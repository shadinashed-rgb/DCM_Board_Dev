# Dashboard Style Guide — HSBC Client Signals

> Extracted from `dashboard.html` (`<title>HSBC Client Signals — Weekly Dashboard</title>`).
> All values marked **exact** are read directly from the source CSS/JS. Values marked *inferred* are
> reasoned from the code but not literally declared.

---

## 1. Overall Design Direction

**Mood and tone.** Restrained corporate banking. The page is almost entirely achromatic — white cards on a light grey field, near-black text — with a single saturated red (`#db0011`) used as the only real chromatic voice. Red never decorates; it is reserved for brand identity (logo, wordmark), structural emphasis (the 6px rule above the hero and the notes block), and risk semantics (critical flags, red signal pills). The result reads as serious, institutional, and deliberately unexciting.

**Level of formality.** High. Uppercase micro-labels with wide letter-spacing (`.06em`–`.1em`), a strict two-weight type system (700 for nearly everything structural, 400 for prose), and no illustrative imagery, gradients, or rounded "friendly" iconography. The one gradient in the file (`.radar-shell`, `#ffffff → #fbfbfb`) is so subtle it functions as a paper texture rather than a decoration.

**Visual density.** Medium-high, and deliberately so. The in-file copy states the board is "Designed to be scanned in 10–15 minutes ahead of the team meeting." Every client row carries eight data cells plus a 58px mini radar, and the table declares `min-width:1200px` — this is a scanning surface, not a summary. Density is made survivable by generous card padding (24–28px) and a large 20px gutter between sections.

**Use of whitespace.** Whitespace is spent on *separation between sections*, not on breathing room inside them. Cards are padded 24–28px; the gap between cards is a consistent 20px; but inside the table, cells are tight (`padding:16px` on the client cell, `16px 10px` on signals). The hero headline is 54px with `line-height:1.02` — near-zero leading, letting the type block itself act as a graphic element.

**Modernity / minimalism / enterprise.** Contemporary enterprise, not trend-driven. Modern signals: 16px card radius, `999px` pill controls, `aspect-ratio`, `minmax(0,1fr)`, CSS custom properties, soft diffuse shadow (`0 8px 24px rgba(0,0,0,.06)`). Enterprise signals: a black table header, a dense data grid, uppercase column groupings, and a source-attribution strip. It is minimal in *palette* and *ornament*, not in *information*.

**What kind of dashboard this is.** Operational-analytical, for a financial audience — specifically a **relationship-banking triage board**. It is not executive (there is no single headline number to report upward) and not customer-facing. Four KPI tiles give a portfolio-level frame, then everything below exists to answer one operator question: *which client do I call this week, and why?* The design language reinforces this with the copy convention "A trigger, not a verdict" — a red cell means "have a look," not "take an action." **Any future board in this style should preserve that stance: the visuals prompt a conversation, they do not deliver a judgement.**

---

## 2. Layout System

### Page structure

A single-column vertical stack of full-bleed sections inside one centred container. There is **no sidebar** and **no persistent top navigation** — this is a standalone single-page board, not a shell within an app.

```
.page  (max-width:1600px; margin:0 auto; padding:24px)
├── .topbar        logo + wordmark | desk meta | refresh + guide link
├── .hero          2-col: hero-card (1.3fr) | stats-card (0.9fr, 2×2 KPI grid)
├── .panel         2-col: radar-shell (480px) | radar-meta (minmax(0,1fr))
├── .controls      search (left) | filter chip groups (right)
├── .mna-bar       agent trigger + scope/window selects | progress + status pill
├── .colour-legend swatch key for the four pill states
├── .table-card    horizontally scrollable data table (min-width:1200px)
├── .pager         range info | prev / page label / next / page-size select
├── .table-foot    filter summary | source attribution
├── .drill         hidden by default; opens below the table on row click
└── .notes-card    3-col: title block | three explanatory notes; + source strip
```

### Grid system

There is no global column grid. Each section declares its own `display:grid` with intentional, **asymmetric** ratios — a recurring signature of this design:

| Section | `grid-template-columns` | Gap | Notes |
|---|---|---|
| `.hero` | `1.3fr .9fr` | `20px` | Narrative outweighs metrics ~59/41 |
| `.stats-card` | `repeat(2,1fr)` | `14px` | 2×2 KPI block, `align-content:start` |
| `.radar-layout` | `480px minmax(0,1fr)` | `28px` | Fixed chart rail, fluid prose |
| `.drill-kpis` | `repeat(4,1fr)` | `12px` | 4-up KPI strip |
| `.notes-grid` | `260px 1fr 1fr` | `20px` | Fixed title rail, two equal notes |
| `.legend-item` | `18px 1fr auto` | `12px` | Swatch / name / metric |

**Rule to carry forward:** the chart rail is a *fixed pixel width* and the prose column is `minmax(0,1fr)`. The `minmax(0,…)` (rather than plain `1fr`) is what stops the 1200px-wide table and long headlines from blowing out the grid. Reuse this pattern verbatim for any chart-plus-explanation panel.

### Spacing between sections

Vertical rhythm is quantised to a small set of values, applied as `margin-bottom` on the *preceding* block:

- `20px` — between all major cards (topbar, hero, panel, drill, notes)
- `16px` — `.mna-bar`, `.colour-legend`
- `12px` — `.controls`, `.table-card` (tight coupling: controls belong to the table, and the pager belongs to the table)

The `12px` gaps are meaningful: controls → table → pager read as **one composite unit**, visually distinct from the 20px-separated cards around them.

### Card / container arrangement

Six classes share one container recipe:

```css
.hero-card, .stats-card, .panel, .table-card, .notes-card, .drill {
  background: var(--hsbc-card);        /* #ffffff */
  border: 1px solid var(--hsbc-border);/* #d7d7d7 */
  border-radius: var(--radius);        /* 16px    */
  box-shadow: var(--shadow);           /* 0 8px 24px rgba(0,0,0,.06) */
}
```

`.topbar` and `.mna-bar` are deliberately excluded — both use a **14px** radius rather than 16px, marking them as chrome/utility bars rather than content cards. Nested surfaces (`.stat`, `.note`) also use **14px**, and the smallest nested elements (`.drill-kpi`, `.drill-empty`) drop to **10px**. Radius therefore encodes nesting depth: `16px` card → `14px` inner panel → `10px` inner-inner tile.

### Alignment patterns

- `.topbar`, `.controls`, `.pager`, `.table-foot`, `.mna-bar` — all `display:flex; justify-content:space-between; flex-wrap:wrap`. Content pushes to the outer edges; wrapping is always allowed.
- `.controls` uses `align-items:flex-end` so the search input's baseline aligns with the filter chips despite the search having a label above it.
- `.drill-head` uses `align-items:baseline` so the drill title and the "Close ×" button sit on a shared text baseline.
- Numeric/signal cells are `text-align:center`; the action column is `text-align:right`; drill-table numerics are `text-align:right`.

### Header / KPI / chart / table placement

- **Header** — `.topbar`, a card (not a bar): logo mark + "HSBC" wordmark, then a `border-left`-separated desk-meta block (red uppercase kicker + 18px title), with the refresh timestamp and external guide link right-aligned.
- **KPI row** — not a row. Four tiles in a 2×2 grid inside `.stats-card`, sitting *beside* the hero rather than beneath it. A second, true 4-up KPI strip (`.drill-kpis`) appears twice inside the drill-down.
- **Chart area** — one `.panel` holding a 400px SVG radar in a fixed 480px rail, paired with a title/description/legend/toggle column.
- **Table** — full-width `.table-card` with `overflow:hidden` on the card and `overflow:auto` on an inner `.table-scroll`. This is what keeps the 16px corner radius intact while the 1200px table scrolls inside it.

### Navigation structure

None. There is no sidebar, no tab bar, no router. Navigation is **in-place state**, not page transitions:

- Filter chips (`Status`: All / Critical / Watch+ / Quiet; `Signal`: Has RCF / Has debt)
- A search box filtering on client name
- Radar mode toggles (Top 3 critical / Single client)
- Pagination (25 / 50 / 100 / Show all)
- Row click → opens the `.drill` panel *below the table* and scrolls to it (`scrollIntoView({behavior:'smooth', block:'start'})`)

The only true outbound link is `../docs/dashboard_guide_for_bankers.html` ("How it works ↗", `target="_blank" rel="noopener"`).

### Responsive behavior

Two breakpoints, both **exact**:

```css
@media (max-width:1200px){
  .hero, .radar-layout, .notes-grid { grid-template-columns:1fr; }  /* all collapse to single column */
  .hero h1        { font-size:42px; }   /* from 54px */
  .drill-kpis     { grid-template-columns:repeat(2,1fr); }  /* 4-up → 2-up */
}
@media (max-width:720px){
  .page   { padding:14px; }  .topbar { padding:14px; }
  .hero-card, .stats-card, .panel, .notes-card, .drill { padding:18px; }
  .hero h1     { font-size:34px; }
  .stats-card  { grid-template-columns:1fr 1fr; }  /* stays 2-up */
}
```

Note the KPI grid **never** goes single-column — a 2×2 block is treated as the floor. The table never reflows; it relies on horizontal scroll at every width. All flex bars carry `flex-wrap:wrap` and degrade without media queries.

### Maximum content width

**`1600px`** (exact), centred via `margin:0 auto`, with `24px` page padding (→ `14px` under 720px). Effective content width at full size: `1552px`.

---

## 3. Logo and Branding Assets

### Logo Presence

**Logo detected: Yes.** Exactly **one** raster brand asset is embedded in the file.

> **Disambiguation.** `dashboard.html` contains two very large lines. Line **279** is the logo (`<img class="logo-mark" src="data:image/png;base64,…">`, 14,510 characters). Line **490** is a ~1.2 MB `<script id="embedded-data" type="application/json">` payload — this is the **client dataset**, not an image, and contains no branding assets. A `grep` for `data:image/` returns exactly one hit across the whole file.

The mark is the **HSBC hexagon** — six red triangles forming a hexagon with two white counter-triangles in the centre. It is accompanied by, but separate from, a text wordmark rendered in live HTML (`<span class="logo-text">HSBC</span>`), not as part of the image.

There is **no favicon** declared (`Not determinable from provided input` — no `<link rel="icon">` exists). A `<meta name="theme-color" content="#db0011">` is present, so mobile browser chrome tints to HSBC red.

### Logo Placement

Top-left of `.topbar`, the first element on the page. Structure:

```html
<div class="logo-wrap">                                   <!-- flex, gap:10px, flex-shrink:0 -->
  <img class="logo-mark" src="data:image/png;base64,…">   <!-- 64×32 -->
  <span class="logo-text">HSBC</span>                     <!-- 22px / 800 / #000 -->
</div>
<div class="desk-meta">…</div>                            <!-- border-left divider, padding-left:16px -->
```

The lockup is **mark + wordmark, horizontal, left-aligned**, separated from the desk-meta block ("LM Banking · Client Signals" / "Weekly conversation dashboard") by a `1px solid #d7d7d7` left border with `16px` of padding. The parent `.topbar-left` sets `gap:18px` between the lockup and that divider. `flex-shrink:0` guarantees the lockup never compresses when the topbar wraps.

The logo appears **only in the header**. It is not used in the sidebar (none exists), footer, cover area, or navigation.

### Logo Styling

- **Approximate width:** `64px` (exact, `.logo-mark{width:64px}`)
- **Approximate height:** `32px` (exact, `.logo-mark{height:32px}`) — a precise **2:1** box matching the asset's native 1132×566
- **Alignment:** left; `display:block` inside a `display:flex; align-items:center` wrapper
- **Padding/margin:** none on the image itself; `10px` gap to the wordmark, `18px` to the divider, `16px` past the divider to the desk meta. Topbar padding is `16px 20px` (→ `14px` under 720px), so the logo's clear space to the card edge is `20px` left / `16px` top.
- **Background treatment:** none. Transparent PNG sitting directly on the white `.topbar` card. `object-fit:contain` guards against any aspect distortion.
- **Border radius:** none.

### Extracted Logo Asset

#### Logo 1 — HSBC hexagon mark

**Format:** PNG (verified — magic bytes `89 50 4E 47 0D 0A 1A 0A`)

**Source type:** Data URI (Base64), inline in the `src` attribute of `<img class="logo-mark">` at **line 279**

**Technical properties (decoded and verified):**

| Property | Value |
|---|---|
| Native dimensions | `1132 × 566` px (2:1) |
| Colour type | `6` — RGBA, truecolour with alpha |
| Bit depth | `8` |
| Decoded size | `10,865` bytes |
| Base64 length | `14,488` chars (`14,510` including the `data:image/png;base64,` prefix) |
| Rendered size | `64 × 32` px → **~17.7× pixel density** (retina-safe well beyond 3×) |
| Sampled red | `rgb(219, 0, 17)` = `#DB0011` — **exactly** `--hsbc-red` |
| Sampled counters | `rgb(255, 255, 255, 255)` — **opaque white**, not transparent |
| Sampled outer corners | `rgba(0, 0, 0, 0)` — fully transparent |

**Two facts worth carrying forward:** (1) the red in the PNG is a pixel-exact match for the `--hsbc-red` token, so the mark and the UI accent will never drift; (2) the white centre triangles are **baked in as opaque white**, while only the four corners outside the hexagon are transparent. The mark therefore renders correctly on *any* background colour — it does not rely on a white page behind it.

**Base64 or Data URI:**

```text
data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABGwAAAI2CAYAAAAFNR73AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAKhNJREFUeNrs3T2r7dt12OHtlQTjIrFk5LxgMG5UGm5qN9IXSJ9O6gJp7MplkkaQSmoC6SRIIKXAX0BfQZBSdZokWFfpUkTkrHPPOnefvffa6/8yX8YY83ngcLjV2Wusy5xj/rgvT08AAAAAAAAAAAAAAAAAAAAAAHDMHxgBMNpvnr77nQ+//bVJAADJ/Oz7T7/92hiAEQQbYKhPseZX3/vpT776+//wH59+//XvDAUACO0Pv/rLpz/6wV89ff2z//zrD3/5Q9EGGOFiBMAot1jz4ddX18Xnz371d0+X7/yxwQAAYb3YWb768OuXpgKMINgAQzyPNXcWIACAUO7sKj/4sNf83HSA3gQboLu3Ys2DRQgAYKoHO8qPRBugN8EG6Oq9WLNxIQIAGGrjbiLaAF0JNkA3W2LNzsUIAKCrnTuJaAN0I9gAXeyJNQcXJACApg7uIqIN0IVgAzR3JNacXJQAAE45uYOINkBzgg3Q1JlY02hhAgCYsXuINkBTgg3QTItY03hxAgAYuXOINkAzgg3QRMtY02mBAgAYsWuINkATgg1wWo9Y03mRAgAW13nHEG2A0wQb4JSesWbQQgUALGbQbiHaAKcINsBhI2LN4MUKAChu8E4h2gCHCTbAISNjzaQFCwAoZtIuIdoAhwg2wG4zYs3kRQsASG7yDiHaALsJNsAuM2NNkIULAEgmyO4g2gC7CDbAZhFiTbDFCwAILtjOINoAmwk2wCaRYk3QBQwACCboriDaAJsINsBDEWNN8EUMALAjvEe0AR4SbIB3RY41SRYyAMBu8BbRBniXYAPclSHWJFvMAAA7wXOiDXCXYAO8KVOsSbqgAQB2gSvRBniTYAO8kjHWJF/UAIC1dwDRBnhFsAG+kDnWFFnYAIA1737RBviCYAN8ViHWFFvcAIC17nzRBvhMsAE+qhRrii5wAMAad71oA3wk2AAlY03xRQ4AlveP/uLPK9/xog0g2MDqKseaG9EGAIo9Yj7c6f/8l/+l+t0u2sDqZ50RwLpWiDU3og0AFHnAfLjLr3f69W5fgGgDK593RgBrWinW3Ig2AJD88bJWrLkRbWDVM88IYD0rxpob0QYAkj5c1ow1N6INrHjuGQGsZeVYcyPaAECyR8vaseZGtIHVzj4jgHWINd8SbQAgyYNFrHlOtIGVzj8jgDWINa+JNgAQ/LEi1rxFtIFVzkAjgPrEmvtEGwAI+lARa94j2sAK56ARQG1izWPXRfBf/PK/GgQARHmkiDVbiDZQ/Sw0AqhLrNnuj37wV0//7Of/ySAAYPYDRazZQ7SByuehEUBNYs1+//hH/1q0AYCZjxOx5gjRBqqeiUYA9Yg1x4k2ADDpYSLWnCHaQMVz0QigFrHmPNEGAAY/SsSaFkQbqHY2GgHUIda0I9oAwKAHiVjTkmgDlc5HI4AaxJr2RBsA6PwYEWt6EG2gyhlpBJCfWNOPaAMAnR4iYk1Pog1UOCeNAHITa/oTbQCg8SNErBlBtIHsZ6URQF5izTiiDQA0eoCINSOJNpD5vDQCyEmsGU+0AYCTjw+xZgbRBrKemUYA+Yg184g2AHDw4SHWzCTaQMZz0wggF7FmPtEGAHY+OsSaCEQbyHZ2GgHkIdbEIdoAwMYHh1gTiWgDmc5PI4AcxJp4RBsAePDYEGsiEm0gyxlqBBCfWBOXaAMAdx4aYk1kog1kOEeNAGITa+ITbQDgxSNDrMlAtIHoZ6kRQFxiTR6iDQB8emCINZmINhD5PDUCiEmsyUe0AWD5x4VYk5FoA1HPVCOAeMSavEQbAJZ9WIg1mYk2EPFcNQKIRazJT7QBYLlHhVhTgWgD0c5WI4A4xJo6RBsAlnlQiDWViDYQ6Xw1AohBrKlHtAGg/GNCrKlItIEoZ6wRwHxiTV2iDQBlHxJiTWWiDUQ4Z40A5hJr6hNtACj3iBBrViDawOyz1ghgHrFmHaINAGUeEGLNSkQbmHneGgHMIdasR7QBIP3jQaxZkWgDs85cI4DxxJp1iTYApH04iDUrE21gxrlrBDCWWINoA0C6R4NYg2gD489eI4BxxBpuRBsA0jwYxBq+JdrAyPPXCGAMsYaXRBsAwj8WxBpeE21g1BlsBNCfWMM9og0AYR8KYg33iTYw4hw2AuhLrOER0QaAcI8EsYbHRBvofRYbAfQj1rCVaANAmAeCWMN2og30PI+NAPoQa9hLtAFg+uNArGE/0QZ6nclGAO2JNRwl2gAw7WEg1nCcaAM9zmUjgLbEGs4SbQAY/igQazhPtIHWZ7MRQDtiDa2INgAMexCINbQj2kDL89kIoA2xhtZEGwC6PwbEGtoTbaDVGW0EcJ5YQy+iDQDdHgJiDf2INtDinDYCOEesoTfRBoDmjwCxhv5EGzh7VhsBHCfWMIpoA0CzB4BYwziiDZw5r40AjhFrGE20AeD08i/WMJ5oA0fPbCOA/cQaZhFtADi8+Is1zCPawJFz2whgH7GG2UQbAHYv/WIN84k2sPfsNgLYTqwhCtEGgM0Lv1hDHKIN7Dm/jQC2EWuIRrQB4OGyL9YQj2gDW89wI4DHxBqiEm0AuLvoizXEJdrAlnPcCOB9Yg3RiTYAvFryxRriE23g0VluBHCfWEMWog0Anxd8sYY8RBt47zw3AnibWEM2og0AYg0JiTZw70w3AnhNrCEr0QZg4cVerCEv0QbeOteNAL4k1pCdaAOw4FIv1pCfaAMvz3YjgG+JNVQh2gAstNCLNdQh2sDz890I4BtiDdWINgALLPNiDfWINnA7440AxBrqEm0ACi/yYg11iTbwJNiAWEN5og1AwSVerKE+0QZnvRGwMrGGVYg2AIUWeLGGdYg2rH3eGwGrEmtYjWgDUGB5F2tYj2jDume+EbAisYZViTYAiRd3sYZ1iTasee4bAasRa1idaAOQcGkXa0C0Yb2z3whYiVgD3xBtABIt7GIN3Ig2rHX+GwGrEGvgS6INQIJlXayBl0Qb1rkDjIAViDXwNtEGIPCiLtbAPaINa9wDRkB1Yg28T7QBCLikizXwiGhD/bvACKhMrIFtRBuAQAu6WANbiTbUvg+MgKrEGthHtAEIsJyLNbCXaEPdO8EIqEisgWNEG4CJi7lYA0eJNtS8F4yAasQaOEe0AZiwlIs1cJZoQ727wQioRKyBNkQbgIELuVgDrYg21LofjIAqxBpoS7QBGLCMizXQmmhDnTvCCKhArIE+RBuAjou4WAO9iDbUuCeMgOzEGuhLtAHosISLNdDbNdr8yBhIfVcYAZmJNTCGaAPQcAEXa2CUn4s2pL4vjICsxBoYS7QBaLB8izUwmmhD3jvDCMhIrIE5RBuAE4u3WAOziDbkvDeMgGzEGphLtAE4sHSLNTCbaEO+u8MIyESsgRhEG4AdC7dYA1GINuS6P4yALMQaiEW0AdiwbIs1EI1oQ547xAjIQKyBmEQbgHcWbbEGohJtyHGPGAHRiTUQm2gD8MaSLdZAdKIN8e8SIyAysQZyEG0Ani3YYg1kIdoQ+z4xAqISayAX0QZArIGERBvi3ilGQERiDeQk2gBLL9ZiDWQl2hDzXjECohFrIDfRBlhyqRZrIDvRhnh3ixEQiVgDNYg2wFILtVgDVYg2xLpfjIAoxBqoRbQBllimxRqoRrQhzh1jBEQg1kBNog1QepEWa6Aq0YYY94wRMJtYA7WJNkDJJVqsgepEG+bfNUbATGINrEG0AUot0GINrEK0Ye59YwTMItbAWkQboMTyLNbAakQb5t05RsAMYg2sSbQBUi/OYg2sSrRhzr1jBIwm1sDaRBsg5dIs1sDqRBvG3z1GwEhiDXAl2gCpFmaxBviGaMPY+8cIGEWsAZ4TbYAUy7JYA3xJtGHcHWQEjCDWAG8RbYDQi7JYA7xNtGHMPWQE9CbWAO8RbYCQS7JYA7xPtKH/XWQE9CTWAFuINkCoBVmsAbYRbeh7HxkBvYg1wB6iDRDFn/70J2INsJVoQzeCDV2INcARog0w2/UMup5FADuINnQh2NCcWAOcIdoAs4g1wAmiDc0JNjQl1gAtiDbAaGIN0IBoQ1OCDc2INUBLog0wilgDNCTa0IxgQxNiDdCDaAP0JtYAHYg2NCHYcJpYA/Qk2gC9iDVAR6INpwk2nCLWACOINkBrYg0wgGjDKYINh4k1wEjXh9X3fvoTgwBOE2uAgUQbDhNsOESsAWb4zl//m6d/4pEFnCDWABOINhwi2LCbWAPM9E8/PLZEG+AIsQaYSLRhN8GGXcQaIALRBthLrAECEG3YRbBhM7EGiES0AbYSa4BARBs2E2zYRKwBIhJtgEfEGiAg0YZNBBseEmuAyEQb4B6xBghMtOEhwYZ3iTVABqIN8JJYAyQg2vAuwYa7xBogE9EGuBFrgEREG+4SbHiTWANkJNoAYg2QkGjDmwQbXhFrgMxEG1iXWAMkJtrwimDDF8QaoALRBtYj1gAFiDZ8QbDhM7EGqES0gXWINUAhog2fCTZ8JNYAFYk2UJ9YAxQk2vCRYINYA5Qm2kBdYg1QmGiDYLM6sQZYgWgD9Yg1wAJEm8UJNgsTa4CViDZQh1gDLES0WZhgsyixBliRaAP5iTXAgkSbRQk2CxJrgJWJNpCXWAMsTLRZkGCzGLEGQLSBjMQaANFmNYLNQsQagG+JNpCHWAPwmWizEMFmEWINwGuiDcQn1gC8ItosQrBZgFgDcJ9oA3GJNQB3iTYLEGyKE2sAHhNtIB6xBuAh0aY4waYwsQZgO9EG4hBrADYTbQoTbIoSawD2E21gPrEGYDfRpijBpiCxBuA40QbmEWsADhNtChJsihFrAM4TbWA8sQbgNNGmGMGmELEGoB3RBsYRawCaEW0KEWyKEGsA2hNtoD+xBqA50aYIwaYAsQagH9EG+hFrALoRbQoQbJITawD6E22gPbEGoDvRJjnBJjGxBmAc0QbaEWsAhhFtEhNskhJrAMYTbeA8sQZgONEmKcEmIbEGYB7RBo4TawCmEW0SEmySEWsA5hNtYD+xBmA60SYZwSYRsQYgDtEGthNrAMIQbRIRbJIQawDiEW3gMbEGIBzRJgnBJgGxBiAu0QbuE2sAwhJtEhBsghNrAOITbeA1sQYgPNEmOMEmMLEGIA/RBr4l1gCkIdoEJtgEJdYA5CPagFgDkJBoE5RgE5BYA5CXaMPKxBqAtESbgASbYMQagPxEG1Yk1gCkJ9oEI9gEItYA1CHasBKxBqAM0SYQwSYIsQagHtGGFYg1AOWINkEINgGINQB1iTZUJtYAlCXaBCDYTCbWANQn2lCRWANQnmgzmWAzkVgDsA7RhkrEGoBliDYTCTaTiDUA6xFtqECsAViOaDOJYDOBWAOwLtGGzMQagGWJNhMINoOJNQCINmQk1gAsT7QZTLAZSKwB4Ea0IROxBoBPRJuBBJtBxBoAXhJtyECsAeAF0WYQwWYAsQaAe0QbIhNrALhDtBlAsOlMrAHgEdGGiMQaAB4QbToTbDoSawDYSrQhErEGgI1Em44Em07EGgD2Em2IQKwBYCfRphPBpgOxBoCjRBtmEmsAOEi06UCwaUysAeAs0YYZxBoAThJtGhNsGhJrAGhFtGEksQaARkSbhgSbRsQaAFoTbRhBrAGgMdGmEcGmAbEGgF5EG3oSawDoRLRpQLA5SawBoDfRhh7EGgA6E21OEmxOEGsAGEW0oSWxBoBBRJsTBJuDxBoARhNtaEGsAWAw0eYgweYAsQaAWUQbzhBrAJhEtDlAsNlJrAFgNtGGI8QaACYTbXYSbHYQawCIQrRhD7EGgCBEmx0Em43EGgCiEW3YQqwBIBjRZiPBZgOxBoCoRBveI9YAEJRos4Fg84BYA0B0og1vEWsACE60eUCweYdYA0AWog3PiTUAJHGNNt7bdwg2d4g1AGQj2nAl1gCQzK9Em7cJNm8QawDISrRZm1gDQEIf39+izWuCzQtiDQDZiTZrEmsASEy0eYNg84xYA0AVos1axBoAChBtXhBsPhFrAKhGtFmDWANAIaLNM4LNk1gDQF2iTW1iDQAFiTafLB9sxBoAqhNtahJrAChMtHlaPNiINQCsQrSpRawBYAHLR5tlg41YA8BqRJsaxBoAFrJ0tFky2Ig1AKxKtMlNrAFgQctGm+WCjVgDwOpEm5zEGgAWtmS0WSrYiDUA8A3RJhexBgDWizbLBBuxBgC+JNrkINYAwGdLRZslgo1YAwBvE21iE2sA4JVlok35YCPWAMD7RJuYxBoAuGuJaFM62Ig1ALCNaBOLWAMAD5WPNmWDjVgDAPuINjGINQCwWeloUzLYiDUAcIxoM5dYAwC7lY025YKNWAMA54g2c4g1AHBYyWhTKtiINQDQhmgzllgDAKeVizZlgo1YAwBtiTZjiDUA0EypaFMi2Ig1ANCHaNOXWAMAzZWJNumDjVgDAH2JNn2INQDQTYlokzrYiDUAMIZo05ZYAwDdpY82aYONWAMAY4k2bYg1ADBM6miTMtiINQAwh2hzzp/8+78VawBgrLTRJl2wEWsAYC7R5pjrzP7k3/2tQQDAeCmjTapgI9YAQAyizT7XWV1nBgBMky7apAk2Yg0AxCLabCPWAEAYqaJNimAj1gBATKLN+8QaAAgnTbQJH2zEGgCITbR5m1gDAGGliDahg41YAwA5iDZfEmsAILzw0SZssBFrACAX0eYbYg0ApBE62oQMNmINAOS0erQRawAgnbDRJlywEWsAILdrsPjDr/5yuc8t1gBAWiGjTahgI9YAQA1/9qu/WyraiDUAkF64aBMm2Ig1AFDH5Tt/vEy0EWsAoIxQ0SZEsBFrAKCeFaKNWAMA5YSJNtODjVgDAHVVjjZiDQCUFSLaTA02Yg0A1Fcx2og1AFDe9GgzLdiINQCwjkrRRqwBgGVMjTZTgo1YAwDrqRBtxBoAWM60aDM82Ig1ALCuzNFGrAGAZU2JNkODjVgDAGSMNmINACxveLQZFmzEGgDg8wKSKNqINQDAJ0OjzZBgI9YAAK+WkATRRqwBAF4YFm26BxuxBgC4u4gEjjZiDQBwx5Bo0zXYiDUAwMNlJGC0EWsAgAe6R5tuwUasAQA2LySBoo1YAwBs1DXadAk2Yg0AsHspCRBtxBoAYKdu0aZ5sBFrAIDDi8nEaCPWAAAHdYk2TYONWAMAnF5OJkQbsQYAOKl5tGkWbMQaAKDZgjIw2og1AEAjTaNNk2Aj1gAArY2INmINANBYs2hzOtiINQBALz2jjVgDAHTSJNqcCjZiDQDQW49oI9YAAJ2djjaHg41YAwCM0jLaiDUAwCCnos2hYCPWAACjtYg2Yg0AMNjhaLM72Ig1AMAsZ6KNWAMATHIo2uwKNmINADDbkWgj1gAAk+2ONpuDjVgDAESxJ9qINQBAELuizaZgI9YAANFsiTZiDQAQzOZo8zDYiDUAQFTvRRuxBgAIalO0eTfYiDUAQHRvRRuxBgAI7mG0uRtsxBoAIIvn0UasAQCSeDfaXMwHAAAAIJa7web7T7/9+sNvP/zw69fGBABE9vuvf/f0P374r57+76//+9P/+cV/e/qfP/63hgIARPexu3z/6bdvdpd3/wkb0QYAiO55rLkRbQCA4N6NNVcP/5Uo0QYAiOqtWHMj2gAAQT2MNVeb/hs2og0AEM17seZGtAEAgtkUa642/0eHRRsAIIotseZGtAEAgtgca652/V+iRBsAYLY9seZGtAEAJtsVa652/2+9RRsAYJYjseZGtAEAJtkda64uR/4k0QYAGO1MrLkRbQCAwQ7FmqvL0T9RtAEARmkRa25EGwBgkMOx5upy5k8WbQCA3lrGmhvRBgDo7FSsubqc/QlEGwCglx6x5ka0AQA6OR1rri4tfhLRBgBorWesuRFtAIDGmsSaq0urn0i0AQBaGRFrbkQbAKCRZrHm6tLyJxNtAICzRsaaG9EGADipaay5urT+CUUbAOCoGbHmRrQBAA5qHmuuLj1+UtEGANhrZqy5EW0AgJ26xJqrS6+fWLQBALaKEGtuRBsAYKNusebq0vMnF20AgEcixZob0QYAeKBrrLm69P4Eog0AcE/EWHMj2gAAd3SPNVeXEZ9EtAEAXooca25EGwDghSGx5uoy6hOJNgDATYZYcyPaAACfDIs1V5eRn0y0AQAyxZob0QYAljc01lxdRn9C0QYA1pUx1tyINgCwrOGx5uoy45OKNgCwnsyx5ka0AYDlTIk1V5dZn1i0AYB1VIg1N6INACxjWqy5usz85KINANRXKdbciDYAUN7UWHN1mT0B0QYA6qoYa25EGwAoa3qsubpEmIRoAwD1VI41N6INAJQTItZcXaJMRLQBgDpWiDU3og0AlBEm1lxdIk1GtAGA/FaKNTeiDQCkFyrWXF2iTUi0AYC8Vow1N6INAKQVLtZcXSJOSrQBgHxWjjU3og0ApBMy1lxdok5MtAGAPMSab4k2AJBG2FhzdYk8OdEGAOITa14TbQAgvNCx5uoSfYKiDQDEJdbcJ9oAQFjhY83VJcMkRRsAiEeseUy0AYBwUsSaq0uWiYo2ABCHWLOdaAMAYaSJNVeXTJMVbQBgPrFmP9EGAKZLFWuuLtkmLNoAwDxizXGiDQBMky7WXF0yTlq0AYDxxJrzRBsAGC5lrLm6ZJ24aAMA44g17Yg2ADBM2lhzdck8edEGAPoTa9oTbQCgu9Sx5uqS/RsQbQCgH7GmH9EGALpJH2uuLhW+CdEGANoTa/oTbQCguRKx5upS5RsRbQCgHbFmHNEGAJopE2uuLpW+GdEGAM4Ta8YTbQDgtFKx5upS7RsSbQDgOLFmHtEGAA4rF2uuLhW/KdEGAPYTa+YTbQBgt5Kx5upS9RsTbQBgO7EmDtEGADYrG2uuLpW/OdEGAB4Ta+IRbQDgodKx5upS/RsUbQDgPrEmLtEGAO4qH2uuLit8k6INALwm1sQn2gDAK0vEmqvLKt+oaAMA3xJr8hBtAOCzZWLN1WWlb1a0AQCxJiPRBgDWijVXl9W+YdEGgJWJNXmJNgAsbLlYc3VZ8ZsWbQBYkViTn2gDwIKWjDVXl1W/cdEGgJWINXWINgAsZNlYc3VZ+ZsXbQBYgVhTj2gDwAKWjjVXl9X/DhBtAKhMrKlLtAGgsOVjzdXF3weiDQA1iTX1iTYAFCTWfCLYfCLaAFCJWLMO0QaAQsSaZwSbZ0QbACoQa9Yj2gBQgFjzgmDzwrNo8wvTACAbsWZdog0AiYk1bxBs3nCNNh9+/fhJtAEgEbEG0QaAhMSaOwSbd4g2AGQh1nAj2gCQiFjzDsHmAdEGgOjEGl4SbQBIQKx5QLDZQLQBICqxhntEGwACE2s2EGw2Em0AiEas4RHRBoCAxJqNBJsdRBsAohBr2Eq0ASAQsWYHwWYn0QaA2cQa9hJtAAhArNlJsDlAtAFgFrGGo0QbACYSaw4QbA4SbQAYTazhLNEGgAnEmoMEmxNEGwBGEWtoRbQBYCCx5gTB5iTRBoDexBpaE20AGECsOUmwaUC0AaAXsYZeRBsAOhJrGhBsGhFtAGhNrKE30QaADsSaRgSbhkQbAFoRaxhFtAGgIbGmIcGmMdEGgLPEGkYTbQBoQKxpTLDpQLQB4CixhllEGwBOEGs6EGw6EW0A2EusYTbRBoADxJpOBJuORBsAthJriEK0AWAHsaYjwaYz0QaAR8QaohFtANhArOlMsBlAtAHgHrGGqEQbAN4h1gwg2Awi2gDwklhDdKINAG8QawYRbAYSbQC4EWvIQrQB4BmxZiDBZjDRBgCxhmxEGwCexJrhBJsJRBuAdYk1ZCXaACxNrJlAsJlEtAFYj1hDdqINwJLEmkkEm4lEG4B1iDVUIdoALEWsmUiwmUy0AahPrKEa0QZgCWLNZIJNAKINQF1iDVWJNgCliTUBCDZBiDYA9Yg1VCfaAJQk1gQh2AQi2gDUIdawCtEGoBSxJhDBJhjRBiA/sYbViDYAJYg1wQg2AYk2AHmJNaxKtAFITawJSLAJSrQByEesYXWiDUBKYk1Qgk1gog1AHmINfEO0AUhFrAlMsAlOtAGIT6yBL4k2ACmINcEJNgmINgBxiTXwNtEGIDSxJgHBJgnRBiAesQbeJ9oAhCTWJCHYJCLaAMQh1sA2og1AKGJNIoJNMqINwHxiDewj2gCEINYkI9gkJNoAzCPWwDGiDcBUYk1Cgk1Sog3AeGINnCPaAEwh1iQl2CQm2gCMI9ZAG6INwFBiTWKCTXKiDUB/Yg20JdoADCHWJCfYFCDaAPQj1kAfog1AV2JNAYJNEaINQHtiDfQl2gB0IdYUIdgUItoAtCPWwBiiDUBTYk0hgk0xog3AeWINjCXaADQh1hQj2BQk2gAcJ9bAHKINwCliTUGCTVGiDcB+Yg3MJdoAHCLWFCXYFCbaAGwn1kAMog3ALmJNYYJNcaINwGNiDcQi2gBsItYUJ9gsQLQBuE+sgZhEG4B3iTULEGwWIdoAvCbWQGyiDcCbxJpFCDYLEW0AviXWQA6iDcAXxJqFCDaLEW0AxBrIRrQB+EisWYxgsyDRBliZWAM5iTbA4sSaBQk2ixJtgBWJNZCbaAMsSqxZlGCzMNEGWIlYAzWINsBixJqFCTaLE22AFYg1UItoAyxCrFmcYINoA5Qm1kBNog1QnFiDYMM3RBugIrEGahNtgKLEGj4SbPhMtAEqEWtgDaINUIxYw2eCDV8QbYAKxBpYi2gDFCHW8AXBhldEGyAzsQbWJNoAyYk1vCLY8CbRBshIrIG1iTZAUmINbxJsuEu0ATIRa4Ar0QZIRqzhLsGGd4k2QAZiDfCcaAMkIdbwLsGGh0QbIDKxBniLaAMEJ9bwkGDDJqINEJFYA7xHtAGCEmvYRLBhM9EGiESsAbYQbYBgxBo2E2zYRbQBIhBrgD1EGyAIsYZdBBt2E22AmcQa4AjRBphMrGE3wYZDRBtgBrEGOEO0ASYRazhEsOEw0QYYSawBWhBtgMHEGg4TbDhFtAFGEGuAlkQbYBCxhlMEG04TbYCexBqgB9EG6Eys4TTBhiZEG6AHsQboSbQBOhFraEKwoRnRBmhJrAFGEG2AxsQamhFsaEq0AVoQa4CRRBugEbGGpgQbmhNtgDPEGmAG0QY4SayhOcGGLkQb4AixBphJtAEOEmvoQrChG9EG2EOsASIQbYCdxBq6EWzoSrQBthBrgEhEG2AjsYauBBu6E22A94g1QESiDfCAWEN3gg1DiDbAW8QaIDLRBrhDrGEIwYZhRBvgObEGyEC0AV4QaxhGsGEo0Qa4EmuATEQb4BOxhqEEG4YTbWBtYg2QkWgDyxNrGE6wYQrRBtYk1gCZiTawLLGGKQQbphFtYC1iDVCBaAPLEWuYRrBhKtEG1iDWAJWINrAMsYapBBumE22gNrEGqEi0gfLEGqYTbAhBtIGaxBqgMtEGyhJrCEGwIQzRBmoRa4AViDZQjlhDGIINoYg2UINYA6xEtIEyxBpCEWwIR7SB3MQaYEWiDaQn1hCOYENIog3kJNYAKxNtIC2xhpAEG8ISbSAXsQZAtIGExBrCEmwITbSBHMQagG+JNpCGWENogg3hiTYQm1gD8JpoA+GJNYQn2JCCaAMxiTUA94k2EJZYQwqCDWmINhCLWAPwmGgD4Yg1pCHYkIpoAzGINQDbiTYQhlhDKoIN6Yg2MJdYA7CfaAPTiTWkI9iQkmgDc4g1AMeJNjCNWENKgg1pfYo2PzMJGEOsAThPtIHhxBrSEmxI7cPB+zcffvuxSUBfYg1AO6INDCPWkJpgQ3ofDuBfPIk20I1YA9CeaAPdiTWkJ9hQgmgDfYg1AP2INtCNWEMJgg1liDbQllgD0J9oA82JNZQh2FCKaANtiDUA44g20IxYQymCDeWINnCOWAMwnmgDp4k1lCPYUJJoA8eINQDziDZwmFhDSYINZYk2sI9YAzCfaAO7iTWUJdhQmmgD24g1AHGINrCZWENpgg3liTbwPrEGIB7RBh4SayhPsGEJog28TawBiEu0gbvEGpYg2LAM0Qa+JNYAxCfawCtiDcsQbFiKaAPfEGsA8hBt4DOxhqUINixHtGF1Yg1APqINiDWsR7BhSaINqxJrAPISbViYWMOSBBuWJdqwGrEGID/RhgWJNSxLsGFpog2rEGsA6hBtWIhYw9IEG5Yn2lCdWANQj2jDAsQalifYwJNoQ11iDUBdog2FiTXwJNjAZ6IN1Yg1APWJNhQk1sAngg08I9pQhVgDsA7RhkLEGnhGsIEXRBuyE2sA1iPaUIBYAy8INvAG0YasxBqAdYk2JCbWwBsEG7hDtCEbsQYA0YaExBq4Q7CBd4g2ZCHWAHAj2pCIWAPvEGzgAdGG6MQaAF4SbUhArIEHBBvYQLQhKrEGgHtEGwITa2ADwQY2Em2IRqwB4BHRhoDEGthIsIEdRBuiEGsA2Eq0IRCxBnYQbGAn0YbZxBoA9hJtCECsgZ0EGzhAtGEWsQaAo0QbJhJr4ADBBg4SbRhNrAHgLNGGCcQaOEiwgRNEG0YRawBoRbRhILEGThBs4CTRht7EGgBaE20YQKyBkwQbaEC0oRexBoBeRBs6EmugAcEGGhFtaE2sAaA30YYOxBpoRLCBhkQbWhFrABhFtKEhsQYaEmygMdGGs8QaAEYTbWhArIHGBBvoQLThKLEGgFlEG04Qa6ADwQY6EW3YS6wBYDbRhgPEGuhEsIGORBu2EmsAiEK0YQexBjoSbKAz0YZHxBoAohFt2ECsgc4EGxhAtOEesQaAqEQb3iHWwACCDQwi2vCSWANAdKINbxBrYBDBBgYSbbgRawDIQrThGbEGBhJsYDDRBrEGgGxEG57EGhhOsIEJRJt1iTUAZCXaLE2sgQkEG5hEtFmPWANAdqLNksQamESwgYlEm3WINQBUIdosRayBiQQbmEy0qU+sAaAa0WYJYg1MJthAAKJNXWINAFWJNqWJNRCAYANBiDb1iDUAVCfalCTWQBCCDQQi2tQh1gCwCtGmFLEGAhFsIBjRJj+xBoDViDYliDUQjGADAYk2eYk1AKxKtElNrIGABBsISrTJR6wBYHWiTUpiDQQl2EBgok0eYg0AfEO0SUWsgcAEGwhOtIlPrAGAL4k2KYg1EJxgAwmINnGJNQDwNtEmNLEGEhBsIAnRJh6xBgDeJ9qEJNZAEoINJCLaxCHWAMA2ok0oYg0kIthAMqLNfGINAOwj2oQg1kAygg0kJNrMI9YAwDGizVRiDSQk2EBSos14Yg0AnCPaTCHWQFKCDSQm2owj1gBAG6LNUGINJCbYQHKiTX9iDQC0JdoMIdZAcoINFCDa9CPWAEAfok1XYg0UINhAEaJNe2INAPQl2nQh1kARgg0UItq0I9YAwBiiTVNiDRQi2EAxos15Yg0AjCXaNCHWQDGCDRQk2hwn1gDAHKLNKWINFCTYQFGizX5iDQDMJdocItZAUYINFCbabCfWAEAMos0uYg0UJthAcaLNY2INAMQi2mwi1kBxgg0sQLS5T6wBgJhEm3eJNbAAwQYWIdq8JtYAQGyizZvEGliEYAMLEW2+JdYAQA6izRfEGliIYAOLEW3EGgDIRrT5SKyBxQg2sKCVo41YAwA5LR5txBpYkGADi1ox2og1AJDbotFGrIFFCTawsJWijVgDADUsFm3EGliYYAOLWyHaiDUAUMsi0UasgcUJNkDpaCPWAEBNxaONWAMINsA3KkYbsQYAaisabcQa4CPBBvisUrQRawBgDcWijVgDfCbYAF+oEG3EGgBYS5FoI9YAXxBsgFcyRxuxBgDWlDzaiDXAK4IN8KaM0UasAYC1JY02Yg3wJsEGuCtTtBFrAICrZNFGrAHuEmyAd2WINmINAPBckmgj1gDvEmyAhyJHG7EGAHhL8Ggj1gAPCTbAJhGjjVgDALwnaLQRa4BNBBtgs0jRRqwBALYIFm3EGmAzwQbYJUK0EWsAgD2CRBuxBthFsAF2mxltxBoA4IjJ0UasAXYTbIBDZkQbsQYAOGNStBFrgEMEG+CwkdFGrAEAWhgcbcQa4DDBBjhlRLQRawCAlgZFG7EGOEWwAU7rGW3EGgCgh87RRqwBThNsgCZ6RBuxBgDoqVO0EWuAJgQboJmW0UasAQBGaBxtxBqgGcEGaKpFtBFrAICRGkUbsQZoSrABmjsTbcQaAGCGk9FGrAGaE2yALo5EG7EGAJjpYLQRa4AuBBugmz3RRqwBACLYGW3EGqAbwQboaku0EWsAgEg2RhuxBuhKsAG6+xRt/uWnxeYLYg0AENGDaCPWAN0JNsAQnxaaHz49izZiDQAQ2Z1oI9YAQ/xDIwBGuS42v3n67jXa/Or3X//uO2INABDdNdp8fDj9xZ9ffxNrgGH+wAiA0X7z9N2v/sGffu+n/+9//W/DAABS+LC7PH3YXf5GrAEAAAAAWNT/F2AAsll3ydjRog0AAAAASUVORK5CYII=
```

**External source, if applicable:**

```text
Not applicable — the logo is fully embedded. The file references no external image, CDN, or icon font.
(The only external reference in the document is a documentation link:
 ../docs/dashboard_guide_for_bankers.html)
```

**Inline SVG, if applicable:**

```xml
Not applicable — the brand mark is a raster PNG, not inline SVG.
(Inline SVG is used in this dashboard for data visualisation only: #mainRadar and the per-row .mini-radar.)
```

#### Logo 2 — "HSBC" wordmark (live text, not an asset)

**Format:** Not an image — rendered as HTML text.

**Source type:** Inline HTML + CSS.

```css
.logo-text{ font-size:22px; font-weight:800; letter-spacing:.02em; color:#000000; }
```

This is the only place in the entire stylesheet that uses `font-weight:800` on a full word, and one of only two uses of `800` at all (the other being the 9px `.disc-tag`). Treat `800` as **reserved for the wordmark**; do not introduce it into body or heading styles.

*Assumption, labelled:* because the real HSBC wordmark is set in a licensed typeface (Univers Next for HSBC) which the `font-family` stack requests but cannot guarantee, this text lockup will fall back to Arial on most machines. It is a functional stand-in, not a faithful brand wordmark. If a licensed wordmark asset becomes available, replace this `<span>` rather than restyling it.

### Logo Usage Rules

- **Recommended placement.** Top-left of the header card, as the first child, in a `mark + wordmark` horizontal lockup. Never centre it, never place it in a footer, and never repeat it inside content cards.
- **Recommended size.** `64 × 32` px for the mark (locked 2:1), paired with a `22px / 800` wordmark. Scale the pair together; do not exceed ~`96 × 48` in a header, and do not go below `40 × 20` (the counter-triangles start to fill in). Always set both `width` and `height` plus `object-fit:contain` — never let the aspect float.
- **Minimum spacing.** Keep at least `10px` between mark and wordmark (exact, from `.logo-wrap{gap:10px}`) and at least **half the logo's height (`16px`)** of clear space on all other sides. In the source, the nearest neighbour is the `18px` gap to the desk-meta divider — treat `16px` as the hard floor and `18px+` as the intended value.
- **Light or dark backgrounds.** Safe on **both**. Because the white counter-triangles are opaque, the hexagon holds its form on dark surfaces (e.g. the `#111111` table header) without needing a knockout variant. On light backgrounds it is used as-is, on white. Do not add a coloured plate, drop shadow, or rounded background behind it — the asset already carries its own figure/ground.
- **Where it may appear.** Header only, in this design. There is no sidebar or footer usage. If a cover/title slide is ever added, place the lockup top-left at the same 2:1 ratio and scale to `96 × 48`.
- **What never to do.** Do not recolour the mark (its red is token-locked to `--hsbc-red`), do not rotate or mirror it, do not apply `border-radius`, and do not re-encode the PNG at a lower resolution — the current asset is only ~10.9 KB and already retina-safe at 17×.

---

## 4. Colour Palette

All hex values below are **exact** — read from `:root` custom properties or from literal declarations in the stylesheet. Nothing here is sampled or approximated except where noted.

| Role | Approx. HEX | Usage |
|---|---:|---|
| **Brand & accent** | | |
| Brand red (`--hsbc-red`) | `#DB0011` | The single accent. Logo, eyebrows, kickers, hero `::before` rule, active toggles, links, primary radar series, `theme-color`, priority-3 bar, focus borders |
| Brand red — dark (`--hsbc-red-dark`) | `#B1000E` | Hover state of the primary filled button (`.mna-run`) only |
| Amber / ochre (secondary accent) | `#996300` | The *only* secondary accent. "Watch" KPI value, priority-2 bar, third radar series. Note: **not** a token — hard-coded in 5 places |
| **Surfaces** | | |
| Page background (`--hsbc-bg`) | `#F3F3F3` | `html, body` field behind all cards |
| Card surface (`--hsbc-card`) | `#FFFFFF` | All cards, topbar, mna-bar, table body, controls |
| Soft surface (`--hsbc-soft`) | `#F8F8F8` | Nested tiles: `.stat`, `.note`, `.legend-item`, `.drill-kpi`, `.drill-empty`, idle status pill |
| Radar shell gradient | `#FFFFFF → #FBFBFB` | `linear-gradient(180deg,…)` on `.radar-shell` — a near-invisible paper tone |
| **Header / table chrome** | | |
| Table header | `#111111` | `thead th` background. Near-black, not pure black |
| Table header — grouped | `#1E1E1E` | `thead .group-market` — one column group tinted one step lighter to separate "Market · Bloomberg" |
| Header text | `#FFFFFF` | `thead th` |
| Header group label | `rgba(255,255,255,.62)` | 9px `.group-label` above each column name |
| Header cell divider | `rgba(255,255,255,.08)` | `border-right` between header cells |
| **Text** | | |
| Text primary (`--hsbc-charcoal`) | `#333333` | `body` default, chip/toggle labels, drill table cells |
| Text emphasis (`--hsbc-black`) | `#000000` | All headings, KPI values, client names, wordmark, `<strong>` |
| Text muted (`--hsbc-slate`) | `#5C5C5C` | Subtitles, labels, metadata, sector/geo, pager info, note text |
| Radar axis label | `#666666` | 10px uppercase axis names |
| Radar axis sub-label | `#888888` | 9px axis qualifier ("news", "util.") |
| **Borders & dividers** | | |
| Border subtle (`--hsbc-border`) | `#D7D7D7` | All card borders, row bottom borders, cell right borders |
| Border strong (`--hsbc-border-strong`) | `#B8B8B8` | Interactive edges: chips, toggles, inputs, pager buttons, dashed source strip |
| Legend hover border | `#B5B5B5` | `.legend-item:hover` |
| Radar grid ring | `#E2E2E2` | Inner rings at 25 / 50 / 75 |
| Radar outer ring | `#C9C9C9` | The 100 ring, drawn 1.2px to close the shape |
| Radar axis spoke | `#D8D8D8` | Dashed `4 4` spokes; also the mini-radar grid |
| Swatch hairline | `rgba(0,0,0,.06)` | 1px border on legend swatches |
| **Signal / status states** | | |
| Negative — bg (`--pill-red-bg`) | `#FDE7EA` | "Red — clear trigger" cell |
| Negative — text (`--pill-red-tx`) | `#8F0010` | Text on red pill |
| Warning — bg (`--pill-amber-bg`) | `#FFF2DB` | "Amber — worth a glance" cell |
| Warning — text (`--pill-amber-tx`) | `#7A5500` | Text on amber pill |
| Positive — bg (`--pill-green-bg`) | `#E7F5EC` | "Green — nothing to flag" cell |
| Positive — text (`--pill-green-tx`) | `#1C5C35` | Text on green pill |
| Neutral / no-data — bg (`--pill-grey-bg`) | `#EFEFEF` | "Grey — no data" cell; also `.drill-table th` background |
| Neutral / no-data — text (`--pill-grey-tx`) | `#666666` | Text on grey pill |
| **Row & priority** | | |
| Row hover | `#FCF4F5` | `tbody tr:hover` — the faintest possible red wash |
| Row selected | `#FFF1F3` | `tbody tr.selected` — one step stronger than hover |
| Priority 3 bar | `#DB0011` | 3+ red flags → critical |
| Priority 2 bar | `#996300` | 1–2 red flags → watch |
| Priority 1 bar | `#777777` | Amber flags only |
| Priority 0 bar | `#D0D0D0` | No flags → quiet (the `.priority-bar` default) |
| **Discovery tags** | | |
| `.disc-tag.cin_only` | text `#1C5C35` · border `#BFE0CB` · bg `#EAF6EE` | Matched on CIN only |
| `.disc-tag.name_only` | text `#8F0010` · border `#F3C9CF` · bg `#FDEEF0` | Matched on name only |
| `.disc-tag.both` | text `#7A5500` · border `#ECD7A6` · bg `#FFF5E2` | Matched on both |
| **Agent status pill borders** | | |
| Busy border | `#ECCF95` | `.mna-status[data-tone="busy"]` |
| Success border | `#BFE3CC` | `.mna-status[data-tone="success"]` |
| Error border | `#F0C2C9` | `.mna-status[data-tone="error"]` |
| **Chart series (main radar, max 3)** | | |
| Series 1 | stroke `#DB0011` · fill `rgba(219,0,17,.20)` | Highest-priority client; also the single-client colour |
| Series 2 | stroke `#111111` · fill `rgba(0,0,0,.14)` | Second client |
| Series 3 | stroke `#996300` · fill `rgba(153,99,0,.18)` | Third client |
| **Chart series (mini radar, priority-driven)** | | |
| pri-3 | stroke `#DB0011` · fill `rgba(219,0,17,.24)` | Critical |
| pri-2 | stroke `#996300` · fill `rgba(153,99,0,.20)` | Watch |
| pri-1 | stroke `#777777` · fill `rgba(90,90,90,.18)` | Amber-only |
| pri-0 | stroke `#1C5C35` · fill `rgba(28,92,53,.14)` | Quiet |

**Palette discipline.** The whole board runs on **one hue plus one secondary** (`#DB0011` + `#996300`), a green and a grey reserved strictly for semantics, and eleven greys. There is no blue, no purple, no teal, no categorical rainbow anywhere. Preserve this: adding a decorative hue is the fastest way to break the style.

---

## 5. Typography

### Font family

```css
font-family:"Univers Next for HSBC Regular","Univers Next for HSBC",
            "Arial","Helvetica Neue",sans-serif;
-webkit-font-smoothing:antialiased;
-moz-osx-font-smoothing:grayscale;
```

Declared once on `html, body` and inherited everywhere — no element re-declares a family. `.mna-run` uses `font:700 11px/1 inherit` specifically so the shorthand does not reset the inherited family.

The primary face is **Univers Next for HSBC**, a licensed corporate grotesque. It will not be present on most machines, so the practical rendering is **Arial**. *Inferred category:* a neutral, closed-aperture, Helvetica-lineage grotesque — **not** a geometric (Futura), humanist (Frutiger/Segoe), or modern UI sans (Inter). If substituting, prefer Arial → Helvetica Neue → Univers → Nimbus Sans. Avoid Inter and Roboto; their wider apertures and taller x-height noticeably change the board's tone.

### Weight system

Only **three** weights appear, and their distribution is unusually strict:

| Weight | Where |
|---|---|
| `400` (implicit) | Body prose only: `.subtitle`, `.radar-desc`, `.note-text`, `.notes-title p`, `.source-strip`, `.pager-info` |
| `600` | Exactly two places: `.client-geo` and `.mna-field select` |
| `700` | **Everything else** — all headings, all labels, all KPI values, all buttons, all table headers, all pills |
| `800` | Exactly two places: `.logo-text` (22px wordmark) and `.disc-tag` (9px tag) |

**Rule:** in this system, `700` is the default and `400` is the exception. Prose is 400; anything that labels, quantifies, or acts is 700.

### Type scale (all values exact)

| Token / element | Size | Weight | Line-height | Letter-spacing | Transform |
|---|---|---|---|---|---|
| `.hero h1` | `54px` → `42px` @1200 → `34px` @720 | 700 | `1.02` | `-.03em` | — |
| `.radar-title` | `34px` | 700 | `1.08` | `-.02em` | — |
| `.notes-title h3` | `28px` | 700 *(inherited from `h3`)* | `1.08` | — | — |
| `.drill-title` | `24px` | 700 | — | — | — |
| `.logo-text` | `22px` | **800** | — | `.02em` | — |
| `.drill-kpi-value` | `20px` | 700 | — | — | — |
| `.desk-meta .title` | `18px` | 700 | `1.2` | — | — |
| `.client-name` | `17px` | 700 | `1.2` | — | — |
| `.subtitle` | `16px` | 400 | `1.55` | — | — |
| `.drill-section-title` | `16px` | 700 | — | — | — |
| `.stat .value` | `36px` | 700 | `1` | — | — |
| `.radar-desc` | `15px` | 400 | `1.6` | — | — |
| `.legend-name` | `15px` | 700 | `1.2` | — | — |
| `.note-text`, `.notes-title p` | `14px` | 400 | `1.6` | — | — |
| `.search-box` | `14px` | 400 | — | — | — |
| `.signal` (value) | `13px` | 700 | `1.1` | — | — |
| `.eyebrow` | `12px` | 700 | — | `.1em` | uppercase |
| `.desk-meta .kicker` | `12px` | 700 | — | `.08em` | uppercase |
| `.topbar-right` | `12px` | 400 | — | `.08em` | uppercase |
| `.toggle` | `12px` | 700 | — | `.06em` | uppercase |
| `.chip` | `12px` | 700 | — | — | — |
| `.action-link` | `12px` | 700 | — | `.06em` | uppercase |
| `.pg-btn`, `.pg-size`, `.pg-page` | `12px` | 700 | — | — | — |
| `.legend-flags`, `.pager-info`, `.table-foot`, `.mna-prog`, `.source-strip` | `12px` | 400 | `1.5` | — | — |
| `.stat .label` | `11px` | 700 | — | `.08em` | uppercase |
| `thead th` | `11px` | 700 | — | `.06em` | uppercase |
| `.drill-eyebrow`, `.drill-close` | `11px` | 700 | — | `.1em` / `.08em` | uppercase |
| `.client-sector` | `11px` | 700 | — | `.06em` | uppercase |
| `.client-geo` | `11px` | **600** | — | `.06em` | uppercase |
| `.mna-run`, `.mna-status`, `.mna-field` | `11px` | 700 | `1` | `.06em` / `.04em` | uppercase |
| `.filter-group .grp-label` | `10px` | 700 | — | `.08em` | uppercase |
| `.signal small` | `10px` | 700 | — | `.05em` | uppercase, `opacity:.72` |
| `.radar-axis-label` | `10px` | 700 | — | `.08em` | uppercase |
| `.group-label` (thead) | `9px` | 700 | — | `.08em` | — |
| `.disc-tag` | `9px` | **800** | — | `.06em` | uppercase |
| `.drill-table th` | `9px` | 700 | — | `.06em` | uppercase |
| `.drill-kpi-label` | `9px` | 700 | — | `.1em` | uppercase |
| `.radar-axis-label-sub` | `9px` | 400 | — | — | — |

### The governing typographic idea

**Letter-spacing scales inversely with font size.** Display type gets *negative* tracking (`-.03em` at 54px, `-.02em` at 34px) to tighten the headline into a block. Micro-labels get *positive* tracking (`.06em`–`.1em`) plus uppercase to stay legible at 9–12px. There is no tracking at all in the 13–22px middle band. Reproduce this curve on any new type you add:

- `≥ 28px` → `letter-spacing: -.02em` to `-.03em`, `line-height: 1.02`–`1.08`
- `13–22px` → no tracking, `line-height: 1.2` (headings) or `1.5`–`1.6` (prose)
- `≤ 12px` → `uppercase`, `700`, `letter-spacing: .06em`–`.1em`

Prose line-height is generous (`1.55`–`1.6`); heading line-height is tight (`1.02`–`1.2`). KPI values run at `line-height:1` so the digits sit flush in their tile.

---

## 6. Components

### Cards

| Property | Value |
|---|---|
| Background | `#FFFFFF` (`--hsbc-card`) |
| Border | `1px solid #D7D7D7` (`--hsbc-border`) |
| Border radius | `16px` (`--radius`); `14px` for chrome bars and nested tiles; `10px` for the smallest tiles |
| Padding | `24px` standard (`.panel`, `.drill`, `.notes-card`); `28px 28px 26px` for `.hero-card`; `22px` for `.stats-card`; `16px 20px` for `.topbar`; `12px 16px` for `.mna-bar`; `18px` for everything at ≤720px |
| Shadow | `0 8px 24px rgba(0,0,0,.06)` — wide, soft, low-opacity; a *lift*, not a drop |
| Header style | A red uppercase `.eyebrow` (12px / 700 / `.1em`) above a large black heading. The eyebrow is the section's label; the heading is its statement. |
| Content style | Black heading → slate prose (`max-width:720–760px`) → controls |
| Divider usage | `border-bottom:1px solid #D7D7D7` under `.drill-head` with `padding-bottom:14px; margin-bottom:20px`. `border-left:1px solid #D7D7D7` inside `.topbar` to separate lockup from desk meta. |
| Interaction | Cards themselves are static. Only `tbody tr` and `.legend-item` respond to hover. |

**The red rule motif.** Two cards are topped by a 6px red bar, and this is the design's strongest structural signature:

```css
.hero-card::before{ content:""; position:absolute; left:0; top:0;
                    width:100%; height:6px; background:var(--hsbc-red); }
.notes-title      { border-top:6px solid var(--hsbc-red); padding-top:14px; }
```

`.hero-card` pairs this with `position:relative; overflow:hidden` so the bar clips to the 16px radius. Use the pseudo-element form when the bar must span a full card; use `border-top` when it should cap a single column. Reserve it for the page's *opening* statement and its *closing* explainer — do not put a red rule on every card.

### KPI Tiles

Two distinct tile types.

**Portfolio tiles (`.stat`)** — the 2×2 block beside the hero:

```css
.stat{ background:#F8F8F8; border:1px solid #D7D7D7; border-radius:14px;
       padding:16px; min-height:110px; }
.stat .label{ font-size:11px; font-weight:700; color:#5C5C5C;
              text-transform:uppercase; letter-spacing:.08em; margin-bottom:10px; }
.stat .value{ font-size:36px; line-height:1; font-weight:700; color:#000; margin-bottom:8px; }
.stat .value.red  { color:#DB0011; }
.stat .value.amber{ color:#996300; }
.stat .sub{ font-size:12px; color:#5C5C5C; line-height:1.35; }
```

Order is **label → value → sub**, top to bottom: you read what it is, then the number, then the qualifier. The four tiles are hard-coded in `renderStats()`:

| Label | Value | Sub | Value colour |
|---|---|---|---|
| Clients | `total` | In coverage | black |
| Critical | `priority===3` | 3+ red flags | `#DB0011` |
| Watch | `priority===2` | 1–2 red flags | `#996300` |
| Quiet | `priority<=1` | No / amber-only flags | black |

**KPI colour is semantic, never decorative.** Only the two tiles that represent risk are coloured; "Clients" and "Quiet" stay black. A green KPI value is never used — good news is expressed by *absence* of colour.

**Drill tiles (`.drill-kpi`)** — the 4-up strips inside the drill-down:

```css
.drill-kpi{ background:#F8F8F8; border:1px solid #D7D7D7;
            border-left:3px solid #DB0011; border-radius:10px; padding:10px 14px; }
.drill-kpi-label{ font-size:9px; font-weight:700; text-transform:uppercase;
                  letter-spacing:.1em; color:#5C5C5C; margin-bottom:4px; }
.drill-kpi-value{ font-size:20px; font-weight:700; color:#000; }
```

The `3px` red left border is the drill-down's own signature — a miniature of the hero's red rule, rotated 90°.

**Trend indicators / comparison text / sparklines.** There are **no arrows, no percentage deltas, and no period-over-period comparisons anywhere in this dashboard**. This is a deliberate and important property: the board reports *current state against thresholds*, not *change over time*. The `.sub` line ("3+ red flags") states the **rule that produced the number**, not a trend.

The sparkline role is filled instead by the **per-row mini radar** — a 58px, six-axis shape that gives an at-a-glance profile of *where* a client's risk sits, not how it moved.

**Positive / negative / neutral treatment.** Negative → `#DB0011`. Warning → `#996300`. Neutral and positive → black or `#5C5C5C`. Green (`#1C5C35`) is used **only** inside pills, discovery tags, and the pri-0 mini radar — never as a KPI value colour.

### Charts

**Chart types.** Exactly one family: **radar / spider charts**. There are no bars, lines, pies, donuts, areas, or scatter plots in the entire dashboard. This single-chart-type discipline is central to the identity.

**Main radar (`#mainRadar`)** — exact geometry from the JS:

```js
const CX = 200, CY = 200, R = 160;              // centre and outer radius
// viewBox="-35 -35 470 470"  → 35px of bleed on every side for axis labels
// CSS: width:100%; max-width:400px; aspect-ratio:1/1

// Six axes, first spoke pointing straight up:
const angle = (Math.PI * 2 * i) / 6 - Math.PI / 2;
// Value → radius, hard-clamped to 0..100:
const rr = (Math.max(0, Math.min(100, v)) / 100) * R;
```

- **Axes (6, fixed):** `M&A / news`, `Debt / news`, `RCF / util.`, `<12m / debt`, `12–24m / debt`, `Bond / vs call`
- **Rings:** polygons at `25, 50, 75, 100`. The `100` ring uses `.radar-grid-outer` (`#C9C9C9`, `1.2px`); the inner three use `.radar-grid` (`#E2E2E2`, `1px`). Weighting the outermost ring is what makes the chart read as a closed container.
- **Spokes:** `#D8D8D8`, `1px`, `stroke-dasharray:4 4` — dashed so they recede behind the data.
- **Axis labels:** placed at `R + 26` px from centre, `text-anchor:middle`, `dominant-baseline:middle`. The sub-label sits `+12px` below its label. Two-line labels (name + qualifier) are what let 6 axes fit without collision.
- **Series:** `fill` path + `stroke` path + a `circle r=3.5` at every vertex. Stroke `2.4px`, rising to `3px` when active.
- **Maximum three series overlaid.** `top3()` returns `sortClients(clients).filter(c => priority(c) >= 2).slice(0, 3)` — only *flagged* clients ever appear, and never more than three.

**Mini radar (`.mini-radar`)** — the in-row glyph:

```js
const r = 22, cx = 28, cy = 28;   // viewBox="0 0 56 56", rendered 58×58 CSS
```

- One grid polygon only (the 100 ring), `stroke-width:.8`, `#D8D8D8`
- Fill + stroke, `stroke-width:1.5`, coloured by **row priority** — not by series index
- `aria-hidden="true"` (correct: the numbers beside it carry the same information)
- Cell is `84px` wide, `padding:10px 8px`, centred

**Axis styling.** No numeric tick labels on the rings. The scale is communicated in prose instead ("the outer edge means *fully red*"), which is only defensible because every axis is normalised to the same 0–100 concern scale.

**Gridlines.** Two-tier: dashed spokes and solid rings, both ≤ `1.2px`, all in the `#D8D8D8`–`#E2E2E2` band. Gridlines never approach the darkness of the data.

**Legend placement.** Right of the chart, in the prose column, as a vertical stack of clickable `.legend-item` rows — not a conventional inline key. Each row is `[18px colour line] [client name] [flag counts]`:

```css
.legend-item{ display:grid; grid-template-columns:18px 1fr auto; gap:12px;
              align-items:center; padding:12px 14px; border:1px solid #D7D7D7;
              border-radius:12px; background:#F8F8F8; cursor:pointer; transition:all .15s ease; }
.legend-line{ width:18px; height:4px; border-radius:999px; }
```

**The legend is the primary interaction surface for the chart.** `mouseenter` on a legend row calls `buildMainRadar(active, idx)`, which adds `.radar-shape-active` to the hovered series and `.dim` (`opacity:.22`) to the rest, while `.legend-item.dimmed` (`opacity:.45`) fades the sibling rows. `mouseleave` restores. This is *focus-plus-context* highlighting, and it is the reason three overlapping translucent shapes remain readable.

**Tooltips.** No custom tooltip component exists. The only tooltip is a native `title` attribute on each signal cell: `title="${cell.v} ${cell.l}"` (e.g. `"60% drawn"`). *Inferred rule:* if a real tooltip is ever needed, it should be a white card, `1px solid #D7D7D7`, `radius:10px`, `12px` text, `--shadow` — never a dark tooltip, which would clash with the light surface system.

**Data labels.** None on the radar. The chart shows *shape*; the table beside it carries the numbers. This division of labour is the core visualisation principle of the board.

**Highlighting rules.** Emphasis is achieved by **dimming everything else**, never by brightening the target: `.dim{opacity:.22}` on shapes, `.dimmed{opacity:.45}` on legend rows, `.radar-shape-active` merely thickens the stroke from `2.4` → `3`.

**Empty state.** `renderTop3()` handles zero flagged clients explicitly: it draws an empty grid via `buildMainRadar([])` and writes `<div class="legend-item"><div class="legend-name">No flagged clients</div></div>`. **The axes and rings remain drawn** — the frame persists so the reader sees an empty chart, not a broken one.

### Tables

**Header:**

```css
thead th{ background:#111111; color:#fff; padding:14px 12px;
          text-align:left; vertical-align:bottom;
          font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.06em;
          border-right:1px solid rgba(255,255,255,.08); white-space:nowrap; }
thead th:last-child{ border-right:none; }
thead th.num{ text-align:center; }
thead .group-market{ background:#1E1E1E; }
```

The header is a **near-black band** — the single darkest element on the page, and the visual anchor of the lower half. `vertical-align:bottom` is what aligns single-line and two-line headers along their baselines.

**Two-tier column headers.** Each `th` may carry a 9px `.group-label` in `rgba(255,255,255,.62)` naming the *data source*, above the column's own name:

```html
<th class="num"><span class="group-label">Internal · Carm</span>RCF utilisation</th>
```

Groups in use: `Signal shape`, `External news` (×2), `Internal · Carm`, `Internal · Carm + BBG` (×2), `Market · Bloomberg`. The Bloomberg column additionally gets `.group-market` (`#1E1E1E`) — **provenance is encoded in the chrome**, so a reader always knows whether a number came from inside the bank or outside it. Carry this forward.

**Rows:**

```css
tbody tr{ border-bottom:1px solid #D7D7D7; transition:background .12s ease; cursor:pointer; }
tbody tr:hover   { background:#FCF4F5; }
tbody tr.selected{ background:#FFF1F3; }
tbody td{ border-right:1px solid #D7D7D7; vertical-align:middle; padding:0; }
tbody td:last-child{ border-right:none; }
```

**No zebra striping.** Separation comes from a full 1px grid — both row *and* column dividers — which suits a dense numeric matrix better than alternating fills (and is required here, since the signal cells already own their background colour).

**`tbody td` has `padding:0`.** All padding lives on an inner `div` (`.client-cell`, `.signal`, `.action-cell`, `.mini-radar-cell`). This is deliberate and load-bearing: it lets `.signal` paint its pill colour edge-to-edge across the entire cell. **Do not add padding to `td` — it will leave white gutters inside the coloured cells.**

**Cell padding (on the inner div):** `.client-cell` `16px` (min-width `240px`) · `.signal` `16px 10px` (min-width `110px`) · `.action-cell` `16px` (min-width `110px`) · `.mini-radar-cell` `10px 8px` (width `84px`).

**Alignment.** Client → left. Mini radar → centre. All six signal cells → centre. Action → right. Drill-table numerics → right (`.drill-table .num{text-align:right}`).

> Note a genuine inconsistency in the source: the **main** table centres its numeric `.signal` cells (`thead th.num{text-align:center}`), while the **drill** table right-aligns its numerics. Both are internally consistent. The main table's values are short, mixed-format tokens (`4`, `60%`, `€450m`, `+2.1`) that centre well under a centred header; the drill table's are comparable currency figures that should align on their last digit. *Recommendation for new tables:* centre categorical/threshold tokens, right-align true magnitudes.

**Status indicators.** The signal cell is itself the indicator — a full-bleed coloured cell, not a badge inside a white cell:

```css
.signal{ padding:16px 10px; text-align:center; font-size:13px; font-weight:700;
         line-height:1.1; min-width:110px; }
.signal small{ display:block; margin-top:4px; font-size:10px; font-weight:700;
               color:inherit; opacity:.72; text-transform:uppercase; letter-spacing:.05em; }
.signal.red  { background:#FDE7EA; color:#8F0010; }
.signal.amber{ background:#FFF2DB; color:#7A5500; }
.signal.green{ background:#E7F5EC; color:#1C5C35; }
.signal.grey { background:#EFEFEF; color:#666666; }
```

Every cell carries **value + unit label** (`60%` / `drawn`), so meaning never rests on colour alone. `color:inherit` on the `small` keeps the unit tied to its pill's text colour.

**The priority bar.** A `4px × 36px` rounded bar at the left of every client name, colour-coded by computed priority — a row-level severity rail:

```css
.priority-bar{ width:4px; min-width:4px; height:36px; border-radius:999px;
               margin-top:2px; background:#D0D0D0; }
tr.pri-3 .priority-bar{ background:#DB0011; }
tr.pri-2 .priority-bar{ background:#996300; }
tr.pri-1 .priority-bar{ background:#777777; }
```

**Sorting / filtering indicators.** There are none, because the table is **not user-sortable**. Order is imposed by `sortClients()`, a fixed cascade: `priority` desc → `red` count desc → `amber` count desc → `name` A–Z. The most urgent client is always row one. Filtering state lives entirely in the chip row above the table.

**Empty state.** `<tr class="empty-row"><td colspan="9">No clients match the current search and filters.</td></tr>`, styled `padding:28px; text-align:center; color:#5C5C5C; font-style:italic`. *Italic + slate + centred* is this system's universal empty-state signature.

### Filters and Controls

**Search input:**

```css
.search-box{ border:1px solid #B8B8B8; background:#fff; border-radius:999px;
             padding:10px 16px; font-size:14px; min-width:280px; color:#333; }
.search-box:focus{ outline:none; border-color:#DB0011; }
```

`type="search"`, `autocomplete="off"`, placeholder `"Type a company name…"`, with an uppercase 11px label above. Filters on every `input` event and resets `page = 1`.

**Filter chips:**

```css
.chip{ border:1px solid #B8B8B8; background:#fff; color:#333;
       padding:9px 13px; border-radius:999px; font-size:12px; font-weight:700;
       cursor:pointer; transition:.15s ease; }
.chip:hover { border-color:#DB0011; color:#DB0011; }
.chip.active{ background:#000000; color:#fff; border-color:#000000; }
```

**Radar toggles:**

```css
.toggle{ appearance:none; border:1px solid #B8B8B8; background:#fff; color:#333;
         padding:10px 14px; border-radius:999px; font-size:12px; font-weight:700;
         text-transform:uppercase; letter-spacing:.06em; cursor:pointer; transition:.15s ease; }
.toggle:hover { border-color:#DB0011; color:#DB0011; }
.toggle.active{ background:#DB0011; color:#fff; border-color:#DB0011; }
```

> **A deliberate distinction, not a bug.** Both controls hover to red, but their **active** fills differ: chips fill **black**, toggles fill **red**. Chips scope *what data you see* (a neutral, additive act); toggles switch *what the chart is about* (the board's primary accent action). Only one toggle group exists, so red stays scarce. Preserve this rule — if you add a second chip group, it fills black; if you add a mode switch, it fills red.

**Primary button (`.mna-run`)** — the only filled-red button on the page:

```css
.mna-run{ appearance:none; border:1px solid #DB0011; background:#DB0011; color:#fff;
          font:700 11px/1 inherit; text-transform:uppercase; letter-spacing:.06em;
          padding:9px 14px; border-radius:999px; cursor:pointer; }
.mna-run:hover   { background:#B1000E; }
.mna-run:disabled{ opacity:.5; cursor:not-allowed; }
```

**Select controls** — the one place the system abandons the pill:

```css
.mna-field select{ border:1px solid #D7D7D7; border-radius:10px; background:#fff;
                   color:#333; font:600 12px/1 inherit; padding:7px 10px; cursor:pointer; }
.pg-size{ border:1px solid #B8B8B8; border-radius:8px; padding:8px 10px;
          font-size:12px; font-weight:700; background:#fff; color:#333; }
```

**Radius encodes affordance:** `999px` = a thing you toggle or type into (chip, toggle, search, button, status pill). `8–10px` = a thing that opens a menu or steps a value (select, pager button). Never round a `<select>` to a pill.

**Pager buttons:**

```css
.pg-btn{ border:1px solid #B8B8B8; background:#fff; color:#333;
         padding:8px 12px; border-radius:8px; font-size:12px; font-weight:700; cursor:pointer; }
.pg-btn:hover:not(:disabled){ border-color:#DB0011; color:#DB0011; }
.pg-btn:disabled{ opacity:.4; cursor:not-allowed; }
```

Note `:hover:not(:disabled)` — disabled buttons correctly refuse the hover treatment.

**Status pill (`.mna-status`)** — a four-state indicator driven by `data-tone`:

```css
.mna-status{ font-size:11px; font-weight:700; letter-spacing:.04em; padding:5px 10px;
             border-radius:999px; border:1px solid #D7D7D7; background:#F8F8F8;
             color:#5C5C5C; white-space:nowrap; }                       /* idle    */
.mna-status[data-tone="busy"]   { background:#FFF2DB; color:#7A5500; border-color:#ECCF95; }
.mna-status[data-tone="success"]{ background:#E7F5EC; color:#1C5C35; border-color:#BFE3CC; }
.mna-status[data-tone="error"]  { background:#FDE7EA; color:#8F0010; border-color:#F0C2C9; }
```

This reuses the pill palette but adds a **1px border at a mid-tone between bg and text** — a refinement the table pills lack. Use this pattern for any standalone status chip.

**Disabled/hover/focus.** Disabled is expressed twice, at two opacities: `.4` for pager buttons, `.5` for the agent button. *Recommendation:* standardise on `.45`. Focus is addressed only on `.search-box` (see §11).

### Navigation

No sidebar and no top nav. The `.topbar` is an identity-and-context bar, not a navigation bar:

- **Left:** logo lockup → `1px` left-border divider → red kicker (`LM Banking · Client Signals`) + 18px title (`Weekly conversation dashboard`)
- **Right:** `.guide-link` ("How it works ↗", red, 700, with a transparent `border-bottom` that turns red on hover) · a middot separator · `Refreshed <strong id="refreshText">`

**Active item style.** The nearest equivalents are `.chip.active` (black fill) and `.toggle.active` (red fill).

**Icon/text relationship.** No icons in navigation. The only glyphs anywhere are typographic: `↗` `‹` `›` `×` `⟳` `—` `·`.

**Collapse/expand.** The `.drill` panel is the only expandable region: `display:none` → `.drill.open{display:block}`, opened by row click and closed by `#drillClose` or by re-clicking the same row (`if(openDrillName === client.name) closeDrill(); else openDrill(client);`). On open it calls `scrollIntoView({behavior:'smooth', block:'start'})`.

**Section grouping.** Filters are grouped under 10px uppercase `.grp-label`s (`Status`, `Signal`); the drill-down is grouped under 16px `.drill-section-title`s (`RCF portfolio`, `Maturing loan positions`, `M&A news (Refinitiv)`).

---

## 7. Iconography

**There is no icon set.** No SVG icon sprite, no icon font, no `<i>` elements, no external icon library — consistent with the file's self-contained, zero-CDN constraint (the source comments this explicitly: *"Self-contained HSBC wordmark (no external image / CDN)"*).

**Every glyph is a Unicode character in the type stream:**

| Glyph | Char | Use | Role |
|---|---|---|---|
| External link | `↗` | "How it works ↗" | Functional |
| Row action | `→` | "View →" | Functional |
| Prev / Next | `‹` `›` | Pager buttons | Functional |
| Close | `×` | "Close ×" on the drill | Functional |
| Refresh / run | `⟳` | "⟳ Count M&A news · Refinitiv" | Functional |
| Separator | `·` | Middots throughout | Decorative |
| No data | `—` (em dash) | Every empty value | **Status** |
| Currency | `€` | Signal values | Semantic |

**Stroke or fill treatment.** Not applicable — glyphs inherit the text face and `font-weight:700` from their parent. There is no stroke/fill vocabulary to maintain.

**Size and colour.** Glyphs are exactly the size and colour of the label they sit inside (`11–12px`, `#DB0011` in links, `#333333` in buttons). They never receive their own colour.

**Non-typographic visual indicators.** Three, and all three are geometry rather than icons:

1. **`.priority-bar`** — a `4×36px` red/ochre/grey rail (row severity)
2. **`.swatch`** — a `16×16px` `4px`-radius square in the colour legend
3. **`.legend-line`** — an `18×4px` `999px`-radius bar (chart series key)

**Relationship between icons and labels.** Glyphs are always **suffixed or prefixed to a full text label**, never standalone. There is not a single icon-only control in the dashboard. Preserve this: an icon-only button would be the first element in the system with no accessible name.

**Rule for new work.** Do not introduce an icon library. If a new affordance needs a mark, first try a Unicode glyph appended to a text label; if that fails, use an inline SVG at `currentColor`, `1.5px` stroke, `16px`, and still keep the text label.

---

## 8. Data Visualization Rules

### Recommended chart colours

**Overlay series (ordered, maximum 3):**

| Slot | Stroke | Fill |
|---|---|---|
| 1 | `#DB0011` | `rgba(219,0,17,.20)` |
| 2 | `#111111` | `rgba(0,0,0,.14)` |
| 3 | `#996300` | `rgba(153,99,0,.18)` |

Fill opacity descends `.20 → .18 → .14` as the stroke darkens — so the three translucent shapes stack to roughly equal visual weight. Preserve the ordering: **series 1 is always red**, because series 1 is always the most-flagged entity.

**Never exceed three overlaid series.** If you need more categories, facet into small multiples (as the mini radars already do) rather than adding a fourth colour.

**Priority/severity colours (unordered, semantic):** critical `#DB0011` → watch `#996300` → low `#777777` → quiet `#1C5C35` / `#D0D0D0`.

### Positive vs. negative trends

This dashboard **does not show trends**, and that is a rule to inherit, not an omission to correct. It shows **current state against thresholds**. There are no arrows, deltas, or period comparisons anywhere.

- **Negative / concerning** → red `#DB0011` (or the `#FDE7EA` / `#8F0010` pill)
- **Cautionary** → ochre `#996300` (or the `#FFF2DB` / `#7A5500` pill)
- **Positive / benign** → green pill `#E7F5EC` / `#1C5C35`, or simply **the absence of colour**
- **Unknown** → grey pill `#EFEFEF` / `#666666` + an em dash `—`

If a future board genuinely needs deltas, express them as `▲ +2.1` / `▼ −0.4` in the same red/ochre/green semantics, always with a sign character so the direction survives greyscale printing.

### Highlighting key values

**Dim the context; never brighten the target.** This is the board's governing emphasis rule.

```css
.radar-shape           { transition:opacity .18s ease; }
.radar-shape.dim       { opacity:.22; }   /* non-focused series */
.legend-item.dimmed    { opacity:.45; }   /* non-focused legend rows */
.radar-shape-active .stroke { stroke-width:3; }  /* 2.4 → 3, the only "brightening" */
```

Secondary emphasis techniques, in order of preference: (1) colour the *value* while the label stays slate (`.stat .value.red`); (2) add a `3px` red left border (`.drill-kpi`); (3) add a `6px` red top rule (`.hero-card::before`); (4) wrap in `<strong>` to promote `#5C5C5C` → `#000000`. Never use bold-plus-colour-plus-size simultaneously.

### Avoiding clutter

- **One chart type per board.** This dashboard uses radar and nothing else.
- **No numeric tick labels** on radar rings. Explain the scale once in prose.
- **No data labels on the chart.** Put the numbers in the adjacent table. *The chart is for shape; the table is for value.*
- **Gridlines stay under `1.2px` and inside the `#D8D8D8`–`#E2E2E2` band.** Spokes are dashed (`4 4`) so they recede.
- **No chart titles inside the SVG.** The `.eyebrow` + `.radar-title` above it serve that role.
- **Cap article/row lists.** The agent caps stored articles at `MNA_MAX_ARTICLES = 25`.

### Labelling conventions

- Axis labels are **two lines**: a 10px uppercase name (`#666666`) and a 9px lowercase qualifier (`#888888`) — e.g. `RCF` / `util.`. This is what allows six axes on a 400px chart without collision.
- Every signal cell shows **value + unit** (`€450m` + `maturing`), never a bare number.
- Every KPI shows **label + value + rule** (`Critical` / `7` / `3+ red flags`). The third line states *the threshold that produced the number* — this is the board's most transferable labelling idea.
- Column headers state **provenance** above name (`Internal · Carm` / `RCF utilisation`).
- Ranges use en dashes (`12–24m`, `1–2 red flags`, `10–15 minutes`); separators use middots (`·`).
- Currency is written compactly: `€450m`, not `€450,000,000`.

### Legends and annotations

- The **series legend** sits beside the chart as interactive rows carrying the series colour, the entity name, and its flag counts (`4 red · 2 amber`) — a legend that doubles as a data table and a hover control.
- The **colour legend** (`.colour-legend`) is a separate horizontal strip directly above the table, defining all four pill states in plain English: *"Red — clear trigger"*, *"Amber — worth a glance"*, *"Green — nothing to flag"*, *"Grey — no data"*.

**Both legends spell out the semantics in words.** A future board must not ship a colour scale without this strip.

Annotation is prose, not callouts: the `.notes-card` explains *how to read the shape*, *how to drill in*, and *what a red cell does and does not mean*. Budget a three-note explainer block on every board.

### Comparing categories, time series, proportions, rankings

| Task | Rule in this system |
|---|---|
| **Categories** | Radar axes — but only when all categories share one normalised 0–100 scale. Never a categorical colour ramp. |
| **Time series** | Not supported, by design. If unavoidable, use a single-series line in `#DB0011` on `#E2E2E2` gridlines; never overlay more than 3. |
| **Proportions** | Expressed as a **number plus its unit** (`60%` / `drawn`), colour-coded by threshold. No pies, no donuts, no stacked bars. |
| **Rankings** | The table *is* the ranking. Sort deterministically (`priority → red → amber → name`), never let the user re-sort, and mark rank with the `4px` priority bar. Top-N overlays cap at 3. |

### Null, missing, and zero values

Rigorously distinguished — this is one of the board's strongest conventions:

| State | Presentation |
|---|---|
| **No data** | Grey pill `#EFEFEF` / `#666666` + `—` (em dash). `normS()` maps any unknown code to `'grey'`; `hasRcf()` / `hasDebt()` treat `'—'` and `'grey'` as absent. |
| **Zero, meaningful** | The number `0` in a **green** pill (e.g. `0%` / `undrawn`) — zero draw is *good news*, not missing data |
| **Not yet fetched** | Stays grey; the source comments *"batch failed → those clients stay grey 'pending'"* |
| **Empty table** | Italic slate centred row: *"No clients match the current search and filters."* |
| **Empty drill section** | `.drill-empty` — italic slate centred on `#F8F8F8`, `radius:10px`, `padding:18px` |
| **Empty chart** | Axes and rings still drawn; legend reads *"No flagged clients"* |
| **Un-run agent** | *"Run 'Count M&A news · Refinitiv' to populate."* |

**Never render a missing value as `0`, and never render a real `0` in grey.** Grey means *we do not know*; green `0` means *we know, and it is fine*.

### Data integrity rule (carried from the agent code)

`applyMnaResult()` re-validates every model-returned field before it touches the DOM: links must match `/^https?:\/\//i`, headlines must be non-empty, counts are coerced with `Math.max(0, Math.round(…))`, and the displayed count is `Math.max(reportedCount, articles.length)`. The source comments this: *"Deterministic re-validation — never trust raw model output."* Any future AI-populated cell must pass through the same gate, and every rendered string must go through `mnaEsc()`.

---

## 9. Spacing and Sizing

### The spacing scale

Spacing is **not** a strict 4px or 8px scale. It is a 2px-quantised scale with a strong preference for even numbers, clustering at:

`4 · 6 · 8 · 10 · 12 · 14 · 16 · 18 · 20 · 22 · 24 · 26 · 28`

Values `≥ 12px` dominate structural spacing; `4–10px` handle intra-component gaps. `14px`, `18px`, `22px` and `26px` all appear, so a pure 8px grid would misrepresent it.

### Margin and padding patterns

| Context | Value |
|---|---|
| Page padding | `24px` → `14px` @720 |
| Standard card padding | `24px` (`.panel`, `.drill`, `.notes-card`) |
| Hero card padding | `28px 28px 26px` (note the 2px optical bottom correction) |
| Stats card padding | `22px` |
| Topbar padding | `16px 20px` → `14px` @720 |
| Agent bar padding | `12px 16px` |
| Nested tile padding | `16px` (`.stat`, `.note`) · `10px 14px` (`.drill-kpi`) · `12px 14px` (`.legend-item`) |
| Table cell padding | `0` on `<td>`; `16px` / `16px 10px` / `10px 8px` on the inner div |
| Table header padding | `14px 12px` |
| Drill table padding | `10px 12px` (th) · `9px 12px` (td) |
| All cards @720px | `18px` |

### Gaps between cards

- **`20px`** — the canonical gutter, used for `margin-bottom` on every major card *and* as the `gap` inside `.hero` and `.notes-grid`
- **`16px`** — `.mna-bar`, `.colour-legend` margin-bottom
- **`12px`** — `.controls`, `.table-card` margin-bottom (tight coupling)
- **`28px`** — `.radar-layout` gap (the widest gap on the page; separates chart from prose)
- **`14px`** — `.stats-card` internal gap
- **`12px`** — `.drill-kpis` gap
- **`8–10px`** — control clusters (`.filters`, `.toggle-row`, `.pager-controls`, `.radar-legend`)
- **`18px`** — `.topbar-left` gap; `.colour-legend` gap

### Section spacing

`margin-bottom` on the preceding block: `20px` between cards, `24px` between `.drill-section`s (with `:last-child{margin-bottom:0}`), `14px` under `.drill-section-title`, `10px` under `.eyebrow`, `12px` under `.hero h1`.

### Border radius values

| Value | Applied to |
|---|---|
| `999px` | Pills: chips, toggles, search box, `.mna-run`, `.mna-status`, `.priority-bar`, `.legend-line` |
| `16px` (`--radius`) | Primary cards; `.radar-shell` |
| `14px` | `.topbar`, `.mna-bar`, `.stat`, `.note` |
| `12px` | `.legend-item`, `.source-strip` |
| `10px` | `.drill-kpi`, `.drill-empty`, `.mna-field select` |
| `8px` | `.pg-btn`, `.pg-size`, `.drill-close` |
| `4px` | `.swatch` |

**Radius is a depth and affordance signal**, not decoration: outer card `16px` → chrome/nested `14px` → sub-tile `10–12px` → button `8px`; and `999px` for anything toggled or typed into.

### Common component heights

| Component | Height |
|---|---|
| Logo mark | `32px` (× `64px` wide) |
| `.stat` tile | `min-height:110px` |
| `.radar-shell` | `min-height:440px` |
| `#mainRadar` | `max-width:400px`, `aspect-ratio:1/1` |
| `.mini-radar` | `58 × 58px` (in an `84px` cell) |
| `.priority-bar` | `36 × 4px` |
| `.legend-line` | `4 × 18px` |
| `.swatch` | `16 × 16px` |
| `.hero-card::before` / `.notes-title` rule | `6px` |
| `.drill-kpi` left border | `3px` |
| Chip *(computed)* | ≈ `31px` (9px padding + 12px text + 2px border) |
| Toggle *(computed)* | ≈ `33px` |
| Pager button *(computed)* | ≈ `29px` |
| Search box *(computed)* | ≈ `37px` |
| Table row *(computed)* | ≈ `70px` (16px + 17px name + 4px + 11px sub + 16px) |

### Dashboard density

**Medium-high.** Cards are airy (24–28px padding, 20px gutters) but the table is dense (~70px rows carrying nine columns across a 1200px minimum). Density is concentrated where the work happens and relaxed everywhere else.

### Header / sidebar dimensions

- **Header:** not fixed. `.topbar` height is content-driven — `16px + max(32px logo, ~44px desk-meta) + 16px` ≈ **`76px`**, plus a `20px` bottom margin. It is a card in the flow, **not sticky or fixed**.
- **Sidebar:** none.
- **Chart rail:** `480px` fixed (`.radar-layout` column 1).
- **Notes rail:** `260px` fixed (`.notes-grid` column 1).
- **Max content width:** `1600px`.

### Aspect ratios

- Logo: **2:1** (`64×32`; native `1132×566`)
- Main radar: **1:1** (`aspect-ratio:1/1`, enforced in CSS)
- Mini radar: **1:1** (`viewBox="0 0 56 56"`)
- Hero split: **1.3 : 0.9** ≈ 59% / 41%
- Radar panel split: `480px` : fluid
- Notes: `260px` : `1fr` : `1fr`

### Shadow and motion

One shadow token only — `--shadow: 0 8px 24px rgba(0,0,0,.06)` — applied to cards, topbar, and the agent bar. Nothing else casts a shadow: no hover elevation, no modal scrim, no dropdown shadow.

Transition durations, all `ease`:

| Duration | Applied to |
|---|---|
| `.12s` | `tbody tr` background |
| `.15s` | `.chip`, `.toggle`, `.legend-item` (`transition:all`) |
| `.18s` | `.radar-shape` opacity |

Nothing animates for longer than **180ms**. No transforms, no scale, no translate, no keyframes anywhere.

---

## 10. Interaction and State Styling

| State | Treatment |
|---|---|
| **Hover — table row** | `background:#FCF4F5`, `transition:background .12s ease`, `cursor:pointer` |
| **Hover — chip / toggle** | `border-color:#DB0011; color:#DB0011` (border + text only; fill unchanged) |
| **Hover — legend item** | `border-color:#B5B5B5; background:#FFFFFF` (lifts off the `#F8F8F8` tile) + dims all sibling rows to `.45` and all non-hovered radar shapes to `.22` |
| **Hover — pager button** | `:hover:not(:disabled)` → red border + red text |
| **Hover — primary button** | `background:#B1000E` (red darkens; no lift, no shadow) |
| **Hover — action / guide link** | A transparent `border-bottom` becomes `#DB0011` (2px on `.action-link`, 1px on `.guide-link`) — an underline that grows in place, so text never shifts |
| **Hover — drill close** | `color:#DB0011; border-color:#DB0011` |
| **Selected — table row** | `background:#FFF1F3` (one step warmer than hover) |
| **Selected — radar series** | `.radar-shape-active` → `stroke-width:2.4 → 3`, `fill opacity:1`; all others `.dim{opacity:.22}` |
| **Active — chip** | `background:#000000; color:#fff; border-color:#000000` |
| **Active — toggle** | `background:#DB0011; color:#fff; border-color:#DB0011` |
| **Disabled** | `.pg-btn:disabled{opacity:.4; cursor:not-allowed}` · `.mna-run:disabled{opacity:.5; cursor:not-allowed}` — *standardise on `.45`* |
| **Loading** | Amber `.mna-status[data-tone="busy"]` reading *"Querying Refinitiv…"*, a live `#mnaProg` counter (`"12 / 40 companies"`), and the trigger button disabled. **No spinner, no skeleton, no overlay** — the UI stays interactive and re-renders incrementally as each batch lands (`renderStats(); renderRadar(); renderTable();` inside the worker loop). |
| **Empty** | Italic + `#5C5C5C` + centred. Table: `padding:28px`. Drill: `.drill-empty` on `#F8F8F8`, `radius:10px`, `padding:18px`. Chart: axes retained, legend reads *"No flagged clients"*. |
| **Error** | Red `.mna-status[data-tone="error"]` reading *"Done with some errors"*. Errors are **non-fatal and per-batch**: a failed batch leaves its clients grey/pending and the rest of the board renders normally. There is no error modal, banner, or toast. |
| **Success** | Green `.mna-status[data-tone="success"]` reading *"Done · N companies"* or *"Up to date (180d)"* |
| **Warning** | Amber pills and the ochre `#996300` accent |
| **Focus** | Only `.search-box:focus{outline:none; border-color:#DB0011}`. Every other control relies on the UA default ring. **See §11 — this is the board's principal accessibility gap.** |
| **Snapshot mode** | `window.__SNAPSHOT_MODE || navigator.webdriver` → agent button disabled, status reads *"Snapshot mode"*. Live-data controls must degrade gracefully when the board is being screenshotted. |

**The interaction philosophy.** Every state change is a **colour or opacity change**, never a geometry change. Nothing moves, scales, lifts, or reflows on hover — a deliberate choice for a dense table where any shift would cost the reader their place. The one motion in the file is `scrollIntoView({behavior:'smooth'})` when the drill panel opens.

---

## 11. Accessibility Considerations

### Text contrast — measured against WCAG 2.1 AA

| Pair | Ratio | Verdict |
|---|---|---|
| `#333333` on `#FFFFFF` | ≈ 12.6:1 | ✅ Passes AAA |
| `#5C5C5C` on `#FFFFFF` | ≈ 7.0:1 | ✅ Passes AAA |
| `#5C5C5C` on `#F8F8F8` | ≈ 6.6:1 | ✅ Passes AAA |
| `#DB0011` on `#FFFFFF` | ≈ 5.2:1 | ✅ Passes AA (normal text) |
| `#FFFFFF` on `#111111` | ≈ 18.9:1 | ✅ Passes AAA |
| `#8F0010` on `#FDE7EA` | ≈ 8.6:1 | ✅ Passes AAA |
| `#7A5500` on `#FFF2DB` | ≈ 6.9:1 | ✅ Passes AAA |
| `#1C5C35` on `#E7F5EC` | ≈ 6.8:1 | ✅ Passes AAA |
| `#666666` on `#EFEFEF` | ≈ 5.0:1 | ✅ Passes AA |
| `#666666` on `#FFFFFF` (radar axis label) | ≈ 5.7:1 | ✅ Passes AA |
| **`#888888` on `#FBFBFB`** (radar axis sub-label, 9px) | **≈ 3.5:1** | ❌ **Fails AA** |
| **`.signal small` at `opacity:.72`** (10px) | e.g. `#8F0010`@72% on `#FDE7EA` ≈ **4.4:1** | ⚠️ **Borderline; fails for `#666666`@72% on `#EFEFEF` ≈ 2.9:1** |

*Ratios computed from the declared hex values; the two failures are the only ones in the system.*

**Fixes that preserve the style:**

1. `.radar-axis-label-sub{ fill:#767676; }` — the lightest grey that clears 4.5:1 on white. Visually near-identical to `#888888`.
2. Remove `opacity:.72` from `.signal small` and instead set explicit per-state colours one step lighter than the value text (e.g. `.signal.grey small{ color:#5A5A5A; }`). Opacity on small text is the single most common contrast regression in this codebase's pattern.

### Colour contrast concerns beyond text

- **Priority bar is colour-only.** A `4px` rail encoding critical/watch/low/quiet, with no text or shape alternative. It is *redundant* with the signal pills, so this is acceptable — but never let it become the sole carrier of severity.
- **`#996300` (ochre) vs `#DB0011` (red)** are distinguishable in protanopia/deuteranopia (they differ strongly in lightness: L≈45 vs L≈40 with very different hue angles), but red-vs-green in the pills is the classic risk. **Mitigated** by the value+unit text inside every pill and by the `.colour-legend` naming each state in words.
- **Radar series 1 (red) and series 3 (ochre)** are the closest pair. They are separated by stroke colour *and* by legend order *and* by the dim-on-hover interaction. Adding a `stroke-dasharray` to series 3 would make greyscale printing unambiguous.

### Font readability

The board runs **eleven type sizes between 9px and 12px**. Sizes `9px` (`.disc-tag`, `.group-label`, `.drill-kpi-label`, `.drill-table th`, `.radar-axis-label-sub`) and `10px` (`.signal small`, `.radar-axis-label`, `.grp-label`) are below the 12px floor most enterprise standards set for sustained reading. They are all uppercase, `700`, and widely tracked — which helps — and they are all *labels*, never content. **Rule: nothing below 12px may carry information not also available at ≥12px.** The current file honours this; keep it.

### Touch / click target size

| Control | Approx. height | WCAG 2.5.8 (24px, AA) | WCAG 2.5.5 (44px, AAA) |
|---|---|---|---|
| `.chip` | ≈ 31px | ✅ | ❌ |
| `.toggle` | ≈ 33px | ✅ | ❌ |
| `.pg-btn` | ≈ 29px | ✅ | ❌ |
| `.mna-run` | ≈ 30px | ✅ | ❌ |
| `.search-box` | ≈ 37px | ✅ | ❌ |
| `tbody tr` | ≈ 70px | ✅ | ✅ |
| `.action-link` | ≈ 17px | ⚠️ *(inside a 70px row, so effectively fine)* | — |

All controls clear the 24px AA minimum; none reach 44px. On a touch device, raise chip/toggle vertical padding from `9–10px` to `14px` inside a `@media (pointer:coarse)` block — this changes nothing on desktop.

### Visual hierarchy

Excellent and worth preserving verbatim. Four unambiguous tiers: (1) `54px` hero headline; (2) `36px` KPI values and `34px` radar title; (3) `17px` client names and `13px` signal values; (4) `9–12px` uppercase labels. The `#111111` table header anchors the lower half. The red accent appears rarely enough that every instance reads as intentional.

### Colour alone vs. labels/icons

**Strong.** Every signal pill carries a value and a unit; the colour legend names all four states in prose; KPI tiles state the threshold rule that produced the number; the radar legend lists exact flag counts (`4 red · 2 amber`). Remove all colour from this board and it still functions. That is the standard to hold new pages to.

### Keyboard and focus visibility — the real gaps

1. **`.search-box{outline:none}`** replaces the focus ring with a `1px` red border. A 1px border change is a weak focus indicator and likely fails WCAG 2.4.11 (Focus Appearance). **Fix:**
   ```css
   .search-box:focus-visible{ outline:2px solid #DB0011; outline-offset:2px; border-color:#DB0011; }
   ```
2. **No `:focus-visible` styles exist for `.chip`, `.toggle`, `.pg-btn`, `.mna-run`, or `.drill-close`.** They inherit the UA ring, which is inconsistent across browsers and nearly invisible on the red-filled active toggle. **Fix:** one shared rule —
   ```css
   .chip:focus-visible, .toggle:focus-visible, .pg-btn:focus-visible,
   .mna-run:focus-visible, .drill-close:focus-visible{
     outline:2px solid #DB0011; outline-offset:2px;
   }
   .toggle.active:focus-visible, .mna-run:focus-visible{ outline-color:#000000; }
   ```
3. **Table rows are not keyboard-reachable.** `row.addEventListener('click', …)` on a `<tr>` gives no `tabindex`, no `role`, and no `Enter`/`Space` handler — so the drill-down, the board's primary interaction, is **unreachable by keyboard**. This is the most serious issue in the file. **Fix:** give the row's action link the real behaviour, since `.action-link` ("View →") already exists in every row and is natively focusable — move the handler onto it and leave the `<tr>` click as a convenience shortcut.
4. **No `scope` attributes, no `<caption>`, no `aria-sort`.** Add `scope="col"` to every `<th>` and a visually-hidden `<caption>` naming the table.
5. **The drill-down opens with no focus management.** After `drill.classList.add('open')`, move focus to `#drillTitle` (give it `tabindex="-1"`) and return focus to the originating row on close.
6. **`renderStats()`/`renderTable()` replace DOM silently.** Add `aria-live="polite"` to `#pagerInfo` so screen-reader users hear the result count after filtering, and to `#mnaStatus` so agent progress is announced.

### What the file already does right

- `#mainRadar` carries `aria-label="Client radar"`.
- `.mini-radar` carries `aria-hidden="true"` — correct, since its data is duplicated in the adjacent numeric cells. **This is exemplary:** decorative redundant visualisations should be hidden, not labelled.
- Every `<button>` is a real `<button type="button">`, not a styled `<div>`.
- The search input has a real `<label for="searchBox">`; `#pageSize` has an `aria-label`.
- `.pg-btn:hover:not(:disabled)` correctly suppresses hover feedback on disabled controls.
- The external link uses `target="_blank" rel="noopener"`.
- All agent-supplied strings pass through `mnaEsc()` before reaching `innerHTML`.

### Reduced motion

No `@media (prefers-reduced-motion)` block exists. Transitions are all ≤180ms opacity/colour changes and are harmless, but the `scrollIntoView({behavior:'smooth'})` on drill-open should be gated:

```css
@media (prefers-reduced-motion:reduce){ *{ transition-duration:.01ms !important; } }
```
…and pass `behavior: matchMedia('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth'`.

---

## 12. Do and Don't Guidelines

### Keep consistent

- **One accent.** `#DB0011` for brand, structure, and criticality. `#996300` as the *only* secondary. Everything else is grey, plus semantic green.
- **The card recipe.** `#FFFFFF` · `1px solid #D7D7D7` · `radius:16px` · `box-shadow:0 8px 24px rgba(0,0,0,.06)`. One shadow token, everywhere, forever.
- **The radius ladder.** `16px` card → `14px` chrome/nested → `10–12px` sub-tile → `8px` menu-or-step control → `999px` toggle-or-input.
- **The 20px gutter** between major cards, and `24px` page padding.
- **`700` as the default weight**; `400` reserved for prose; `800` reserved for the wordmark.
- **The tracking curve.** Negative tracking above 28px, none in the middle band, `.06em`–`.1em` uppercase below 12px.
- **Eyebrow → heading.** Every section opens with a 12px red uppercase eyebrow above a black heading.
- **Value + unit in every data cell.** Never a bare number in a coloured cell.
- **Grey + `—` means unknown. Green `0` means known and fine.**
- **Dim the context to highlight the target** (`.22` shapes, `.45` legend rows).
- **Colour is never the only carrier of meaning.**
- **Self-contained.** No CDN, no external fonts, no icon libraries, no remote images. The board must work on a `file://` double-click.

### Avoid

- ❌ **Adding a third hue.** No blue, teal, purple, or categorical rainbow. If you need to distinguish more than three series, facet — don't colour.
- ❌ **Filling a chip red or a toggle black.** Chips fill black (scoping), toggles fill red (mode). Swapping them breaks the affordance grammar.
- ❌ **Adding `padding` to `<td>`.** It is `0` on purpose; the inner div carries it so `.signal` can paint edge-to-edge. Padding on the `td` puts white gutters inside every coloured cell.
- ❌ **Zebra striping the table.** The 1px row+column grid already does that job, and stripes would fight the pill backgrounds.
- ❌ **Hover lift, scale, or translate.** Nothing moves in this design. State changes are colour and opacity only.
- ❌ **A second shadow value.** There is exactly one, and no hover elevation.
- ❌ **Trend arrows and period-over-period deltas.** This board reports state against thresholds, not change over time.
- ❌ **Numeric tick labels or data labels on the radar.** The chart carries shape; the table carries value.
- ❌ **Icon-only buttons.** There is no icon set and no icon-only control anywhere. A glyph always follows a text label.
- ❌ **Green as a KPI value colour.** Good news is the *absence* of colour, not the presence of green.
- ❌ **More than three overlaid radar series.**
- ❌ **`opacity` on small text** — it silently breaks contrast (see `.signal small`).
- ❌ **A red rule on every card.** The 6px bar caps the opening statement and the closing explainer. Two per page, maximum.
- ❌ **`outline:none` without a `:focus-visible` replacement.**
- ❌ **Recolouring, rotating, or rounding the logo.**

### Common mistakes that would break the style

1. **Reaching for a chart library.** Every visual here is hand-built SVG with six lines of trigonometry. A charting library will import its own palette, its own fonts, its own tooltip, and its own gridline greys — and the board will stop looking like itself.
2. **Using `1fr` instead of `minmax(0,1fr)`** for the fluid column beside a fixed chart rail. The 1200px table will blow out the grid.
3. **Letting the KPI `.sub` line become a trend** ("↑ 12% vs last week") instead of the threshold rule that produced the number ("3+ red flags").
4. **Introducing an 8px spacing grid.** The real scale is 2px-quantised and uses `14`, `18`, `22`, `26`. Snapping to 8px will subtly wreck the hero card's `28px 28px 26px`.
5. **Setting `font-family` on a component.** It is declared once on `body`. Re-declaring it will drop the Univers stack. If you must use the `font` shorthand, end it with `inherit` as `.mna-run` does.
6. **Rendering a missing value as `0`.** Grey pill + em dash, always.
7. **Making the table sortable.** The deterministic sort *is* the ranking, and row one is always the client to call first.
8. **Trusting model output straight into `innerHTML`.** Re-validate, clamp, and `mnaEsc()` — as `applyMnaResult()` does.

### Adapting the style to new pages

- **Reuse the shell verbatim:** `.page` (1600px / 24px) → `.topbar` → hero + KPI split → content → `.notes-card` explainer. Swap only the middle.
- **Keep the hero's `1.3fr .9fr` split.** Narrative left, four KPIs right, in a 2×2 grid.
- **Every page gets a `.notes-card`** with a red-ruled title rail and two-to-three notes explaining how to read the page and what its signals do *not* mean.
- **Every page gets a `.source-strip`** — the dashed-border footer naming the data sources and the refresh command. Provenance is part of this design language.
- **Group table columns by data source** using the 9px `.group-label`, and tint any externally-sourced group one step lighter (`#1E1E1E`).

### Adding new charts or cards without breaking consistency

**A new card:** copy the shared recipe, open with a red `.eyebrow`, follow with a black heading, then `#5C5C5C` prose capped at `max-width:720px`, `padding:24px`, `margin-bottom:20px`.

**A new chart:** build it in inline SVG. Gridlines `#E2E2E2` at `1px`; the outermost boundary `#C9C9C9` at `1.2px`; any axis/spoke dashed `4 4` in `#D8D8D8`. Series 1 is `#DB0011`; if a second is needed, `#111111`; a third, `#996300`; there is no fourth. Fill opacity `.14`–`.20`. Vertices `r=3.5`. Give the SVG an `aria-label`; give any redundant decorative variant `aria-hidden="true"`. Put the numbers in a table beside it, not on the chart. Add a plain-English legend strip. Handle the empty case by keeping the frame and writing *"No … clients"* in the legend.

**A new KPI:** `label (11px uppercase slate)` → `value (36px black, or `#DB0011` / `#996300` if it measures risk)` → `sub (12px slate, stating the rule)`. Never green, never an arrow.

**A new control:** pill (`999px`) if it toggles or accepts text; `8–10px` radius if it opens a menu or steps a value. Border `#B8B8B8`, white fill, `12px/700`, hover to red border+text. Active fills black if it scopes data, red if it switches mode. Add a `:focus-visible` outline.

---

## 13. Reusable Design Tokens

All values below are **exact**, lifted from the source. Tokens marked `/* new */` did not exist as custom properties in the original (they were hard-coded literals) and are promoted here so future boards can reference them.

```css
:root{
  /* ── Brand ─────────────────────────────────────────────── */
  --hsbc-red:              #db0011;   /* primary accent; identical to the logo's red */
  --hsbc-red-dark:         #b1000e;   /* primary button hover only */
  --hsbc-ochre:            #996300;   /* new: the sole secondary accent */

  /* ── Neutrals ──────────────────────────────────────────── */
  --hsbc-black:            #000000;   /* headings, KPI values, wordmark */
  --hsbc-charcoal:         #333333;   /* body default */
  --hsbc-slate:            #5c5c5c;   /* muted text, labels, metadata */
  --hsbc-border:           #d7d7d7;   /* card + table borders */
  --hsbc-border-strong:    #b8b8b8;   /* interactive borders */
  --hsbc-bg:               #f3f3f3;   /* page background */
  --hsbc-card:             #ffffff;   /* card surface */
  --hsbc-soft:             #f8f8f8;   /* nested tile surface */

  /* ── Table chrome ──────────────────────────────────────── */
  --table-head-bg:         #111111;                 /* new */
  --table-head-bg-alt:     #1e1e1e;                 /* new: externally-sourced column group */
  --table-head-fg:         #ffffff;                 /* new */
  --table-head-group-fg:   rgba(255,255,255,.62);   /* new */
  --table-head-divider:    rgba(255,255,255,.08);   /* new */
  --row-hover:             #fcf4f5;                 /* new */
  --row-selected:          #fff1f3;                 /* new */

  /* ── Signal pills ──────────────────────────────────────── */
  --pill-red-bg:   #fde7ea;  --pill-red-tx:   #8f0010;
  --pill-amber-bg: #fff2db;  --pill-amber-tx: #7a5500;
  --pill-green-bg: #e7f5ec;  --pill-green-tx: #1c5c35;
  --pill-grey-bg:  #efefef;  --pill-grey-tx:  #666666;

  /* Status-pill borders (mid-tone between bg and text) */
  --pill-amber-br: #eccf95;                         /* new */
  --pill-green-br: #bfe3cc;                         /* new */
  --pill-red-br:   #f0c2c9;                         /* new */

  /* ── Semantic aliases ──────────────────────────────────── */
  --color-background:      var(--hsbc-bg);
  --color-surface-card:    var(--hsbc-card);
  --color-surface-inset:   var(--hsbc-soft);
  --color-primary:         var(--hsbc-red);
  --color-secondary:       var(--hsbc-ochre);
  --color-text-primary:    var(--hsbc-charcoal);
  --color-text-emphasis:   var(--hsbc-black);
  --color-text-muted:      var(--hsbc-slate);
  --color-border-subtle:   var(--hsbc-border);
  --color-border-strong:   var(--hsbc-border-strong);
  --color-success:         var(--pill-green-tx);    /* #1c5c35 */
  --color-warning:         var(--pill-amber-tx);    /* #7a5500 */
  --color-error:           var(--pill-red-tx);      /* #8f0010 */
  --color-neutral:         var(--pill-grey-tx);     /* #666666 */

  /* ── Priority scale ────────────────────────────────────── */
  --priority-3: #db0011;   /* critical — 3+ red flags */    /* new */
  --priority-2: #996300;   /* watch    — 1–2 red flags */   /* new */
  --priority-1: #777777;   /* low      — amber only  */     /* new */
  --priority-0: #d0d0d0;   /* quiet    — no flags    */     /* new */

  /* ── Chart ─────────────────────────────────────────────── */
  --chart-series-1:        #db0011;                 /* new */
  --chart-series-2:        #111111;                 /* new */
  --chart-series-3:        #996300;                 /* new */
  --chart-fill-1:          rgba(219,0,17,.20);      /* new */
  --chart-fill-2:          rgba(0,0,0,.14);         /* new */
  --chart-fill-3:          rgba(153,99,0,.18);      /* new */
  --chart-grid:            #e2e2e2;                 /* new: inner rings */
  --chart-grid-outer:      #c9c9c9;                 /* new: boundary ring, 1.2px */
  --chart-axis:            #d8d8d8;                 /* new: spokes, dasharray 4 4 */
  --chart-label:           #666666;                 /* new */
  --chart-label-sub:       #767676;                 /* new: raised from #888888 for AA */
  --chart-dim-opacity:     .22;                     /* new */
  --chart-stroke:          2.4px;                   /* new */
  --chart-stroke-active:   3px;                     /* new */
  --chart-vertex-r:        3.5px;                   /* new */

  /* ── Typography ────────────────────────────────────────── */
  --font-family-base:      "Univers Next for HSBC Regular","Univers Next for HSBC",
                           "Arial","Helvetica Neue",sans-serif;

  --font-size-display:     54px;   /* hero h1  (42px @1200, 34px @720) */
  --font-size-heading-xl:  34px;   /* radar title */
  --font-size-kpi:         36px;   /* stat value */
  --font-size-heading-lg:  28px;   /* notes h3 */
  --font-size-heading-md:  24px;   /* drill title */
  --font-size-wordmark:    22px;
  --font-size-kpi-sm:      20px;   /* drill kpi value */
  --font-size-heading-sm:  18px;   /* topbar title */
  --font-size-strong:      17px;   /* client name */
  --font-size-body-lg:     16px;   /* subtitle, drill section title */
  --font-size-body:        15px;   /* radar desc, legend name */
  --font-size-body-sm:     14px;   /* note text, search box */
  --font-size-data:        13px;   /* signal value */
  --font-size-label:       12px;   /* eyebrow, chip, toggle, meta */
  --font-size-label-sm:    11px;   /* stat label, th, sector */
  --font-size-micro:       10px;   /* signal unit, axis label */
  --font-size-nano:         9px;   /* group label, disc tag, kpi label */

  --font-weight-regular:   400;    /* prose only */
  --font-weight-medium:    600;    /* .client-geo, select */
  --font-weight-bold:      700;    /* the system default */
  --font-weight-black:     800;    /* wordmark + disc tag only */

  --line-height-display:   1.02;
  --line-height-heading:   1.08;
  --line-height-tight:     1.2;
  --line-height-data:      1.1;
  --line-height-kpi:       1;
  --line-height-body:      1.6;
  --line-height-body-lg:   1.55;
  --line-height-meta:      1.35;

  --tracking-display:      -.03em;  /* ≥ 40px */
  --tracking-heading:      -.02em;  /* 28–39px */
  --tracking-normal:       0;       /* 13–22px */
  --tracking-label:        .06em;   /* ≤ 12px uppercase */
  --tracking-label-wide:   .08em;
  --tracking-eyebrow:      .1em;

  /* ── Spacing (2px-quantised, not an 8px grid) ──────────── */
  --spacing-3xs:            4px;
  --spacing-2xs:            6px;
  --spacing-xs:             8px;
  --spacing-sm:            10px;
  --spacing-md:            12px;
  --spacing-base:          14px;
  --spacing-lg:            16px;
  --spacing-xl:            18px;
  --spacing-2xl:           20px;   /* the canonical card gutter */
  --spacing-3xl:           24px;   /* page + card padding */
  --spacing-4xl:           28px;   /* hero padding; radar-layout gap */

  --gap-card:              20px;
  --gap-section:           20px;
  --gap-tight:             12px;   /* controls → table → pager */
  --padding-page:          24px;   /* → 14px @720 */
  --padding-card:          24px;   /* → 18px @720 */
  --padding-card-hero:     28px 28px 26px;
  --padding-topbar:        16px 20px;

  /* ── Border radius (encodes depth + affordance) ────────── */
  --radius:                16px;   /* primary cards */
  --radius-card:           16px;
  --radius-chrome:         14px;   /* topbar, mna-bar, stat, note */
  --radius-md:             12px;   /* legend item, source strip */
  --radius-sm:             10px;   /* drill kpi, select */
  --radius-xs:              8px;   /* pager button, drill close */
  --radius-swatch:          4px;
  --radius-pill:          999px;   /* chips, toggles, inputs, buttons */

  /* ── Elevation & borders ───────────────────────────────── */
  --shadow:                0 8px 24px rgba(0,0,0,.06);   /* the only shadow */
  --shadow-card:           0 8px 24px rgba(0,0,0,.06);
  --border-card:           1px solid #d7d7d7;
  --border-interactive:    1px solid #b8b8b8;
  --border-dashed:         1px dashed #b8b8b8;           /* source strip */
  --rule-accent:           6px;                          /* red top rule */
  --rule-accent-inset:     3px;                          /* drill-kpi left border */

  /* ── Motion (nothing exceeds 180ms; colour/opacity only) ─ */
  --transition-row:        background .12s ease;
  --transition-control:    .15s ease;
  --transition-shape:      opacity .18s ease;

  /* ── Logo ──────────────────────────────────────────────── */
  --logo-width:            64px;
  --logo-height:           32px;    /* locked 2:1; native 1132×566 PNG */
  --logo-gap:              10px;    /* mark → wordmark */
  --logo-clearspace:       16px;    /* minimum; 18px intended */
  --logo-fit:              contain;

  /* ── Layout ────────────────────────────────────────────── */
  --max-content-width:   1600px;
  --header-height:         76px;    /* content-driven, not fixed or sticky */
  --sidebar-width:          0;      /* no sidebar in this design */
  --chart-rail-width:     480px;
  --chart-max-width:      400px;    /* #mainRadar, aspect-ratio 1/1 */
  --chart-shell-min-h:    440px;
  --notes-rail-width:     260px;
  --table-min-width:     1200px;
  --stat-min-height:      110px;
  --mini-chart-size:       58px;
  --breakpoint-lg:       1200px;
  --breakpoint-sm:        720px;
}
```

---

## 14. Reusable Future Dashboard Prompt

```text
Create a new dashboard using the following visual style:

DESIGN LANGUAGE — HSBC corporate: restrained, institutional, analytical. Achromatic base
(white cards on #f3f3f3, near-black text) with ONE saturated accent, HSBC red #db0011, and
ONE secondary, ochre #996300. Red is never decorative — it signals brand, structure, and
criticality only. No blue, no teal, no categorical rainbow. Self-contained: a single HTML
file with zero CDN, zero external fonts, zero icon libraries, zero remote images; it must
work on a file:// double-click. Operational, not executive: the board answers "who do I
call this week, and why?" Its stance is "a trigger, not a verdict" — signals prompt a
conversation, they do not replace judgement.

LAYOUT — Single centred column, max-width 1600px, 24px page padding (14px under 720px).
No sidebar, no top navigation. Vertical stack: topbar → hero (1.3fr narrative | 0.9fr 2×2
KPI grid, 20px gap) → chart panel (480px fixed chart rail | minmax(0,1fr) prose, 28px gap)
→ controls → table → pager → drill-down → notes explainer. 20px gutter between major cards;
12px where controls/table/pager form one unit. Use minmax(0,1fr), never plain 1fr, beside a
fixed rail. Breakpoints at 1200px (all grids → single column, h1 54→42px, KPI 4-up → 2-up)
and 720px (h1 → 34px, card padding → 18px; the KPI grid stays 2-up).

LOGO — The HSBC hexagon PNG, embedded as a base64 data URI, top-left of the header card at
exactly 64×32px (locked 2:1, object-fit:contain), followed by a 10px gap and a live-text
"HSBC" wordmark at 22px/800/#000. A 1px #d7d7d7 left border with 16px padding separates the
lockup from a red uppercase kicker + 18px title. Keep ≥16px clear space. The mark's white
counter-triangles are opaque, so it is safe on light AND dark backgrounds. Never recolour,
rotate, round, or re-encode it. Header only — never in a footer or repeated in content.

COLOURS — bg #f3f3f3 · card #ffffff · inset #f8f8f8 · border #d7d7d7 · interactive border
#b8b8b8 · text #333333 · emphasis #000000 · muted #5c5c5c · accent #db0011 (hover #b1000e)
· secondary #996300 · table header #111111 (externally-sourced column groups #1e1e1e).
Signal pills: red #fde7ea/#8f0010, amber #fff2db/#7a5500, green #e7f5ec/#1c5c35,
grey #efefef/#666666. Row hover #fcf4f5, selected #fff1f3.

TYPOGRAPHY — "Univers Next for HSBC", Arial, Helvetica Neue, sans-serif, declared once on
body. Weight 700 is the DEFAULT; 400 is reserved for prose; 800 only for the wordmark.
Tracking scales inversely with size: -.03em at 54px, -.02em at 34px, none at 13–22px, and
.06em–.1em uppercase below 12px. Scale: 54 hero / 36 KPI / 34 chart title / 24 drill title
/ 17 row name / 16 subtitle / 13 signal / 12 label / 11 th / 9–10 micro-label. Prose
line-height 1.55–1.6; headings 1.02–1.2; KPI values 1.

COMPONENTS — Cards: #fff, 1px solid #d7d7d7, radius 16px, ONE shadow (0 8px 24px
rgba(0,0,0,.06)), 24px padding. Radius encodes depth: 16 card → 14 chrome/nested → 10–12
sub-tile → 8 menu/step control → 999px anything toggled or typed into. Open every section
with a 12px red uppercase eyebrow above a black heading. Cap the opening hero and the
closing explainer — and only those — with a 6px red rule.
KPI tiles: label (11px uppercase slate) → value (36px black; #db0011 or #996300 only when
it measures risk) → sub (12px slate stating the THRESHOLD RULE that produced the number,
e.g. "3+ red flags"). Never green, never an arrow, never a period-over-period delta.
Table: near-black #111111 header, 11px uppercase, with a 9px .group-label above each column
naming its DATA SOURCE (tint externally-sourced groups #1e1e1e). No zebra striping — a full
1px row+column grid instead. Put padding:0 on <td> and pad an inner div, so status cells
paint their colour edge-to-edge. Every data cell shows VALUE + UNIT ("60%" / "drawn").
A 4px×36px rounded priority rail sits left of each row name. Sort deterministically
(priority → red count → amber count → name); the table is not user-sortable.
Controls: pills (999px) for chips/toggles/search/buttons; 8–10px radius for selects and
pager buttons. All hover to red border + red text. Chips fill BLACK when active (they scope
data); mode toggles fill RED (they switch what the chart is about).

DATA VISUALISATION — Hand-built inline SVG only; never a charting library. One chart type
per board. Gridlines #e2e2e2 at 1px; the boundary ring #c9c9c9 at 1.2px; axes dashed "4 4"
in #d8d8d8. Series 1 #db0011, series 2 #111111, series 3 #996300 — there is no fourth;
facet instead. Fills rgba at .20/.14/.18, strokes 2.4px (3px active), vertices r=3.5.
No tick labels, no data labels, no in-SVG title: the chart carries SHAPE, the adjacent
table carries VALUE. Two-line axis labels (10px uppercase name over a 9px qualifier).
Highlight by DIMMING context (shapes to opacity .22, legend rows to .45) — never by
brightening the target. Legends spell out semantics in words ("Red — clear trigger").
Grey + em dash = unknown; a green 0 = known and fine. Never render a missing value as 0.
Keep the axes drawn in the empty state. Ship a three-note explainer card and a dashed
source-attribution strip on every page.

INTERACTION — Every state change is a colour or opacity change. Nothing lifts, scales,
translates, or reflows on hover; there is no second shadow and no hover elevation.
Transitions: .12s row background, .15s controls, .18s chart opacity — nothing over 180ms.
Disabled = opacity .45 + cursor:not-allowed. Loading = an amber status pill plus a live
"12 / 40" progress counter, with the board staying interactive and re-rendering
incrementally — no spinner, no skeleton, no overlay. Errors are non-fatal and per-batch:
failed items stay grey/pending and the rest of the board renders normally. Empty states are
italic, #5c5c5c, and centred. Re-validate and HTML-escape any model- or API-supplied value
before it reaches innerHTML.

ACCESSIBILITY — All body text must clear WCAG AA (the palette already does; keep muted text
at #5c5c5c or darker, and chart sub-labels at #767676 or darker). Never use opacity on text
under 12px. Nothing below 12px may carry information unavailable at ≥12px. Colour is never
the only carrier of meaning: every coloured cell also states its value and unit, and every
scale gets a plain-English legend strip. Give every control an explicit
:focus-visible{outline:2px solid #db0011; outline-offset:2px} (black on red-filled
controls) — never outline:none without a replacement. Make row-level actions keyboard
reachable via the row's real <a>/<button>, not a bare click handler on <tr>. Add scope="col"
to headers, aria-label to meaningful SVGs, aria-hidden="true" to redundant decorative ones,
and aria-live="polite" to result counts and status pills. Manage focus when panels open and
close. Honour prefers-reduced-motion. Keep all targets ≥24px, and raise chip/toggle padding
to 14px inside @media (pointer:coarse).

Apply the same layout structure, logo placement, colour palette, typography, card styling,
chart styling, table styling, spacing, and interaction states. Reuse the extracted logo
asset exactly where applicable. Maintain the same visual hierarchy and dashboard density.
```

---

## Appendix — Source Inventory and Assumptions

**Source file:** `Signal Alert Dashbaord/dashboard.html` — 941 lines, 1,291,008 bytes, fully self-contained.

**What was read directly (exact):** all `:root` custom properties; every CSS rule; both `@media` blocks; the full `<body>` markup; all JavaScript (radar geometry, priority/sort/filter logic, drill-down rendering, and the Refinitiv M&A agent). The logo PNG was base64-decoded and its IHDR header and pixel data inspected.

**What was inferred, and labelled as such:**
- The rendered typeface (Arial) — the Univers Next for HSBC stack cannot be verified from source alone.
- Tooltip styling — no custom tooltip component exists; only native `title` attributes.
- Computed control heights (chip ≈31px, etc.) — derived from padding + font-size + border, not measured in a browser.
- Contrast ratios — computed from declared hex values using the WCAG relative-luminance formula.
- Header height (≈76px) — content-driven; the element has no fixed height.

**Not determinable from the provided input:**
- Favicon (no `<link rel="icon">` is declared).
- Print styles (no `@media print` block).
- Dark-mode styling (no `prefers-color-scheme` block; the design is light-only).
- Reduced-motion preferences (no `prefers-reduced-motion` block).
- Any brand asset beyond the single embedded hexagon PNG — a `grep` for `data:image/` across all 1.2 MB returns exactly one match.

**One clarification worth recording:** the file's 1.2 MB weight comes almost entirely from line 490, a `<script id="embedded-data" type="application/json">` block carrying the client dataset so the board works offline on a `file://` double-click. The logo accounts for only ~14.5 KB of it. Do not mistake that JSON payload for an embedded asset.
