# Signal definitions — current development scope

Authority: explicit user decisions and latest dated updates supersede older discovery notes. No business triggers are confirmed. Core assessment is 3 November 2026; CRR assessment is 4 November.

## SIG01 — RCF drawing increase

- **Business purpose (Business definition incomplete):** Investigate a material increase in RCF drawings that could merit banker review.
- **Primary input (Development rule):** CLO REV/RCF observations; keep source-native facility/borrower grain and the latest two available group snapshots.
- **Calculation (Development rule):** Current drawn minus prior drawn, with the actual comparison dates/gap retained. Absent prior observations stay unavailable.
- **Missing values (User decision):** Blank/missing drawn is zero only for SIG01; retain raw blanks and current/prior imputation flags. Invalid numeric values remain unavailable.
- **Materiality (Unverified business rule):** EUR50m total investment-grade whole-facility drawings was a stakeholder baseline; it is not an agreed increase threshold.
- **Open definitions (Unresolved):** Increase amount/percentage, comparison period, qualifying products, currency/FX date and whole-facility versus HSBC share.

## SIG02 — New facilities

- **Business purpose (Business definition incomplete):** Investigate newly signed RCF, term-loan or bridge facilities as possible financing context.
- **Primary input (Observed source):** Facilities Limits; observed field facility_creation_date. Keep facility parents, products, borrowers and versions separately.
- **Calculation (Development rule):** Age in days = original assessment date minus creation date. The 90-day inclusive lookback is a development test.
- **Ambiguity (Development rule):** Withhold contexts with conflicting products or creation dates rather than selecting arbitrary first/MAX values.
- **Open definitions (Unresolved):** Confirm signing versus amendment, migration or administration; define eligible products, amount scope and event deduplication.
- **Publishing scope (Unresolved):** Country/source partitions may publish on different dates; additional DE extraction is deferred and global latest selection remains unresolved.

## SIG03 — Enquiry and pre-hedging activity

- **Business purpose (Business definition incomplete):** Investigate derivatives/pre-hedge or swap-pricing enquiries that could relate to financing.
- **Primary input (Missing source):** No suitable enquiry/pricing-request source has been identified. Executed trades or facilities do not substitute for enquiries.
- **Required event fields (Required contract):** Entity identifiers, enquiry/request ID and date, product/type, status, amount/currency and financing purpose.
- **Open definitions (Unresolved):** Enquiry eligibility, business-event date, repeated-request rules and an approved identity route.

## SIG04 — KYC activity

- **Business purpose (Business definition incomplete):** Investigate entity onboarding or relevant KYC case activity, distinguishing business events from routine refreshes.
- **Primary input (Empty export):** delta.prod_party_gda.kyc; the selected target export is valid but header-only.
- **Development fields (Development rule):** review_request_created_time_stamp and candidate NTB/TRG purpose codes; 90-day lookback remains unverified.
- **Identity and schema (Source constraints):** cdd_topco_legal_name is an array. mg_parent_grid/groupguci are not automatically mastergroup IDs; names are review clues.
- **Open definitions (Unresolved):** Known target case/entity, NTB/Trigger/Periodic/Remediation meanings, case dates, signatory coverage and event eligibility.

## SIG06 — Utilisation and covenant evidence

- **Business purpose (Business definition incomplete):** Investigate compatible utilisation pressure separately from explicit financial covenant tests.
- **Calculation (Development rule):** Utilisation percent = valid utilisation / compatible approved limit x 100; candidate test is strictly >70%.
- **Compatibility (Required validation):** Numerator/denominator must share currency, units, scope, date and participation basis. Missing/zero denominator or unknown/conflicting scope is unavailable.
- **No aggregation (Source constraints):** Do not sum across sources, currencies, snapshots, parent/child limits or whole-facility versus HSBC share. Shared borrower rows consolidate only if exposure attributes agree.
- **Missing values (User decisions):** No missing-as-zero, no fallback FX conversion and no utilisation-based inference of a covenant breach.
- **Covenants (Missing source):** Require genuine financial terms, actual/final value, threshold, operator, test date and result/approval state. Supplied mislabelled Counterparty payload is quarantined.
- **Open definitions (Unresolved):** Eligible products/commitments, threshold approval, base/LCY units, participation, cancellation flags and exposure hierarchy.

## SIG07 — Rating and advisory context

- **Business purpose (Business definition incomplete):** Investigate rating/advisory context; an engagement, rating change or category trigger has not been defined.
- **Source scope (User decision):** Retain existing Facilities/PVD context. Application Ratings adds CRR only, not agency ratings or new category/advisory inference.
- **Displayed CRR (User decision):** Non-placeholder final_crr with crr_scale. Preserve previous/proposed/approved/manual/overridden states separately; blank/N/A stays unavailable without fallback.
- **Version selection (Development rule):** Latest supplied snapshot per source/country/CARM scope, then candidate effective periods at that snapshot. HISTORICAL can coexist with an open period.
- **Multiple ratings (Source constraints):** Keep competing applications and multiple CRRs per CIN. No MAX, averaging, group rating or assumed numeric direction.
- **Open definitions (Unresolved):** CRR scales, effective periods/version flags, latest-approved scope, reviewed CIN associations and any advisory engagement criterion.

