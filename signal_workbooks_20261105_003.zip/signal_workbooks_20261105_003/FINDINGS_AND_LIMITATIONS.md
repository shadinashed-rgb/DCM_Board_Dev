# Findings and limitations — 5 November 2026

The 626 records are development evidence. The additional DE extraction is deferred. Historical source/report copies retain their original dates and may be superseded by current decisions.

## All signals

- **Scope:** Three target mastergroups: Vodafone MG001356, Siemens Energy MG102229 and SoftBank MG101624. SIG05 and PVD sector aggregate excluded. Preserve scope.
- **Evidence versus alerts:** 626 records are development evidence; business_trigger remains blank. Define and review business rules before confirming triggers.
- **Assessment dates:** Original core assessed 3 November 2026; CRR assessed 4 November from the 3 November snapshot. Do not silently rebase dates to export date.
- **Identity:** CIN, GID and PVD key/relationship/supergroup namespaces differ. Names and identifier shapes never establish joins. Use explicit reviewed, date-scoped mappings; keep conflicts and native groups.
- **Counterparty:** Preserve valid original CLO mastergroups; only fill missing groups from a unique combined point-in-time candidate under explicit assumptions. No arbitrary first/MAX or transitive expansion; no missing groups recovered in this baseline.
- **Development associations:** Observed links and inherited unique_reviewed_cohort_group labels are not production approvals or historical membership proof. Keep the development qualification visible.
- **Freshness:** PVD observation date is 30 September. Daily refresh is a preference, not verified capability. Show actual source dates; do not treat stale or empty data as no activity.
- **Validation:** 269 local assertions and 70 tests passed in the prior validation run; source-wide completeness and business eligibility remain unverified. Use the recorded scope and owner-review questions.
- **DE publishing:** Image-transcribed profile suggests seven DE partitions at 3 November. Additional raw extraction is deferred. Treat transcription as derived evidence; publishing/current-selection completeness unresolved.
- **Provenance gaps:** Exact submitted SQL, native export times and download caps were not supplied for every round. Keep unknowns explicit; do not use file modification time as export time.

## SIG01 — RCF drawing increase

- **Drawing comparisons:** Three comparisons: Vodafone two and Siemens one. Both current and prior drawn values were imputed, yielding zero delta. Do not describe these as observed zero drawings or a confirmed increase.
- **SoftBank coverage:** No identifiable REV record; nine rows lack product/facility keys and one is TERM. No assessable RCF comparison does not establish no drawing activity.
- **Comparison gap:** Current 2 November versus prior 30 October; actual gap three days. Agree comparison horizon and materiality separately from EUR50m baseline.

## SIG02 — New facilities

- **Raw grain:** 105 supplied current rows; 19 blank facility IDs, 86 ID-bearing rows, 63 source/country/facility keys. Preserve product and borrower child contexts.
- **Ambiguity:** 13 keys have multiple products; two also have conflicting creation dates. 50 contexts remain usable and 13 withheld. Do not resolve with arbitrary row selection.
- **Recent candidates:** Eight under the 90-day test: seven Vodafone dated 17 September and one Siemens AE dated 6 October, FGL, AED40m proposed limit. Confirm real signing/new-financing meaning and product eligibility.
- **German history:** 349 archived DE rows at 30 October are shown separately, not added as current transactions. Additional extraction remains deferred; source/country publishing needs validation.

## SIG03 — Enquiry and pre-hedging activity

- **Missing events:** No assessable enquiry/pricing events in the combined evidence. Identify the actual enquiry source and event contract; do not infer events from facilities or trades.

## SIG04 — KYC activity

- **Empty target export:** Zero supplied KYC rows with 326 native headers retained. Earlier unrelated cases only supported schema inspection. Locate a known target case through a verified identity route.
- **Purpose ambiguity:** NTB, Trigger, Periodic and Remediation meanings and dates are unverified. A Trigger case alone is not a financing event.

## SIG06 — Utilisation and covenant evidence

- **DRR exposures:** 642 native target rows reduce to 405 candidate exposures: 57 usable ratios and 348 unavailable DRR contexts. Preserve shared borrower lineage without multiplying limits.
- **Other context:** Four CLO and 33 PVD utilisation contexts are unavailable; 385 unavailable utilisation contexts overall. Do not force alternative CLO USD or stale PVD ratios without units/grain validation.
- **High ratios:** Five arithmetic candidates: Vodafone 94.28%; Siemens 76.80% and 74.22%; SoftBank two at 100%. All observed 2 November. No qualifying financing eligibility has been confirmed.
- **Products and flags:** Candidates use FGTE, FCTA and FLNS; none is RVCF. Both FGTE rows have committed=Y and unconditionally_cancellable=Y. FCTA parent flag is G. Define products, cancellation flags and hierarchy before inclusion/exclusion.
- **Amounts:** Three candidates differ between base and LCY amounts despite matching numerator/denominator currency labels. Currency labels alone do not prove units, share or measurement basis.
- **Covenants:** Genuine financial covenant tests are missing. Counterparty payload labelled covenants is quarantined; Overdue reporting obligations are not breaches. Obtain genuine terms/tests before deriving pressure or breach signals.

## SIG07 — Rating and advisory context

- **Full CRR inputs:** 722 rows supplied: Vodafone 477, Siemens 238, SoftBank 7, all 3 November. Earlier 207 samples reconcile as a subset. Full scoped exports do not prove full group coverage or approved CIN links.
- **Current evidence:** 118 SIG07 contexts: 96 existing Facilities/PVD plus 22 Application Ratings contexts (Vodafone 8, Siemens 12, SoftBank 2). Keep each component and application separate.
- **Availability:** 18 populated final CRRs, four unavailable: one Vodafone blank, two Siemens blanks and one Siemens N/A. Keep raw placeholders and no fallback.
- **Historical flags:** Nine retained open-period contexts are HISTORICAL: two Vodafone and seven Siemens. Validate source period/version/latest-approved semantics.
- **Competing CRRs:** Siemens CIN AEBBME035063734 has 2.1, 3.1 and N/A across three retained applications. Retain all three, flagged multiple_crrs_for_cin; no numeric direction.
- **Historical agency fields:** Older alternate CRA fields contain two historical Siemens records repeating MY:Baa1 and SP:BBB/A-2. Their periods ended in March/June 2026. Excluded from the CRR-only contribution; not proof of current agency ratings or independent changes.
- **Raw codes:** Three Siemens raw historical rows have 0000000; none passes the current period rule. All populated retained CRRs have scale 1. Define code/scale meanings; do not assign grade direction or agency equivalence.

