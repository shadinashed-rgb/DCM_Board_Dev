# Bond Radar signal workbooks and development files

Open **SIGNAL_OVERVIEW.xlsx** first. It summarizes all six retained signals, their client coverage, current definitions and findings. Each individual signal has its own workbook: **SIG01.xlsx**, **SIG02.xlsx**, **SIG03.xlsx**, **SIG04.xlsx**, **SIG06.xlsx** and **SIG07.xlsx**.

The package contains the existing **626 development evidence records**. Business eligibility and triggers remain unverified. Core assessment remains 3 November 2026 and CRR assessment remains 4 November. This organization does not generate new signals or refresh the underlying observations.

## Sheets in each signal workbook

1. **Summary** — evidence counts, client breakdown and the main qualifications.
2. **Signal data** — a compact view with key measures and identifiers first, linked to the original evidence.
3. **Definitions** — business purpose, current development rules, confirmed user decisions and unresolved definitions.
4. **Findings** — signal-specific findings and shared identity, coverage and freshness limitations.
5. **Sources** — source files, tables, raw row counts and the sheet containing each source.
6. **Owner review / Coverage**, where applicable — existing validation questions or missing/empty-source information.
7. **Lineage** — one row per evidence-to-source record link, including the prior side of SIG01 comparisons.
8. **Evidence detail** — every original evidence field and value, kept separately from the compact presentation.
9. **Raw source sheets** — each source in its own table with native headers and original text values. Audit columns identify the record ordinal and whether it was used. The older DE Facilities snapshot is in **DE history**, excluded from current evidence.

SIG03 has no enquiry source and SIG04 has an empty target KYC export. Their workbooks show the gaps and definitions rather than invented events. SIG04 retains all native KYC column headers. SIG05 remains excluded.

The overview workbook also contains the shared Counterparty raw reference. It is supporting identity evidence; no new entity joins are inferred. Full CRR inputs supersede the earlier partial samples. Existing Facilities/PVD rating context remains separate from Application Ratings CRR. Missing CRRs stay unavailable, and competing applications remain distinct.

## Findings and definitions in this directory

- **SIGNAL_DEFINITIONS.md** — consolidated current definitions and open questions for all signals.
- **FINDINGS_AND_LIMITATIONS.md** — consolidated findings, evidence counts, validation limits and next actions.
- **findings_and_definitions/** — verbatim requirements, dated analysis findings, CRR review and validation files. Earlier statements may be superseded by the latest development updates. Historical counts of 614 describe the sample baseline; the current full-CRR result has 626 records.

The additional German Facilities extraction remains deferred at the user's request. The image-transcribed partition profile is retained as derived evidence, not treated as source facts. The historical DE raw file is kept separate; it is not silently concatenated with current GB/AE data.

## Development files

**development/** contains the continuing workspace snapshot: the active `pvd_client_cohort_lab` package, SQL templates, schemas/profiles, tests, raw inputs, source/reference documents, dated analysis and selected completed runs. This is a copy of the existing implementation, not a replacement engine. Prior archived SQLite files can retain original absolute paths as provenance; the root runner is the supported portable rebuild route.

The original shipped manifest is retained inside the development snapshot. Installed dependencies, caches and incomplete/generated duplicate runs are excluded. The selected runs include `crr_full_001`, `validation_20261105_001`, `signal_extracts_20261105_002` and `reference_002`. The earlier legacy prototype remains archival reference only.

From a terminal inside **development/**:

```sh
python3 -B verify_workspace.py
python3 -B -m unittest discover -s pvd_client_cohort_lab/tests -q
python3 -B -m unittest discover -s pvd_client_cohort_lab/engine/tests -q
python3 -B run_reference.py --out runs/package_reference_001 --test-observed-links --verify-reference
```

Use a fresh numbered output if a folder already exists. The reference rebuild uses the original sample inputs and should reproduce 614 records; the latest separately supplied full-CRR output remains 626. The observed-link option reproduces development assumptions, not production mapping approval. Local processing requires Python 3.10+ and its standard library; no Starburst connection is made.

Workbook packaging scripts are in `development/analysis/signal_workbooks_20261105_001/`. They require the installed `@oai/artifact-tool` JavaScript runtime for authoring/rendering; its installed binaries are not bundled. The signal engine does not acquire that dependency. SQL remains manually copied into Starburst by the user.

## Verification

**PACKAGE_MANIFEST.json** records workbook hashes, unchanged source hashes and the development-copy count. **WORKBOOK_CHECKS.json** records workbook inspections and sheet previews. **SAVED_XLSX_CHECKS.json** independently verifies the saved ZIP/XML contents, all source/evidence values, summary counts and cached compact-view formulas. The **previews/** folder contains rendered worksheet excerpts for visual review. Portable engine/test results are recorded separately after checking the copied development workspace.

Native IDs, leading zeros, categorical CRRs, placeholders and raw timestamps remain text. Derived monetary/ratio views use numeric formatting while Evidence detail preserves the exact original strings. No currency conversion or amount aggregation across sources, dates, currencies, participation bases or parent/child facilities is performed.

The saved workbook values and text styles preserve full identifiers. The preview renderer can abbreviate numeric-looking formula text; use the saved Excel cells for exact IDs. Native Excel UI visual testing was unavailable. See `VISUAL_QA.json`.
