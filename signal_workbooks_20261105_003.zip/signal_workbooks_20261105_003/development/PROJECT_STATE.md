# Consolidated project knowledge — 4 November 2026

## Purpose, scope and working stage

Build a Bond Radar dashboard that helps bankers identify and investigate potential financing/advisory opportunities. We are still developing and testing source extraction, entity coverage, source grain and signal evidence on three known clients. Evidence is not a prediction that a client will issue a bond.

| Mastergroup | Client |
| --- | --- |
| MG001356 | VODAFONE |
| MG102229 | Siemens Energy |
| MG101624 | SOFTBANK |

Retained signals: SIG01, SIG02, SIG03, SIG04, SIG06, SIG07. SIG05 is excluded. PVD sector aggregate is excluded from active scope even where retained historical files mention it. The original requirements, meeting notes, workbook, planning notes and dated reviews are preserved alongside this consolidation. There is no verbatim chat transcript in the package.

The user prefers one practical sequence, exact SQL/CSV names and a separate folder for each round. SQL is executed manually in Starburst, downloaded to a drive, then transferred locally. Python never contacts Starburst. Planning turns that say “do not change” must remain read-only.

## Current evidence and reproducible result

The best main round is DCM_Run_003, supplemented by the Application Ratings samples and an earlier Siemens DE Facilities export. Primary copies are catalogued in DATA_CATALOG.csv. Source schemas and older raw extracts remain available for tracing discoveries.

| Core signal | Evidence rows | Interpretation |
| --- | ---: | --- |
| SIG01 | 3 | RCF drawn comparisons, all with zero-imputation |
| SIG02 | 63 | Facilities creation/version contexts, including ambiguous contexts |
| SIG06 | 442 | Utilisation/context evidence across the available sources |
| SIG07 | 96 | Existing Facilities/PVD category/rating contexts |
| Core total | 604 | Earlier consolidated evidence |
| Application Ratings CRR addition | 10 | 9 populated final CRRs, 1 unavailable |
| Combined total | 614 | Development evidence, not confirmed alerts |

No assessable enquiry events for SIG03 or KYC events for SIG04 appear in this combined CSV. Source coverage reports still expose the gaps. Candidate flags: 5 ratios above 70%; 8 recent-creation candidates under a development 90-day lookback; 3 SIG01 comparisons with imputed current drawn. The 90-day window and 30-day freshness setting are test parameters, not agreed business requirements. Business trigger values remain unverified/blank.

The 604-row baseline is assessed on 3 November; the CRR addition on 4 November uses source snapshots dated 3 November. Keep these dates distinct. Root run_reference.py reproduces these assumptions and control counts from immutable selected inputs. It does not require the original project path.

## Selected source coverage

| Source | Selected raw export | Important qualification |
| --- | ---: | --- |
| CLO | 276 rows, 401 columns | 30/31 October and 2 November; comparison history, not 276 current facilities |
| Counterparty | 167 rows, 100 columns | Point-in-time reference, including conflict/non-target candidates |
| DRR | 660 rows, 152 columns | 642 native target rows; other group/no-group records retained for review |
| Facilities | 105 rows, 182 columns | Latest supplied GB/AE data; Siemens DE needs older partition evidence |
| KYC | 0 rows, 326 columns | Header-only valid export; absence of supplied case data, not proof of no activity |
| PVD | 143 rows, 90 columns | All 30 September; stale relative to the November assessment |
| Application Ratings | 207 rows, 227 columns | Vodafone 100, Siemens 100, SoftBank 7; partial samples |
| Financial covenants | Not available | The latest purported covenant export is actually Counterparty data |
| Enquiries/pricing requests | Not identified | Needed for SIG03 |

The earlier Siemens DE Facilities file has 349 raw rows reducing to 25 candidate effective facility keys at 30 October. Keep it as separate history; do not concatenate it into the latest round and count everything as current.

## Decision history that changes interpretation

| Decision / learning | Current position |
| --- | --- |
| Start identity discovery with PVD | User preference; supporting native CLO/DRR/Counterparty IDs improve coverage |
| CIN/GID/PVD namespaces | Distinct until verified; no inferred CIN from joi_key/relationship-ID shape |
| Missing CLO drawn, 3 November | Zero only for SIG01, with explicit current/prior imputation flags |
| Counterparty catalog, 3 November | Delta, not Hive: delta.prod_party_gda.counterparty_core |
| Facilities Limit_Cat | Keep as candidate classification/context; no proved advisory interpretation |
| Application Ratings, 4 November | New SIG07 source; latest user request adds CRR only from this source |
| Existing SIG07 sources | Remain in the 604-row base; CRR-only addition does not delete Facilities/PVD evidence |
| Full Application Ratings | Profile suggests 722 rows; only 207 data rows are present locally |
| “External ratings absent” | Too broad: alternate CRA fields contain historical Siemens agency values |
| Latest-record flags | HISTORICAL can have open effective periods; do not select CURRENT blindly |
| Row reduction | Preserve facility parent/product/borrower/version grains; do not blindly drop duplicate facility IDs |
| Covenants returned file | Counterparty payload under misleading filename; quarantine |
| Legacy CLO solution | Review its enrichment algorithm only; do not adopt its whole solution |

## SIG01 — RCF drawing increase

Primary source is CLO REV/RCF evidence. Retain the latest two available group snapshots for comparisons, but output only facilities present in the selected current snapshot. Keep the actual date gap. An absent prior observation remains unavailable; it is not an implicit zero.

User decision: missing/blank drawn values are zero **only for SIG01**. Preserve the original raw value and both current/prior imputation flags. Invalid numeric strings and missing facility keys are not zero. In the current result, Vodafone has two REV comparisons and Siemens one. All have zero delta because both drawn amounts were imputed. SoftBank has no identifiable REV record; nine rows lack product/facility keys and one is TERM.

Unresolved: material increase threshold, comparison period, qualifying products, currency/FX and whole-facility versus HSBC share. The original EUR50m investment-grade whole-facility drawing baseline is separate from an increase threshold. Never interchange lender participation with total facility value without validation.

## SIG02 — new facilities

Facilities is the main candidate source for RCF/term/bridge creation evidence. The observed column is facility_creation_date, not the earlier guessed facility_creation_dt. Need to establish whether it means signing, amendment, migration or administration and validate the product-code dictionary.

105 supplied rows: 19 have blank facility IDs; 86 ID-bearing rows yield 63 source/country-scoped keys. Thirteen repeated keys have different product codes; two also have conflicting creation dates. The current conservative engine withholds ambiguous contexts, leaving 50 usable creation contexts. Eight are recent under the development 90-day test (seven Vodafone dated 17 September; one Siemens AE dated 6 October, product FGL and AED40m). These are not eight confirmed qualifying financing transactions.

A global latest date loses the older Siemens DE partition. Source/country/CIN partition publishing rules still need confirmation. Build facility parents with product children, borrower links and version/event history rather than dropping repeated facility IDs or summing repeated limits. See the targeted Facilities partition-date SQL in NEXT_STEPS.

## SIG03 — enquiry / pricing activity

No suitable enquiry source has been identified. Need client/entity identifiers, request/enquiry ID and date, enquiry type/product, status, indicative amount/currency and purpose, plus deduplication/event rules. Executed trades, facilities or absence of returned rows cannot stand in for enquiry activity.

## SIG04 — KYC activity

Latest exported data are empty. Earlier unrelated KYC rows helped inspect the schema and case purposes; they do not establish target-client events. cdd_topco_legal_name is ARRAY(varchar); use the supplied array-aware SQL (ARRAY_JOIN), not the older failing scalar cast. mg_parent_grid and groupguci do not automatically share the mastergroup namespace.

Need a known case/entity lookup and definitions for NTB/Trigger/Periodic/Remediation, case date and eligibility. Do not keep widening names without an identity route or describe empty exports as no client activity.

## SIG06 — utilisation pressure and separate covenant evidence

DRR currently supplies the strongest arithmetic candidates. Proposed test is strict **utilisation >70%** of a compatible valid limit. Eligibility of product families and the business trigger are not agreed. Missing/zero denominators, negative utilisation, unknown currency/unit/scope and conflicting rows remain unavailable. No missing-as-zero and no fallback FX conversion. High utilisation is not a covenant breach.

642 native target DRR rows reduce to 405 candidate DRR-UID exposures: Vodafone 93, Siemens 281, SoftBank 31. Of these, 57 have usable ratios (20/32/5) and 348 are unavailable. Consolidate shared borrower associations only when all non-association attributes agree; preserve association lineage. DRR UID is an internal candidate exposure key, not proof of cross-source facility equivalence.

| Client | DRR UID | Product | Limit / utilisation | Candidate ratio |
| --- | --- | --- | --- | ---: |
| Vodafone | 264658583 | FGTE | EGP927660 / 874590 | 94.28% |
| Siemens | 543509314 | FGTE | QAR1371648 / 1053379 | 76.80% |
| Siemens | 815898281 | FCTA | EUR605104472 / 449087805 | 74.22% |
| SoftBank | 864252253 | FLNS | USD120m / 120m | 100% |
| SoftBank | 1234654449 | FLNS | USD1bn / 1bn | 100% |

All five observations are 2 November; none has product RVCF. Two Vodafone RVCF rows have zero utilisation. Product eligibility needs banker/source-owner validation before presenting these five as actionable.

CLO's configured facility_drawn_amount is absent; its four utilisation contexts remain unavailable. Raw USD alternatives exist but their units/denominator scope need validation. PVD is dated 30 September and its currencies/grain are unverified: do not force ratios. Do not sum across sources, currencies, snapshots, parent/child facilities or shares.

Covenants are a separate workstream. Earlier samples are nonfinancial reporting obligations with blank actual/final/threshold fields; Overdue does not prove a financial breach. The latest file labelled covenants_extract has the Counterparty schema and payload (151 exact rows duplicate the CP file; remaining differences are run_date). It is quarantined. A real financial covenant export with type, terms, tests, values, thresholds, operator and dates is still missing. The SF Approval asset location/decryption route was unresolved.

## SIG07 — rating advisory and latest CRR-only addition

No agreed rating advisory engagement trigger or rating-threshold mapping exists. Facilities limit_cat (CAT-A/B/S), advised_ind and grade codes, and PVD drr_crr/category fields remain candidate context. No CAT label or advised_ind value is a proved engagement without definitions.

New source: delta.prod_credit_and_lending_gda.application_ratings, a 227-column application/version dataset keyed through CIN and application references; no verified native MG/GID field. Latest user decision: add **CRR only** from this source. Display non-placeholder final_crr with crr_scale; keep previous/proposed/approved/manual/overridden states separately. Blank/N/A is unavailable, never zero or automatic fallback. Grades are categorical; do not average them or infer better/worse numeric direction without scale definitions.

Only 207 application rows are local. Profiles describe Vodafone 477, Siemens 238, SoftBank 7: expected 722 at that extraction snapshot, not 722 rows supplied or guaranteed at a future date. final_crr is populated in 160 raw rows, including 16 N/A: 144 non-placeholder (42 Vodafone, 95 Siemens, 7 SoftBank). approved_crr is blank in all supplied samples.

Named S&P/Moody/Fitch columns are blank, but alternate CRA fields contain two historical Siemens Energy AG records for CIN2020052910083 repeating MY:Baa1 (17 December 2025) and SP:BBB/A-2 (11 December 2025). Their application periods ended 11 March / 1 June 2026. They are not independent rating changes or proof of current agency ratings. Current CRR-only output deliberately excludes these external-rating values. SCU engagement markers/codes are also unverified.

The CRR adapter selects the latest supplied snapshot by source/country/CARM instance **before** effective-period selection. Ten candidate applications remain: Vodafone 1, Siemens 7, SoftBank 2; nine have final CRR and one N/A is unavailable. Six Siemens records are labelled HISTORICAL despite open periods/latest-approved flags. Keep competing applications and multiple CRRs per CIN; do not select a single group rating by MAX or average. Unknown periods and unresolved CIN links remain unavailable. Current-period interpretation and CIN associations are development assumptions.

sig07_crr.py is a separate optional adapter, not a new registered source in the seven-source engine. When full/sample files coexist it prefers the full file for the same client; keep versions clear. The provided 30-column CRR-only SQL has no 100-row cap and is the current next step; older all-column sampling guides are retained as discovery history.

## Enrichment, joins and freshness

See DATA_MODEL.md for source contracts and the staged model. PVD starts discovery; native CLO/DRR/Counterparty IDs support it. Preserve namespaces and original values. Names are clues, not join keys. Exact ID equality across unrelated namespaces is not sufficient. Target groups are not expanded transitively into Siemens Gamesa, Fortress or SoftBank Ventures based on names or hierarchy alone.

Counterparty enrichment preserves valid original CLO group IDs, selects mapping states as of CLO dates and retains conflicts. Current raw reference has 167 rows; GID candidate routes cover 259/265 usable CLO rows, with no CIN candidates for those. No missing CLO group is recovered. Two missing-group TERM rows have CIN1034107555 and no GID or matching Counterparty CIN. A different valid CLO row associates that CIN with SoftBank; that does not authorize silently overwriting the missing original group.

Old long DRR facility IDs rendered in scientific notation cannot be reconstructed from rounded text. Latest DCM003 has no such scientific IDs. Preserve downloaded IDs as strings and do not open/resave raw exports through a spreadsheet. Freshness is based on exported observation/processing dates, not recovery of historical database versions. A fresh snapshot can still contain old applications; no source-wide completeness claim follows from row counts.

## Known gaps and next development

1. Full CRR-only exports and source-owner interpretation of application period/version flags and scale.
2. Product/currency/share/grain validation of the five utilisation candidates and creation-event validation of eight Facilities candidates.
3. Facilities source/country publishing dates, especially Siemens DE, and parent/product/borrower duplicate model.
4. Actual financial covenants, a known KYC case and an enquiry source.
5. Explicit reviewed identity mappings and coverage by group/source, preserving conflict and partial states.
6. Once evidence is validated, a three-client banker prototype with measures, dates, gaps and drill-down lineage. The existing HTML diagrams are design aids, not a completed dashboard.

NEXT_STEPS.md supplies exact immediate SQL/CSV names. Avoid starting another broad source-discovery cycle when targeted checks address these gaps.
