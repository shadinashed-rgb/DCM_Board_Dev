# Signal extracts with raw data — 5 November 2026

Start with **SIGNAL_SUMMARY.csv** for totals and the three-client breakdown. Open **SIG01.csv**, **SIG02.csv**, **SIG03.csv**, **SIG04.csv**, **SIG06.csv** or **SIG07.csv** for each signal's summary, original evidence and original source records.

These files package the existing 626-row development output. Business triggers remain unverified. The underlying core assessment stays at 3 November 2026 and CRR assessment at 4 November; this export does not refresh those dates or generate new signals. SIG05 remains excluded.

| Signal file | Evidence rows | Main signal data |
| --- | ---: | --- |
| SIG01.csv | 3 | CLO drawing comparisons, raw current/prior values and zero-imputation flags |
| SIG02.csv | 63 | Facilities creation dates, products, amounts, ambiguities and eight recent test candidates |
| SIG03.csv | 0 | Missing enquiry/pricing source, explicit coverage rows for the three clients |
| SIG04.csv | 0 | Empty KYC export, preserved native column headers and explicit coverage rows |
| SIG06.csv | 442 | Source-specific utilisation context, 57 usable ratios and five >70% arithmetic candidates; covenant-data gap |
| SIG07.csv | 118 | Existing Facilities/PVD context plus 22 Application Ratings CRR contexts (18 populated, four unavailable) |

## Read the row types

Each signal CSV contains one consistent header. Filter **row_type** to choose:

- **signal_summary**: the signal total plus one row for each target client. Counts describe evidence, not confirmed alerts. The all-client and client summaries are alternative views; do not add them together.
- **signal_evidence**: the original signal evidence and all original fields, including measures, dates, status, validation reasons, imputation flags and source record references. Counting only these rows reproduces the 626-row combined output.
- **raw_used**: an exact original source record linked to at least one evidence row. Native source columns have the **raw__** prefix. `linked_evidence_ids` and `linked_roles` connect the record to current evidence or prior comparison inputs. A record appears once per signal, even when supporting several evidence rows.
- **raw_not_used**: remaining records from the selected source export, retained for completeness. They are not assigned a new signal, client or eligibility decision.
- **historical_context_not_used**: the archived Siemens DE Facilities snapshot of 30 October, provided separately in SIG02 and SIG07 for context. It is not merged into the current evidence or counted as a new event. The additional German extraction remains deferred.
- **coverage**: missing-source or empty-export information. These are not activity or signal records. For SIG06 these rows represent missing genuine financial covenants.

`raw_source_file`, `raw_source_record`, `raw_reference`, `raw_source_table`, `raw_observation_date_field` and `raw_observation_date` identify the original input. Record numbers are CSV record ordinals including the header as record 1, not physical text lines when a quoted field spans several lines. Raw dates, leading zeros, IDs, currencies, categorical codes and placeholders are preserved as text. A missing source-native field remains blank; no raw value is imputed.

For SIG01, compare `source_record_references` with `previous_source_record_references` and the raw rows' `linked_roles`. The zero-imputed evidence values are separate from the unchanged blank raw drawn amounts. CRR raw fields likewise remain separate from displayed/unavailable final CRR values. Source-native group fields are preserved under `raw__`; linked group labels come only from the existing development evidence and are not new identity approvals.

## Supporting files and scope

**IDENTITY_REFERENCE.csv** preserves all 167 Counterparty rows and their source. It is shared identity-reference evidence; this export does not invent joins from those rows to individual signals or overwrite original groups.

**SOURCE_DATA_INVENTORY.csv** inventories all curated CSVs under `data/`, with current hashes, row/column counts and their role. All primary raw records from the six selected source exports, the three full CRR files and the older DE snapshot are represented in the appropriate signal/reference files. The header-only KYC schema is preserved in SIG04.

Full CRR files supersede the 207 sample rows for current Application Ratings processing. Samples, profiles, schemas and the image-transcribed partition profile are inventoried separately, without being counted as additional business facts. The quarantined Counterparty payload labelled as covenants is inventoried as quarantined and never ingested as covenant data. Older duplicate/archive trees under `sql/` are not concatenated into a new round.

All raw columns from the full 30-column Application Ratings exports are retained; the only derived Application Ratings signal contribution remains CRR context. Existing Facilities/PVD SIG07 context is retained separately. No agency ratings, category interpretation, numeric CRR direction or group rating is added.

**MANIFEST.json** records input/output hashes and per-signal evidence/raw/context counts. Saved CSV values are checked cell by cell against the prepared records, then independently read back with Python. Every original evidence field and every included native raw field is preserved. Source files and prior results remain unchanged. Exact SQL submission/export timestamps and download-cap settings remain unknown where they were not supplied; file modification times are not used as substitutes.

For safe import into Excel, select Text/CSV import and preserve identifier and raw columns as text. CSV itself cannot enforce column types. Do not sum raw rows, summaries, evidence rows and context rows together. No amount aggregation across currencies, sources, snapshots or parent/child facilities has been performed.

The reproducible exporter is `analysis/signal_extracts_20261105_001/export_signal_files.py`, with its CSV authoring helper in the same folder. It accepts a fresh output path and requires the installed artifact-tool JavaScript runtime. The active signal engine is unchanged.
