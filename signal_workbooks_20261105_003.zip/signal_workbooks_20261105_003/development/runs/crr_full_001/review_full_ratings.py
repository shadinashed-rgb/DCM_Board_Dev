"""Reproduce the full-export reconciliation without modifying raw data."""
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        assert len(reader.fieldnames) == len(set(reader.fieldnames)), path
        assert all(None not in r and None not in r.values() for r in rows), path
        return reader.fieldnames, rows


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_day(value):
    if value == '99991231':
        return date.max
    return date.fromisoformat(value) if '-' in value else date(int(value[:4]), int(value[4:6]), int(value[6:8]))


def main():
    manifest = json.loads((OUT / 'manifest.json').read_text())
    hashes = manifest['input_sha256']
    assert all(digest(Path(p)) == h for p, h in hashes.items())
    base_fields, base = read(ROOT / 'analysis/dcm_run_003_review_20261103/DCM_Run_003_All_Signal_Evidence.csv')
    _, combined = read(OUT / 'DCM_Run_003_All_Signal_Evidence_With_CRR.csv')
    _, selected = read(OUT / 'SIG07_Application_Ratings_CRR.csv')
    _, previous = read(ROOT / 'results/SIG07_CRR.csv')
    actual_core = {r['evidence_id']: r for r in combined if r['source'] != 'application_ratings'}
    assert len(actual_core) == len(base) == 604
    for row in base:
        assert {k: actual_core[row['evidence_id']][k] for k in base_fields} == row
    assert len(combined) == 626 and len({r['evidence_id'] for r in combined}) == 626
    assert all(not r['business_trigger'] for r in combined)
    grouped = defaultdict(list)
    for row in selected:
        filename, record = row['source_record_references'].rsplit(':record ', 1)
        grouped[filename].append((int(record), row))
    profiles = []
    clients = [('vodafone', '01_vodafone_crr.sql', 477),
               ('siemens_energy', '02_siemens_energy_crr.sql', 238),
               ('softbank', '03_softbank_crr.sql', 7)]
    for label, sql_name, expected in clients:
        path = ROOT / 'data/application_ratings_full' / f'application_ratings_{label}_full.csv'
        fields, raw = read(path)
        sql_path = ROOT / 'pvd_client_cohort_lab/sql_templates/sig07_crr_20261104' / sql_name
        sql = sql_path.read_text()
        assert fields == re.findall(r't\."([^"]+)"', sql.split('FROM')[0])
        allowed_cins = set(re.findall(r"'([^']*)'", sql.split(' IN (')[1].split('))')[0]))
        assert len(raw) == expected
        assert {r['run_date'] for r in raw} == {'20261103'}
        assert all(r['cin'].strip().upper() in allowed_cins for r in raw)
        assert len({json.dumps(r, sort_keys=True) for r in raw}) == len(raw)
        # Independent, bounded reconciliation: these exports each contain one snapshot.
        expected_records = {i for i, r in enumerate(raw, 2)
                            if parse_day(r['record_start_dt']) <= date(2026, 11, 3) <= parse_day(r['record_end_dt'])}
        retained = grouped[path.name]
        assert {i for i, _ in retained} == expected_records
        assert len(retained) == len(expected_records)
        for record, row in retained:
            original = raw[record - 2]
            for target, source in [('crr_raw', 'final_crr'), ('crr_scale', 'crr_scale'),
                                   ('previous_crr', 'previous_crr'), ('proposed_crr', 'proposed_crr'),
                                   ('approved_crr', 'approved_crr'), ('proposed_manual_crr', 'proposed_manual_crr'),
                                   ('overriden_crr', 'overriden_crr')]:
                assert row[target] == original[source].strip()
            # The existing adapter does not project these three fields. Verify no
            # populated state is lost from the selected full-export records.
            assert all(not original[k].strip() for k in ['crr_prior_ovrd', 'crr_post_ovrd', 'model_crr'])
            assert row['cins'] == original['cin']
            assert row['observation_date'] == '2026-11-03'
            assert row['assessment_date'] == '2026-11-04'
            assert row['mapping_status'] == 'candidate_cin_cohort_lookup'
            assert row['crr'] == ('' if original['final_crr'].strip().upper() in {'', 'N/A'} else original['final_crr'].strip())
        sample_rows = []
        for sample in sorted((ROOT / 'data/application_ratings').glob(f'application_ratings_{label}*.csv')):
            if 'profile' not in sample.stem:
                sample_fields, sample_data = read(sample)
                if set(fields) <= set(sample_fields):
                    sample_rows.extend(sample_data)
        projected_full = Counter(tuple(r[k] for k in fields) for r in raw)
        projected_sample = Counter(tuple(r[k] for k in fields) for r in sample_rows)
        assert sample_rows and not (projected_sample - projected_full)
        profiles.append(dict(client=retained[0][1]['client'], file=str(path.relative_to(ROOT)),
            sha256=digest(path), rows=len(raw), columns=len(fields), run_date='20261103',
            retained=len(retained), excluded_by_period=len(raw)-len(retained),
            populated_crr=sum(bool(r['crr']) for _, r in retained),
            unavailable_crr=sum(not r['crr'] for _, r in retained),
            retained_historical=sum(r['latest_record']=='HISTORICAL' for _, r in retained),
            sample_rows_reconciled=len(sample_rows),
            expected_sql_template=str(sql_path.relative_to(ROOT)), sql_template_sha256=digest(sql_path),
            submitted_sql_confirmed=False, export_time=None,
            row_limit_status='Template has no LIMIT; download cap unconfirmed; counts match prior profiles',
            error='No error payload or malformed CSV detected'))
    old_ids = {r['evidence_id'] for r in previous}
    new_ids = {r['evidence_id'] for r in selected}
    assert old_ids <= new_ids
    for row in selected:
        peers = {r['crr'] for r in selected if r['crr'] and all(r[k] == row[k] for k in ['mastergroup_id', 'source_countries', 'cins'])}
        assert row['multiple_crrs_for_cin'] == str(len(peers) > 1)
    review = dict(assessment_date='2026-11-04', source_snapshot='2026-11-03', profiles=profiles,
        core_rows_preserved=604, selected_crr_rows=len(selected), combined_rows=len(combined),
        previous_crr_records_retained=len(old_ids), additional_crr_records=len(new_ids-old_ids),
        populated_crr=sum(bool(r['crr']) for r in selected), unavailable_crr=sum(not r['crr'] for r in selected),
        historical_retained=sum(r['latest_record']=='HISTORICAL' for r in selected),
        multiple_crr_rows=sum(r['multiple_crrs_for_cin']=='True' for r in selected),
        checks='CSV structure, SQL projection/scope, exact duplicates, samples subset, independent period selection, CRR raw values/states, candidate mappings, lineage, base field preservation, unverified triggers, immutable hashes',
        qualification='Full exports for supplied candidate CIN scope, not proof of complete group coverage or approved joins. Period/version rules and CRR definitions remain unverified.',
        validation=dict(package_tests=48, engine_tests=22, reference_run='runs/reference_002', reference_verified=True))
    assert all(digest(Path(p)) == h for p, h in hashes.items())
    (OUT / 'DATA_REVIEW.json').write_text(json.dumps(review, indent=2)+'\n')
    print(json.dumps(review, indent=2))


if __name__ == '__main__':
    main()
