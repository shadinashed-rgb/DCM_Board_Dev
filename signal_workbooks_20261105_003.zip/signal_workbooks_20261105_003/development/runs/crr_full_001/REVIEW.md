# Full Application Ratings CRR run — 4 November 2026

The three supplied full-cohort exports contain 722 application/version rows, all at source snapshot 3 November 2026. They match the previously profiled counts and contain all 207 earlier sample rows when projected onto the 30 requested columns. They establish coverage of the supplied candidate CIN extraction scope, not complete legal-group coverage or approved identity joins.

| Client | Raw rows | Period candidates | Populated final CRR | Unavailable final CRR |
| --- | ---: | ---: | ---: | ---: |
| Vodafone MG001356 | 477 | 8 | 7 | 1 |
| Siemens Energy MG102229 | 238 | 12 | 9 | 3 |
| SoftBank MG101624 | 7 | 2 | 2 | 0 |
| Total | 722 | 22 | 18 | 4 |

The new combined CSV has **626 evidence rows: the unchanged 604-row core plus 22 Application Ratings CRR contexts**. All ten earlier CRR evidence identifiers remain present; the full exports add seven Vodafone and five Siemens records. The original 614-row sample output remains unchanged in `results/`. No business trigger is confirmed; all combined `business_trigger` values remain blank.

## Selection and unresolved interpretation

The existing adapter selects the latest supplied snapshot by source/country/CARM scope, then applies effective periods at that source snapshot. The full files each contain just the 3 November snapshot. Independent period checks reconcile all 22 retained and 700 excluded records. CRR assessment date is 4 November; the original core assessment remains 3 November.

Nine retained records have HISTORICAL labels and open periods: two Vodafone and seven Siemens. Keep them visible as candidates until the source owner defines the period/version flags. Do not filter CURRENT alone or infer a new rating event from a historical application start date.

Siemens CIN AEBBME035063734 has three retained AE applications: final CRRs 2.1 and 3.1, plus N/A. All three are flagged `multiple_crrs_for_cin=True`; do not collapse them to one group rating or infer numeric rating direction. The four unavailable final CRRs consist of one Vodafone blank, two Siemens blanks and one Siemens N/A. No fallback CRR or zero is substituted.

All populated retained CRRs have scale 1, whose business definition is still unverified. Three raw Siemens historical rows contain `0000000`; none passes the period selection. That code has not been assigned a business meaning. Previous/proposed/approved/manual/overridden fields are preserved by the adapter. The three raw state fields not projected by the current adapter (`crr_prior_ovrd`, `crr_post_ovrd`, `model_crr`) are blank in all 22 retained records and remain in the immutable source CSVs.

CIN associations remain development candidates, not approved mappings or historical-membership proof. Existing Facilities/PVD SIG07 context remains in the core. No agency rating, category, advisory trigger or group-average CRR is introduced.

## Outputs and reproduction

- `DCM_Run_003_All_Signal_Evidence_With_CRR.csv`: latest combined development evidence.
- `SIG07_Application_Ratings_CRR.csv`: the 22 retained CRR contexts and original record references.
- `manifest.json`: adapter selection counts and input hashes.
- `DATA_REVIEW.json`: source profiles, reconciliation and extraction-metadata gaps.
- `review_full_ratings.py`: repeatable independent reconciliation; run from any directory with Python 3.10+.

Executed from the workspace root:

```sh
python3 -B pvd_client_cohort_lab/sig07_crr.py \
  --input data/application_ratings_full \
  --base analysis/dcm_run_003_review_20261103/DCM_Run_003_All_Signal_Evidence.csv \
  --as-of 2026-11-04 \
  --out runs/crr_full_001
python3 -B runs/crr_full_001/review_full_ratings.py
```

The adapter refuses an existing output folder. Use a fresh numbered run for future rebuilds.

Validation passed: 48 package tests, 22 engine tests and the unchanged 614-row sample reference rebuild in `runs/reference_002/`. Every original core field was compared against the base; all retained CRRs and their lineage were checked against raw records. Raw hashes matched before/after processing. No engine, raw CSV, archived result or shipped manifest was changed.

## Extraction provenance and next work

Expected templates are in `pvd_client_cohort_lab/sql_templates/sig07_crr_20261104/`, with pinned `run_date=20261103` and no LIMIT. The downloaded headers, CIN scope, snapshot and row counts match those templates/profiles. The exact submitted SQL and export timestamps were not supplied, and the download's cap setting is unknown; these are recorded as unknown rather than inferred from file modification times. No malformed/error CSV was detected.

Full exports are now present; another CRR extraction is not needed merely to resume this run. Next work is targeted validation: source-owner CRR scale/period/flag definitions and competing applications; product/currency/share eligibility for the five SIG06 candidates; creation-event and publishing-grain checks for Facilities (including Siemens DE). Actual financial covenants, a known KYC case and an enquiry source remain missing. No source discovery or dashboard implementation was restarted.
