# Existing-evidence validation — 5 November 2026

**Share with caveats: development evidence only.** The local calculations and source references checked in this run pass. The data do not establish confirmed business triggers or approved legal-entity joins. Additional German Facilities extraction is deferred at the user's request; publishing-grain and current-selection completeness remain unresolved.

The dataset remains `runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv`, containing 626 evidence rows. No evidence was recalculated at a new assessment date or promoted to a confirmed signal. The core assessment remains 3 November and the CRR assessment remains 4 November.

| Evidence | Local result | Business validation still needed |
| --- | --- | --- |
| 604 original core rows | Every original field preserved; all source references resolve | Reviewed identity links and source-specific definitions |
| SIG06 | All 57 populated ratios match raw numerator/denominator values and strict >70% flags; five exceed the test threshold | Product eligibility, units, participation, commitment/cancellation and hierarchy |
| SIG02 | Dates/ages reconcile for 50 usable contexts; eight meet the original 90-day test; 13 ambiguous contexts remain withheld | Whether creation means signing, amendment, migration or administration; product eligibility and amount scope |
| Application Ratings CRR | All 722 raw rows reconcile to 22 retained period candidates; 18 populated and four unavailable | Scale, competing applications, historical/open-period semantics and advisory criteria |
| SIG01 | Three comparisons retain flagged current/prior missing-as-zero and the actual three-day gap | These are imputed comparisons; no observed drawing increase or agreed materiality trigger is established |

The independent validation script recorded 269 passing local assertions. These are bounded checks of the existing exports, not a completeness guarantee for live sources or proof of business eligibility. See `CHECKS.csv` and `VALIDATION_SUMMARY.json` for precise scope. All 70 existing tests passed, and the original 686-file handover integrity check passed. The earlier reference rebuild was reused after checking its controls and all reference input hashes.

## Review findings

**SIG06: five ratios are arithmetically reproducible, with unresolved eligibility.** The two FGTE candidates (Vodafone DRR UID 264658583 and Siemens UID 543509314) both carry raw `committed_flag=Y` and `unconditionally_cancellable=Y`. Those flags require definitions and reconciliation with the eligibility rule; neither code alone authorizes inclusion or exclusion. Siemens FCTA UID 815898281 has raw `facility_as_parent=G`, whose meaning and hierarchy need confirmation. All five have matching numerator/denominator currency labels, but those labels alone do not prove units or participation scope. Three have different base and `_lcy` amounts. No amounts were summed across currencies, sources, parents or children. The >70% threshold remains a development assumption.

**SIG02: recent dates are reproducible, but transaction meaning remains unknown.** Seven Vodafone candidates have 17 September creation dates and ages of 47 days; the Siemens AE candidate has a 6 October date and age of 28 days, at the original 3 November assessment. Each usable source/country/facility context has a unique product/date in the supplied file. This does not establish signing, a newly originated loan, or whole-facility amount. Repeated borrower/product contexts and the excluded German partition still limit completeness.

**CRR: preserve all competing and unavailable contexts.** Nine retained rows are HISTORICAL despite open periods, and three applications for Siemens CIN AEBBME035063734 include two populated CRRs (2.1 and 3.1) plus N/A. The multiple-CRR flag is preserved on all three. Four final CRRs remain unavailable without zero or fallback. Original previous/proposed/approved/manual/overridden values are retained. No categorical CRR direction, agency rating, group rating or advisory trigger is inferred.

**Identity and coverage remain qualified.** Some inherited core status labels say `unique_reviewed_cohort_group`; the reference was built with development-only observed links. Those labels do not establish production approval or historical legal membership. SIG03 has no identified enquiry source; target KYC data is empty; genuine financial covenants are missing; PVD is dated 30 September. Empty/missing data is not negative client activity. The transcribed DE profile is not used as raw source facts in this validation.

## Files for the validation step

- `SIG06_OWNER_REVIEW.csv`: the five candidates with raw flags, calculations, lineage and specific eligibility questions.
- `SIG02_OWNER_REVIEW.csv`: the eight recent candidates with dates, products, amounts, raw flags and creation-event questions.
- `SIG07_CRR_OWNER_REVIEW.csv`: all 22 CRR contexts and the definitions/conflicts requiring review.
- `CHECKS.csv`: all local validation assertions and their scope.
- `VALIDATION_SUMMARY.json`: counts, outstanding definitions and input hashes.
- `VERIFICATION.json`: tests, workspace verification and reference-check reuse.

The owner-review files are questions and evidence, not approval templates or decisions. Do not infer approval from a PASS in their arithmetic/local-check columns.

To reproduce into a fresh output directory:

```sh
python3 -B analysis/validation_20261105_001/validate_existing_evidence.py \
  --out runs/validation_20261105_002
```

Next, resolve the product/amount/creation and CRR definitions using the candidate review files. Record the confirmed rule, source, reviewer, effective date and decision separately, then implement only the supported eligibility/selection changes with new tests and a fresh evidence run. No additional DE extraction is required to complete this local review; it remains deferred, with completeness explicitly unresolved.
