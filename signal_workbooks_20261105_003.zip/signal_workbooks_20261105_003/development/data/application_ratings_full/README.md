# Full CRR exports not supplied yet

This directory intentionally has no data CSVs. Follow ../../NEXT_STEPS.md to export the three CRR-only queries manually. At the 3 November profile snapshot the raw counts were Vodafone 477, Siemens 238, SoftBank 7. These are expected counts to reconcile, not data currently available or a guarantee for a later snapshot. Keep profiles/errors outside this data directory.
