# Selected raw data and evidence rules

Selected CSVs are exact byte copies of supplied exports. DATA_CATALOG.csv records origin, hash, header/row counts and role. Original files and source schemas remain in sql/ and sql_sample_extract/ for investigation. Their presence does not make them additional current observations.

- **current_exports/**: six reviewed input files for the reference rebuild. Empty KYC is included with its headers. This is the folder to ingest for the supplied core baseline.
- **application_ratings/**: 207 actual raw sample rows across three client files, plus three profile CSVs. The adapter excludes profile files. The original filename `application_ratings_softbank..csv` (double dot) is retained and supported.
- **application_ratings_schema/**: columns, DDL, rating inventory and query-generation output; these are metadata, not client rating observations.
- **history/**: the earlier Siemens DE Facilities file, 349 raw rows at 30 October, retained to investigate country-partition loss. Not automatically mixed into the current 105-row file.
- **quarantine/**: a file named as covenants but containing Counterparty payload. Never feed it to covenant processing. Its misleading historical original remains under sql/DCM_Run_003/ for provenance.
- **application_ratings_full/**: instructions only until full exports are supplied. Full 477/238/7 raw Application Ratings rows are NOT present in this handover.

Missing enquiry and actual financial-covenant data are not replaced with synthetic records. The active package's examples contain synthetic data for tests/demo; never substitute those or demo approvals for real clients. Earlier unrelated KYC, nonfinancial covenant and old DRR samples support schema/quality investigation only. Rounded/scientific IDs cannot be repaired by changing their string formatting.

Keep future raw rounds immutable. Capture source table, submitted SQL, predicates, requested/observed dates, export timestamp, execution outcome, row cap/truncation and filename. Store profiles/errors separately from data. Client data are deliberately included here for local continuation; only share the folder/archive with intended recipients.
