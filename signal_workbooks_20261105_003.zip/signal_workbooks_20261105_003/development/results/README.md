# Preserved current outputs

ALL_SIGNALS_WITH_CRR.csv is an unchanged copy of the 4 November consolidated result: 604 core evidence items plus 10 CRR application contexts. SIG07_CRR.csv is its ten-row Application Ratings contribution. Nine final CRRs are populated and one is unavailable. These files do not establish confirmed advisory/financing triggers.

Original output names, manifest and rationale remain in analysis/sig07_crr_addition_20261104/. Older core output is in analysis/dcm_run_003_review_20261103/. Use fresh runs/ folders for rebuilt results; original path references inside preserved outputs are provenance, not live dependencies. The supplied signal CSVs do not add rows for missing SIG03/SIG04 activity; source coverage is reported separately.

BASELINE_COVERAGE.csv and BASELINE_SELECTION.csv preserve the core run's group/source coverage and snapshot reductions. They describe the seven-source core process; the separate CRR adapter contribution is reported in SIG07_CRR.csv and its manifest.
