-- Engine: Starburst / Trino. Read-only discovery sample.
-- Signals: SIG06 alternative limits source
-- Identify approved/utilised measures, identifier scope, currency and dates. A link to covenant records has not been established.
-- Run 01_schema.sql first. Names of partition/date/client columns are not yet validated.
-- SELECT * is intentional for the first schema-discovery sample only.
-- LIMIT caps returned rows, not bytes scanned. No ordering or representativeness is implied.
-- If this source requires a partition predicate, add its verified predicate before running.
-- After inspection, replace t.* with the required fields and add a verified client/date filter.
-- No latest-date, signing-event or covenant-pressure rule is assumed here.

SELECT t.*
FROM "hive"."pvd_prod_wave"."pvd_omnia_drr" t
LIMIT 100;
