-- Engine: Starburst / Trino. Read-only. Source: InternalSignalsDataSources.xlsx, Sheet1.
-- Signals: SIG06 limits and linkage investigation
-- Identify actual facility/mastergroup keys, approved and utilised measures, units and observation dates. Prior facility_id matching failed.
-- Run statements separately and export each result separately.

-- 1. Columns, types, connector extras and comments.
SHOW COLUMNS FROM "delta"."prod_credit_and_lending_mda"."drr_facility_limits";

-- 2. Definition and exposed storage/partition properties. This SHOW does not create a table.
-- If the object is a view, run SHOW CREATE VIEW instead of this statement.
SHOW CREATE TABLE "delta"."prod_credit_and_lending_mda"."drr_facility_limits";

-- 3. Tabular schema suitable for CSV export.
SELECT
    table_catalog,
    table_schema,
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable
FROM "delta".information_schema.columns
WHERE table_schema = 'prod_credit_and_lending_mda'
  AND table_name = 'drr_facility_limits'
ORDER BY ordinal_position;
