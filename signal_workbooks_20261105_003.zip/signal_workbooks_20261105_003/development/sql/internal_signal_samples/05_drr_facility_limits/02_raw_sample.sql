-- Engine: Starburst / Trino. Read-only discovery sample.
-- Signals: SIG06 limits and linkage investigation
-- Identify actual facility/mastergroup keys, approved and utilised measures, units and observation dates. Prior facility_id matching failed.
-- Run 01_schema.sql first. Names of partition/date/client columns are not yet validated.
-- SELECT * is intentional for the first schema-discovery sample only.
-- LIMIT caps returned rows, not bytes scanned. No ordering or representativeness is implied.
-- If this source requires a partition predicate, add its verified predicate before running.
-- After inspection, replace t.* with the required fields and add a verified client/date filter.
-- No latest-date, signing-event or covenant-pressure rule is assumed here.

SELECT t.*
FROM "delta"."prod_credit_and_lending_mda"."drr_facility_limits" t
LIMIT 100;
