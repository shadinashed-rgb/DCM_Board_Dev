-- Engine: Starburst / Trino. Read-only. Source: InternalSignalsDataSources.xlsx, Sheet1.
-- Signals: SIG06 covenants
-- Inspect facility_id, relationship_id, customer_id, covenant measures, thresholds, statuses and business dates. Do not assume all exist.
-- Run statements separately and export each result separately.

-- 1. Columns, types, connector extras and comments.
SHOW COLUMNS FROM "delta"."prod_credit_and_lending_gda"."covenants";

-- 2. Definition and exposed storage/partition properties. This SHOW does not create a table.
-- If the object is a view, run SHOW CREATE VIEW instead of this statement.
SHOW CREATE TABLE "delta"."prod_credit_and_lending_gda"."covenants";

-- 3. Tabular schema suitable for CSV export.
SELECT
    table_catalog,
    table_schema,
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable
FROM "delta".information_schema.columns
WHERE table_schema = 'prod_credit_and_lending_gda'
  AND table_name = 'covenants'
ORDER BY ordinal_position;
