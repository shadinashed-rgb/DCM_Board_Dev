-- Engine: Starburst / Trino. Metadata only. Run each statement separately.
-- Locate Counterparty Core and SF Approval without inventing their qualified names.
-- No result can mean an unknown location OR metadata permissions; it does not prove absence.
-- These searches cover only the two catalogs already named in the source notes.

SELECT table_catalog, table_schema, table_name, table_type
FROM "delta".information_schema.tables
WHERE table_schema <> 'information_schema'
  AND (
      lower(table_name) LIKE '%counterparty%core%'
      OR lower(table_name) LIKE '%sf%approval%'
  )
ORDER BY table_schema, table_name;

SELECT table_catalog, table_schema, table_name, table_type
FROM "hive".information_schema.tables
WHERE table_schema <> 'information_schema'
  AND (
      lower(table_name) LIKE '%counterparty%core%'
      OR lower(table_name) LIKE '%sf%approval%'
  )
ORDER BY table_schema, table_name;
