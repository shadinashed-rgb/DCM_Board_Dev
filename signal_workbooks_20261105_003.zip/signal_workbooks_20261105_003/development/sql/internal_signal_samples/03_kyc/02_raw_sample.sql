-- Engine: Starburst / Trino. Read-only discovery sample.
-- Signals: SIG04 onboarding and KYC events
-- Identify client keys, business-event dates/types and processing dates. A dataset refresh is not necessarily a client KYC event.
-- Run 01_schema.sql first. Names of partition/date/client columns are not yet validated.
-- SELECT * is intentional for the first schema-discovery sample only.
-- LIMIT caps returned rows, not bytes scanned. No ordering or representativeness is implied.
-- If this source requires a partition predicate, add its verified predicate before running.
-- After inspection, replace t.* with the required fields and add a verified client/date filter.
-- No latest-date, signing-event or covenant-pressure rule is assumed here.

SELECT t.*
FROM "delta"."prod_party_gda"."kyc" t
LIMIT 100;
