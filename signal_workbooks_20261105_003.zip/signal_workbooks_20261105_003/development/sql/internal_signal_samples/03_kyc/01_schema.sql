-- Engine: Starburst / Trino. Read-only. Source: InternalSignalsDataSources.xlsx, Sheet1.
-- Signals: SIG04 onboarding and KYC events
-- Identify client keys, business-event dates/types and processing dates. A dataset refresh is not necessarily a client KYC event.
-- Run statements separately and export each result separately.

-- 1. Columns, types, connector extras and comments.
SHOW COLUMNS FROM "delta"."prod_party_gda"."kyc";

-- 2. Definition and exposed storage/partition properties. This SHOW does not create a table.
-- If the object is a view, run SHOW CREATE VIEW instead of this statement.
SHOW CREATE TABLE "delta"."prod_party_gda"."kyc";

-- 3. Tabular schema suitable for CSV export.
SELECT
    table_catalog,
    table_schema,
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable
FROM "delta".information_schema.columns
WHERE table_schema = 'prod_party_gda'
  AND table_name = 'kyc'
ORDER BY ordinal_position;
