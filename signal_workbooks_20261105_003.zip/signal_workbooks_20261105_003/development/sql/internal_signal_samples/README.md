# Internal signal sample and schema SQL

These read-only queries prepare source samples and schema evidence for Bond Radar. They target **Starburst or Trino**, following [the previous CLO extraction](../../extract_clo_rev_universe.sql). Table mappings come from [the internal source reference](../../Bond%20Radar%20Internal%20Signal%20Data%20Sources.md) and Sheet1 of the source workbook.

## Source folders

| Folder | Source | Signals |
| --- | --- | --- |
| `01_clo` | `hive.clo_prod.clo_cda_contract_lvl` | SIG01 and SIG06 |
| `02_facilities_limits` | `delta.prod_credit_and_lending_gda.facilities_limits` | SIG02 and SIG07 |
| `03_kyc` | `delta.prod_party_gda.kyc` | SIG04 |
| `04_covenants` | `delta.prod_credit_and_lending_gda.covenants` | SIG06 |
| `05_drr_facility_limits` | `delta.prod_credit_and_lending_mda.drr_facility_limits` | SIG06 |
| `06_pvd_omnia_drr` | `hive.pvd_prod_wave.pvd_omnia_drr` | SIG06 and SIG07 |
| `07_pvd_omnia_drr_agg_sec_app` | `hive.pvd_prod_wave.pvd_omnia_drr_agg_sec_app` | Excluded from active scope; legacy sample SQL |
| [Application Ratings sample pack](../../pvd_client_cohort_lab/sql_templates/sig07_application_ratings_20261104/README.md) | `delta.prod_credit_and_lending_gda.application_ratings` | SIG07 candidate; metadata-aware three-client samples added 4 November |

Each folder has `01_schema.sql` and `02_raw_sample.sql`. CLO also has `03_date_and_grain_profile.sql` and `04_facility_history_sample.sql`.

The separate Application Ratings pack uses schema/DDL and a metadata query that
returns sample/profile SQL for the exact three clients; follow its linked guide.
The legacy sector-aggregate folder is excluded from the active project scope.

## Run order

1. Open a source folder and run the statements in `01_schema.sql` individually. Export the column list and tabular schema separately from the table definition. Inspect partition properties and the object type. If an object is a view, replace `SHOW CREATE TABLE` with `SHOW CREATE VIEW` for that statement.
2. Review `02_raw_sample.sql`. The six sources without a confirmed schema use `SELECT t.* LIMIT 100` deliberately to avoid invented fields. After schema inspection, add a verified partition/date and client predicate where needed, then replace `t.*` with the columns relevant to the signal. Some connectors require a partition predicate before they will allow a query.
3. For CLO, edit the fixed `run_date` bounds in each of its three sample/profile queries to an available, useful source window. The starting example is `20260730` through `20261028`. Begin with a narrower known window where possible. Keep filters on the raw `YYYYMMDD` string rather than casting the partition column. Review the raw sample, then run the bounded date profile and facility history query as needed.
4. Save results with the query used, execution time, selected bounds and any client filters. Record zero rows and permission errors explicitly. A zero-row extract does not establish that no relevant event exists.

These SQL files return result sets. Use the SQL client's CSV export for data and schema results, and save table definitions as text. They do not write to HDFS or create database tables. Multiple statements can require separate execution depending on the client.

`LIMIT 100` limits the output, not necessarily scan cost. An unordered sample is arbitrary and may contain only one client or many repeated rows. Use verified client and date filters to build meaningful examples after the first schema inspection. Cross-source match rates cannot be inferred from independently limited samples.

## CLO interpretation

The supplied example documents exploded contract/account rows with repeated facility amounts. The history query uses one row per **candidate facility key, source system, mapping system, booking entity and run date**, rather than adding up repeated amounts. The key follows the example's fallback order of `sub_lim_id`, `rct_facility_ref`, then `facility_id`, with a prefix identifying the chosen tier. Confirm its business scope and stability; a change in the available key tier can split a facility's history.

The history query seeds up to 20 keys from at most 1000 arbitrary REV rows. It then reads all states of those keys in the selected window. It can return fewer than 20 facilities because the table is exploded. The seed is not random, stable between runs or representative. For reproducible client examples, replace the seed selection with a fixed list of verified scoped keys.

`snapshot_rank = 1` means the newest observed record date for that scoped key within the selected window. Dates can differ across facilities. This is not a complete current snapshot. Closure/status handling and source-date meaning still need source-owner confirmation. A facility absent from the window is absent from the output, and a missing later closure record cannot be inferred.

The previous example applies product, positive-limit and maturity filters before choosing the latest eligible state. That can retain an older eligible record when a later state is ineligible. The new diagnostic history deliberately retains later non-REV, zero-limit and expired records where they exist under the same key. No production eligibility rule is being selected here.

Facility currency, product, limit, pre-aggregated drawn amount and maturity are returned only when their non-null values agree within a facility/date group. The native-currency limit also requires one known currency. Distinct-value counts expose disagreements; invalid numeric counts expose failed conversions. `MAX` does not resolve conflicting amounts. Descriptive `example_*` fields are illustrative values, with client identifier counts provided for review. Missing values still need inspection in the raw sample.

`account_balance_drawn_amount_usd` remains in the raw sample and is not treated as interchangeable with `ag_acc_bal_drawn_sub_lim_usd`. No HSBC participation inference, FX fallback, EUR 50 million filter or 70% utilisation trigger is applied. Units and business definitions need validation first.

## Unresolved sources and joins

Run `00_discover_unresolved_sources.sql` to search the two known catalogs for Counterparty Core and SF Approval names. Results depend on metadata visibility; no result does not prove absence. Once a location is confirmed, adapt an existing schema/sample pair to that exact object.

SIG03 pre-hedging has no identified table. SIG07 now has Facilities Limits, PVD
and Application Ratings as candidates; an advisory-specific event mapping remains
open. Application credit ratings should not be assumed to represent advisory activity.

Do not join covenants to DRR yet. The workbook records unsuccessful identifier matching. First identify keys, data grain, dates and units in the samples, then extract a shared client/facility cohort and measure join coverage and multiplicity. Keep original identifiers, including leading zeros and prefixes. Dataset refresh timestamps do not by themselves establish KYC business events, and `facility_creation_dt` is still a candidate proxy rather than a confirmed signing date.

The Facilities Limits HDFS URI is preserved in the source reference. These queries access catalog tables. Do not replace a table identifier with an HDFS URI, or assume SQL and Spark see the same physical source version.

## Schema command references

The metadata statements follow Trino's [SHOW COLUMNS](https://trino.io/docs/current/sql/show-columns.html) and [SHOW CREATE TABLE](https://trino.io/docs/current/sql/show-create-table.html) syntax. Samples use [SELECT and LIMIT](https://trino.io/docs/current/sql/select.html). Run against the actual Starburst environment to validate connector support, fields, permissions and performance.

## Validation performed

All 18 SELECT statements were parsed with a Trino SQL parser. The 14 SHOW statements were checked against the documented syntax. The three CLO sample/profile queries were translated and executed in DuckDB using synthetic records covering repeated amounts, differing source dates, later ineligible states, identifier scope, missing keys, conflicting values and invalid numbers. The history query also returned an empty result for empty input.

These checks validate local syntax and diagnostic behaviour. The queries have not been executed against Starburst, and no source data has been extracted yet.
