-- Engine: Starburst / Trino. Read-only discovery sample.
-- Signals: SIG02 new facilities and SIG06 identifier mapping
-- Inspect facility_id, client/CIN keys, product codes, facility_creation_dt, loan_approva_dt and record_start_dt. Confirm exact names and types.
-- Run 01_schema.sql first. Names of partition/date/client columns are not yet validated.
-- SELECT * is intentional for the first schema-discovery sample only.
-- LIMIT caps returned rows, not bytes scanned. No ordering or representativeness is implied.
-- If this source requires a partition predicate, add its verified predicate before running.
-- After inspection, replace t.* with the required fields and add a verified client/date filter.
-- No latest-date, signing-event or covenant-pressure rule is assumed here.

SELECT t.*
FROM "delta"."prod_credit_and_lending_gda"."facilities_limits" t
LIMIT 100;
