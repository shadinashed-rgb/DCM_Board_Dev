-- Engine: Starburst / Trino. SIG01 bounded source profile.
-- EDIT date literals below; begin with the smallest useful known source window.
-- This aggregates all rows in that window, so it can cost much more than a raw sample.
-- Do not filter to a global max(run_date): compare dates by source and mapping system.
-- Fields come from the supplied CLO example. Confirm them with 01_schema.sql.

WITH scoped AS (
    SELECT
        t.run_date,
        t.source_system,
        t.mapping_system,
        t.hsbc_booking_legal_entity,
        t.local_product_type_lbs,
        coalesce(
            'SUB_LIMIT:' || nullif(trim(t.sub_lim_id), ''),
            'RCT_REF:' || nullif(trim(t.rct_facility_ref), ''),
            'FACILITY_ID:' || nullif(trim(t.facility_id), '')
        ) AS facility_key
    FROM "hive"."clo_prod"."clo_cda_contract_lvl" t
    WHERE t.run_date >= '20260730'
      AND t.run_date <= '20261028'
)
SELECT
    run_date,
    source_system,
    mapping_system,
    hsbc_booking_legal_entity,
    count(*) AS raw_rows,
    count(DISTINCT facility_key) AS distinct_candidate_facility_keys,
    sum(CASE WHEN facility_key IS NULL THEN 1 ELSE 0 END) AS rows_without_facility_key,
    sum(CASE WHEN upper(trim(local_product_type_lbs)) = 'REV' THEN 1 ELSE 0 END) AS raw_rev_rows
FROM scoped
GROUP BY run_date, source_system, mapping_system, hsbc_booking_legal_entity
ORDER BY run_date DESC, source_system, mapping_system, hsbc_booking_legal_entity;
