-- Engine: Starburst / Trino. SIG01 raw RCF sample; no aggregation or FX inference.
-- Field names and varchar YYYYMMDD run_date convention come from extract_clo_rev_universe.sql.
-- Confirm the live schema first. EDIT the two date literals to a known available window.
-- The example window ends on 2026-10-28; it is not an assertion of source freshness.
-- Raw partition comparisons preserve the opportunity for partition pruning.
-- This table is exploded. These 100 rows can contain repeated facilities and amounts.
-- No live-facility or EUR 50m filter: retain evidence needed to validate source semantics.
-- Optional cohort filter after schema review:
--   AND cast(t.rct_mastergroup_id AS varchar) IN ('your_real_mastergroup_id')

SELECT
    t.run_date,
    t.source_system,
    t.mapping_system,
    t.hsbc_booking_legal_entity,
    t.rct_mastergroup_id,
    t.rct_mastergroup_name,
    t.obligor_cin,
    t.obligor_customer_name,
    t.sub_lim_id,
    t.rct_facility_ref,
    t.facility_id,
    t.facility_name,
    t.local_product_type_lbs,
    t.facility_currency,
    t.facility_limit_amount,
    t.ag_acc_bal_drawn_sub_lim_usd,
    t.account_balance_drawn_amount_usd,
    t.instrument_currency_fx_to_usd,
    t.facility_maturity_date
FROM "hive"."clo_prod"."clo_cda_contract_lvl" t
WHERE t.run_date >= '20260730'
  AND t.run_date <= '20261028'
  AND upper(trim(t.local_product_type_lbs)) IN ('REV')
LIMIT 100;
