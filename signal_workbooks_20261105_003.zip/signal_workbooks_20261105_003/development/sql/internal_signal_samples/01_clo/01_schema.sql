-- Engine: Starburst / Trino. Read-only. Source: InternalSignalsDataSources.xlsx, Sheet1.
-- Signals: SIG01 RCF drawings
-- Review REV classification, repeated facility amounts, run_date coverage and identifier scope.
-- Run statements separately and export each result separately.

-- 1. Columns, types, connector extras and comments.
SHOW COLUMNS FROM "hive"."clo_prod"."clo_cda_contract_lvl";

-- 2. Definition and exposed storage/partition properties. This SHOW does not create a table.
-- If the object is a view, run SHOW CREATE VIEW instead of this statement.
SHOW CREATE TABLE "hive"."clo_prod"."clo_cda_contract_lvl";

-- 3. Tabular schema suitable for CSV export.
SELECT
    table_catalog,
    table_schema,
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable
FROM "hive".information_schema.columns
WHERE table_schema = 'clo_prod'
  AND table_name = 'clo_cda_contract_lvl'
ORDER BY ordinal_position;
