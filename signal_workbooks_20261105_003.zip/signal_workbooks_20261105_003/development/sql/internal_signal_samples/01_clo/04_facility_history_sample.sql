-- Engine: Starburst / Trino. SIG01 diagnostic history for up to 20 candidate facility keys.
-- EDIT date literals in bounded below. They are fixed for reproducibility.
-- Seeds come from an arbitrary maximum of 1000 REV rows, then up to 20 distinct scoped keys.
-- This is a convenience cohort, not a random or representative sample. Exploded rows can
-- leave far fewer than 20 facilities. For known-client work, add a verified client filter
-- inside bounded; do not prefilter maturity, positive limits or product there.
-- All product/states of the selected keys in the window are retained. This avoids hiding
-- later zero/expired/non-REV states behind a latest-eligible record. Explicit status/closure
-- fields are not in the example and still require schema review.
-- Key scope includes source, mapping system and booking entity. Confirm business uniqueness.
-- Prefixes prevent a sub-limit ID from colliding with the same text in another key tier.
-- Never SUM repeated facility amounts. Conflicting non-null facility values return NULL
-- with a distinct-value count. Account-level drawn values remain separate in the raw file.
-- No cross-date/currency FX fallback or EUR threshold is applied.

WITH bounded AS (
    SELECT
        t.run_date,
        t.source_system,
        t.mapping_system,
        t.hsbc_booking_legal_entity,
        t.rct_mastergroup_id,
        t.rct_mastergroup_name,
        t.obligor_cin,
        t.obligor_customer_name,
        t.sub_lim_id,
        t.rct_facility_ref,
        t.facility_id,
        t.facility_name,
        t.local_product_type_lbs,
        t.facility_currency,
        t.facility_limit_amount,
        t.ag_acc_bal_drawn_sub_lim_usd,
        t.account_balance_drawn_amount_usd,
        t.instrument_currency_fx_to_usd,
        t.facility_maturity_date,
        coalesce(
            'SUB_LIMIT:' || nullif(trim(t.sub_lim_id), ''),
            'RCT_REF:' || nullif(trim(t.rct_facility_ref), ''),
            'FACILITY_ID:' || nullif(trim(t.facility_id), '')
        ) AS facility_key
    FROM "hive"."clo_prod"."clo_cda_contract_lvl" t
    WHERE t.run_date >= '20260730'
      AND t.run_date <= '20261028'
),
seed_rows AS (
    SELECT facility_key, source_system, mapping_system, hsbc_booking_legal_entity
    FROM bounded
    WHERE facility_key IS NOT NULL
      AND upper(trim(local_product_type_lbs)) IN ('REV')
    LIMIT 1000
),
cohort AS (
    SELECT DISTINCT facility_key, source_system, mapping_system, hsbc_booking_legal_entity
    FROM seed_rows
    LIMIT 20
),
history AS (
    SELECT b.*
    FROM bounded b
    JOIN cohort c
      ON b.facility_key = c.facility_key
     AND b.source_system IS NOT DISTINCT FROM c.source_system
     AND b.mapping_system IS NOT DISTINCT FROM c.mapping_system
     AND b.hsbc_booking_legal_entity IS NOT DISTINCT FROM c.hsbc_booking_legal_entity
),
facility_dates AS (
    SELECT
        facility_key,
        source_system,
        mapping_system,
        hsbc_booking_legal_entity,
        run_date,
        max(rct_mastergroup_id) AS example_mastergroup_id,
        max(rct_mastergroup_name) AS example_mastergroup_name,
        max(obligor_cin) AS example_obligor_cin,
        max(facility_name) AS example_facility_name,
        count(*) AS exploded_row_count,
        count(DISTINCT rct_mastergroup_id) AS distinct_mastergroup_ids,
        count(DISTINCT obligor_cin) AS distinct_obligor_cins,
        count(DISTINCT local_product_type_lbs) AS distinct_product_values,
        CASE WHEN count(DISTINCT local_product_type_lbs) = 1
             THEN max(local_product_type_lbs) END AS local_product_type_lbs,
        count(DISTINCT facility_currency) AS distinct_currency_values,
        CASE WHEN count(DISTINCT facility_currency) = 1
             THEN max(facility_currency) END AS facility_currency,
        count(DISTINCT try_cast(facility_limit_amount AS double)) AS distinct_limit_values,
        CASE WHEN count(DISTINCT try_cast(facility_limit_amount AS double)) = 1
                  AND count(DISTINCT facility_currency) = 1
             THEN max(try_cast(facility_limit_amount AS double)) END AS facility_limit_amount,
        count(DISTINCT try_cast(ag_acc_bal_drawn_sub_lim_usd AS double)) AS distinct_drawn_values,
        CASE WHEN count(DISTINCT try_cast(ag_acc_bal_drawn_sub_lim_usd AS double)) = 1
             THEN max(try_cast(ag_acc_bal_drawn_sub_lim_usd AS double)) END AS ag_acc_bal_drawn_sub_lim_usd,
        count(DISTINCT facility_maturity_date) AS distinct_maturity_values,
        CASE WHEN count(DISTINCT facility_maturity_date) = 1
             THEN max(facility_maturity_date) END AS facility_maturity_date,
        sum(CASE WHEN facility_limit_amount IS NOT NULL
                       AND try_cast(facility_limit_amount AS double) IS NULL
                 THEN 1 ELSE 0 END) AS invalid_limit_rows,
        sum(CASE WHEN ag_acc_bal_drawn_sub_lim_usd IS NOT NULL
                       AND try_cast(ag_acc_bal_drawn_sub_lim_usd AS double) IS NULL
                 THEN 1 ELSE 0 END) AS invalid_drawn_rows
    FROM history
    GROUP BY facility_key, source_system, mapping_system, hsbc_booking_legal_entity, run_date
)
SELECT
    f.*,
    row_number() OVER (
        PARTITION BY facility_key, source_system, mapping_system, hsbc_booking_legal_entity
        ORDER BY run_date DESC
    ) AS snapshot_rank,
    lag(run_date) OVER (
        PARTITION BY facility_key, source_system, mapping_system, hsbc_booking_legal_entity
        ORDER BY run_date
    ) AS previous_observed_run_date
FROM facility_dates f
ORDER BY facility_key, source_system, mapping_system, hsbc_booking_legal_entity, run_date DESC;
