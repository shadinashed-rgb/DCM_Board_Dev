-- Engine: Starburst / Trino. Read-only. Source: InternalSignalsDataSources.xlsx, Sheet1.
-- Signals: SIG06 additional candidate asset
-- Establish aggregation grain and keys before comparing with facility-level data. This location was listed without separate investigation results.
-- Run statements separately and export each result separately.

-- 1. Columns, types, connector extras and comments.
SHOW COLUMNS FROM "hive"."pvd_prod_wave"."pvd_omnia_drr_agg_sec_app";

-- 2. Definition and exposed storage/partition properties. This SHOW does not create a table.
-- If the object is a view, run SHOW CREATE VIEW instead of this statement.
SHOW CREATE TABLE "hive"."pvd_prod_wave"."pvd_omnia_drr_agg_sec_app";

-- 3. Tabular schema suitable for CSV export.
SELECT
    table_catalog,
    table_schema,
    table_name,
    ordinal_position,
    column_name,
    data_type,
    is_nullable
FROM "hive".information_schema.columns
WHERE table_schema = 'pvd_prod_wave'
  AND table_name = 'pvd_omnia_drr_agg_sec_app'
ORDER BY ordinal_position;
