Continue the existing Bond Radar project in this workspace. First read AGENTS.md, START_HERE.md, PROJECT_STATE.md, DATA_MODEL.md and NEXT_STEPS.md. Do not restart source discovery or create another replacement package.

We are developing a banker-facing dashboard locally for Vodafone MG001356, Siemens Energy MG102229 and SoftBank MG101624. The active code is pvd_client_cohort_lab. I execute SQL manually by copying it into Starburst, download CSVs to my drive and transfer them locally for Python. Give one clear sequence with exact SQL and CSV filenames.

The selected raw data are in data/, and the current combined result is results/ALL_SIGNALS_WITH_CRR.csv: 604 earlier evidence rows plus 10 Application Ratings CRR records. These are development evidence, not confirmed alerts. The full Application Ratings export is still absent. Check PROJECT_STATE for missing data and assumptions before proposing changes.

Key decisions: no SIG05 or PVD sector aggregate; missing drawn amounts become zero only for SIG01 with imputation flags; Counterparty is delta.prod_party_gda.counterparty_core; add CRR only from Application Ratings for SIG07 while retaining existing Facilities/PVD context. Names and PVD identifier shapes never establish approved entity joins. Keep raw exports immutable and preserve source/date/grain/lineage. Follow the reference rebuild and tests before relying on changed results.

If I say this is planning or ask you not to change anything, inspect and discuss only. Otherwise make the requested changes in this workspace, preserve prior runs, and explain the outcome simply.

My next request is: [replace this sentence with what you want to do next].
