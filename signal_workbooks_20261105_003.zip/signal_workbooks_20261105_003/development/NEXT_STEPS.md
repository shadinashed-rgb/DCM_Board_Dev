# Resume development without repeating discovery

## First: inspect/rebuild the supplied baseline

Follow START_HERE.md. It does not require a new extraction. Review the existing 614-row CSV and group/source coverage before changing logic. The 614 rows are evidence, with unverified triggers.

## Next extraction: full CRR-only data

Use these SQLs in `pvd_client_cohort_lab/sql_templates/sig07_crr_20261104/`. Copy each query into Starburst, run it manually, download the CSV, and move it into **`data/application_ratings_full/`** with the following exact name:

| Run SQL | Save data as |
| --- | --- |
| 01_vodafone_crr.sql | application_ratings_vodafone_full.csv |
| 02_siemens_energy_crr.sql | application_ratings_siemens_energy_full.csv |
| 03_softbank_crr.sql | application_ratings_softbank_full.csv |

These use the observed candidate CIN lookups and pinned run_date=20261103. Check snapshot availability before changing the date; use a consistent verified date across all three clients. No 100-row cap is included. At the profiled snapshot, expected raw counts were 477 / 238 / 7; different counts need reconciliation, not forced truncation. CIN scope is still development discovery evidence.

Keep only data files in that folder; store the exact submitted queries, date profiles, errors and export notes beside it in a separate evidence folder. Preserve IDs/grades as text. Do not assume a downloaded error CSV is an empty dataset.

From the workspace root, after the three actual full exports are present:

```sh
python3 -B pvd_client_cohort_lab/sig07_crr.py \
  --input data/application_ratings_full \
  --base analysis/dcm_run_003_review_20261103/DCM_Run_003_All_Signal_Evidence.csv \
  --as-of 2026-11-04 \
  --out runs/crr_full_001
```

Use the actual assessment date and a fresh output name. This supplements the existing 604-row baseline without re-extracting all other sources. Do not expect 614 rows after changing to full data: that count describes the supplied samples only. Review selection reductions, multiple-CRR flags, unavailable values, dates and CIN linkage; do not interpret more application versions as more advisory opportunities.

## Then: targeted validation, in order

| Question | Existing evidence / SQL | Needed outcome |
| --- | --- | --- |
| Do the five >70% exposures qualify? | PROJECT_STATE SIG06 and DRR raw / output lineage | Confirm product dictionary, eligible commitments, units, currencies, participation and exposure hierarchy |
| Are eight recent Facilities creations real eligible events? | Current Facilities file and SIG02 evidence | Confirm signing/creation meaning, product types, duplicate borrowers/products and amounts |
| Did global latest selection omit Siemens DE? | analysis/dcm_run_003_review_20261103/next_checks/01_facilities_partition_dates.sql and data/history/ | Verify publishing grain before implementing per-source/country current selection |
| Where are actual financial covenants? | next_checks/02_covenants_schema.sql and 03_covenant_candidate_counts.sql | Return real covenant columns/tests, not the Counterparty export; verify relationship namespace |
| Is PVD September the correct available vintage? | next_checks/04_pvd_client_vintages.sql | Confirm partitions/freshness and amount/currency/grain semantics |
| Can KYC find a known target case? | Current array-aware KYC SQL and schema | Known case/entity ID, verified mapping, purpose/date definitions |
| What triggers rating advisory? | CRR applications plus limit_cat/advised_ind/PVD context | Owner-defined scale, period/version semantics and engagement/event criterion |
| What provides SIG03? | Requirements / original meeting notes | Identify enquiry/pricing request source and event contract |

The `next_checks/` path in the table is under `analysis/dcm_run_003_review_20261103/`. Inspect schema statements separately where instructed. Do not adopt a guessed column or broaden names to hide a failed ID route.

## New multi-source rounds

Do not ingest the historical `sql/DCM_Run_003/` folder directly: its misleading covenant file is quarantined. For new rounds, use a fresh incoming folder, not a mixture of snapshots from unrelated runs. The latest general extraction templates are in `pvd_client_cohort_lab/sql_templates/current_20261103/`; inspect them with the known source-date/grain gaps above before running a later round.

If a new round supplies the same six sources and ratings files, use the portable runner with explicit folders/dates and a new output path, omitting `--verify-reference`:

```sh
python3 -B run_reference.py \
  --input data/round_next \
  --ratings-input data/application_ratings_full \
  --base-as-of 2026-11-04 --as-of 2026-11-04 \
  --out runs/round_next_001 --test-observed-links
```

Replace these example dates with actual assessment dates. The observed-link flag remains a test assumption. For genuine reviewed mappings or a new source such as actual covenants, use the active refresh/cohort workflows with `--approved`, validate source recognition/namespace rules, then update the exporter if needed. The root runner is a reference convenience, not a validated interface for every future source.

After resolving source grain, build the parent/product/borrower model and verified signal definitions, then a three-client banker view with clear dates, availability and lineage. Do not postpone data validation in favour of a polished alert count.
