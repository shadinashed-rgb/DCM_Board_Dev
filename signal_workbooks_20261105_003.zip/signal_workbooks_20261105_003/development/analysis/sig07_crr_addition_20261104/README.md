# CRR added to SIG07, 4 November 2026

Application Ratings contributes **CRR only** in this addition, using the available
207 sample rows. The current-candidate rule selects latest supplied snapshots by
source/country/CARM instance, followed by record periods covering that snapshot.
It preserves competing applications and the raw latest/approval flags.

Ten application records remain: Vodafone one, Siemens seven, SoftBank two. Nine
have a non-placeholder final_crr; one has N/A and is unavailable. Missing ratings
are not zero and no approved/proposed fallback is applied. The current-period
rule, entity scope and CIN associations remain unverified development assumptions.

- `SIG07_Application_Ratings_CRR.csv`: ten application CRR context records.
- `DCM_Run_003_All_Signal_Evidence_With_CRR.csv`: previous 604 rows plus ten CRR
  records, for 614. Existing sources remain available; new Application Ratings
  evidence contains no external agency values or category/advisory inference.
- `manifest.json`: row counts, selection reductions and unchanged input hashes.

All advisory business_trigger values are blank. Multiple CRRs under a CIN are
flagged and kept; they are not averaged or reduced to a single group rating.
The source snapshot is 3 November; this addition is assessed on 4 November.

The reusable adapter is `pvd_client_cohort_lab/sig07_crr.py`. Full-cohort CRR-only
SQL and rebuild instructions are in
`pvd_client_cohort_lab/sql_templates/sig07_crr_20261104/README.md`.
