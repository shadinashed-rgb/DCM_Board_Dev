import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook } from '@oai/artifact-tool';

const packages = JSON.parse(await fs.readFile(process.argv[2], 'utf8'));
const output = process.argv[3];
const inspection = [];
const escape = value => {
  const text = value === null || value === undefined ? '' : String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text;
};
for (const item of packages) {
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add('Data');
  const rows = item.matrix.length;
  const columns = item.matrix[0].length;
  sheet.getRangeByIndexes(0,0,rows,columns).setNumberFormat('@');
  // Values remain original strings, including leading zeros and categorical CRRs.
  for (let start=0; start<rows; start+=128) {
    const batch=item.matrix.slice(start,start+128);
    sheet.getRangeByIndexes(start,0,batch.length,columns).values=batch;
  }
  workbook.recalculate();
  const inspected = await workbook.inspect({kind:'table',range:'Data!A1:F5',tableMaxRows:5,tableMaxCols:6,maxChars:1800});
  inspection.push({file:item.filename,rows:rows-1,columns,inspection:inspected.ndjson});
  const chunks=[];
  for (let start=0; start<rows; start+=128) {
    const saved=sheet.getRangeByIndexes(start,0,Math.min(128,rows-start),columns).values;
    for (let offset=0;offset<saved.length;offset++) {
      const exact=saved[offset].map(v=>v===null || v===undefined ? '' : String(v));
      if (JSON.stringify(exact)!==JSON.stringify(item.matrix[start+offset])) {
        const differences=exact.flatMap((value,col)=>value===item.matrix[start+offset][col]?[]:[{
          field:item.matrix[0][col],expected:item.matrix[start+offset][col],actual:value
        }]);
        throw new Error('Artifact value preservation failed for '+item.filename+' row '+(start+offset+1)+' '+JSON.stringify(differences));
      }
      chunks.push(exact.map(escape).join(',')+'\r\n');
    }
  }
  await fs.writeFile(path.join(output,item.filename),'\uFEFF'+chunks.join(''),{flag:'wx'});
  console.log(item.filename+': '+(rows-1)+' rows, '+columns+' columns');
}
await fs.writeFile(path.join(output,'ARTIFACT_INSPECTION.json'),JSON.stringify(inspection,null,2)+'\n',{flag:'wx'});
