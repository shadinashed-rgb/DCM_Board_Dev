"""Package existing signal evidence and original CSV records without new joins."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv'
CLIENTS = {'MG001356':'VODAFONE', 'MG102229':'Siemens Energy', 'MG101624':'SOFTBANK'}
TABLES = {
    'clo':'hive.clo_prod.clo_cda_contract_lvl',
    'drr':'delta.prod_credit_and_lending_mda.drr_facility_limits',
    'facilities':'delta.prod_credit_and_lending_gda.facilities_limits',
    'pvd':'hive.pvd_prod_wave.pvd_omnia_drr',
    'kyc':'delta.prod_party_gda.kyc',
    'counterparty':'delta.prod_party_gda.counterparty_core',
    'application_ratings':'delta.prod_credit_and_lending_gda.application_ratings',
}
SPECS = {
    'SIG01':('RCF drawing increase', ['clo'], 'Three comparisons use missing drawn as zero with explicit flags; no observed increase or agreed materiality trigger.'),
    'SIG02':('New facility context', ['facilities'], 'Creation-event and product meanings unverified; 90-day lookback is a development test. German extraction deferred.'),
    'SIG03':('Enquiry or pricing activity', [], 'Source not identified. No assessable events supplied; this does not establish no activity.'),
    'SIG04':('KYC activity', ['kyc'], 'Target KYC file is header-only. No assessable events supplied; this does not establish no activity.'),
    'SIG06':('Utilisation and covenant evidence', ['clo','drr','pvd'], 'Strict >70% flags are arithmetic tests; product, units, participation and hierarchy unverified. Genuine financial covenants missing.'),
    'SIG07':('Rating and advisory context', ['facilities','pvd','application_ratings'], 'Application Ratings contributes CRR only. Scales, version rules and advisory criteria unverified; retain competing applications.'),
}
NATIVE_FILES = {'clo':'clo_current_and_previous.csv', 'drr':'drr_current.csv',
    'facilities':'facilities_current.csv','pvd':'pvd_current.csv','kyc':'kyc_current.csv',
    'counterparty':'counterparty_current.csv'}
SOURCE_DATE = {'clo':'run_date','drr':'reporting_date','facilities':'run_date','pvd':'joi_date',
    'kyc':'run_date','counterparty':'run_date','application_ratings':'run_date'}
COMMON_NOTE = 'Development evidence; business triggers unverified. Candidate identity links are not production approvals. Do not sum mixed currencies, sources, snapshots or parent/child amounts.'
SUMMARY_FIELDS = ['summary_scope','evidence_rows','needs_validation_rows','unavailable_evidence_rows',
    'above_70_test_candidates','recent_creation_test_candidates','zero_imputed_comparisons',
    'populated_application_crr','unavailable_application_crr','historical_application_contexts',
    'multiple_crr_application_rows','distinct_raw_records_used','raw_evidence_links',
    'unselected_raw_context_records','historical_context_records','coverage_status','summary_text']
META_FIELDS = ['row_type','row_note','linked_evidence_ids','linked_mastergroup_ids','linked_client_names',
    'linked_roles','raw_source_file','raw_source_record','raw_reference','raw_source_table',
    'raw_observation_date_field','raw_observation_date','raw_file_sha256','raw_record_sha256']


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader=csv.DictReader(handle)
        rows=list(reader)
        fields=reader.fieldnames or []
    if len(fields)!=len(set(fields)) or any(None in r or None in r.values() for r in rows):
        raise ValueError(f'Malformed CSV: {path}')
    return fields,rows


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def row_sha(row):
    return hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def matrix(fields, rows):
    return [fields]+[[str(r.get(k,'')) for k in fields] for r in rows]


def export(output):
    if output.exists():
        raise ValueError('Output exists; choose a fresh --out folder')
    evidence_fields,evidence=read(EVIDENCE)
    assert len(evidence)==len({r['evidence_id'] for r in evidence})==626
    assert all(not r['business_trigger'] for r in evidence)
    sources={}
    for source,filename in NATIVE_FILES.items():
        path=ROOT/'data/current_exports'/filename
        fields,rows=read(path)
        sources[filename]=dict(source=source,path=path,fields=fields,rows=rows,sha256=sha(path))
    for path in sorted((ROOT/'data/application_ratings_full').glob('*.csv')):
        fields,rows=read(path)
        sources[path.name]=dict(source='application_ratings',path=path,fields=fields,rows=rows,sha256=sha(path))
    history_path=ROOT/'data/history/facilities_siemens_de_20261030.csv'
    history_fields,history_rows=read(history_path)
    history=dict(source='facilities',path=history_path,fields=history_fields,rows=history_rows,sha256=sha(history_path))
    selected_input_hashes={str(d['path'].relative_to(ROOT)):d['sha256'] for d in list(sources.values())+[history]}
    selected_input_hashes[str(EVIDENCE.relative_to(ROOT))]=sha(EVIDENCE)
    for path,value in json.loads((ROOT/'runs/crr_full_001/manifest.json').read_text())['input_sha256'].items():
        assert sha(Path(path))==value
    packages=[]
    all_summaries=[]
    verification={}

    for signal,(name,primary_sources,note) in SPECS.items():
        ev=[r for r in evidence if r['signal_id']==signal]
        lookup={r['evidence_id']:r for r in ev}
        linked=defaultdict(set)
        for r in ev:
            for column,role in [('source_record_references','current_evidence'),('previous_source_record_references','prior_comparison')]:
                for ref in r[column].split(' | ') if r[column] else []:
                    match=re.fullmatch(r'([^:]+):record (\d+)',ref)
                    if not match:
                        raise ValueError('Invalid source reference: '+ref)
                    filename,record=match[1],int(match[2])
                    assert filename in sources and 2<=record<=len(sources[filename]['rows'])+1
                    assert sources[filename]['source'] in primary_sources
                    linked[(filename,record)].add((r['evidence_id'],role))
        primary=[d for d in sources.values() if d['source'] in primary_sources]
        include_history=signal in ('SIG02','SIG07')
        raw_records=[]
        raw_fields=list(dict.fromkeys(k for d in primary+([history] if include_history else []) for k in d['fields']))
        for data in primary+([history] if include_history else []):
            historical=data is history
            for record,raw in enumerate(data['rows'],2):
                links=set() if historical else linked.get((data['path'].name,record),set())
                ids=sorted({eid for eid,role in links})
                groups=sorted({lookup[eid]['mastergroup_id'] for eid in ids})
                kind='historical_context_not_used' if historical else 'raw_used' if links else 'raw_not_used'
                rec=dict(row_type=kind, signal_id=signal, signal_name=name, source=data['source'],
                    row_note='Archived DE snapshot, not used in the current evidence.' if historical else
                        'Exact original record linked to signal evidence; not an additional signal.' if links else
                        'Supplied raw context without a linked current evidence record; do not infer eligibility.',
                    linked_evidence_ids=' | '.join(ids),linked_mastergroup_ids=' | '.join(groups),
                    linked_client_names=' | '.join(CLIENTS[g] for g in groups),linked_roles=' | '.join(sorted({role for eid,role in links})),
                    raw_source_file=str(data['path'].relative_to(ROOT)),raw_source_record=record,
                    raw_reference=f'{data["path"].name}:record {record}',raw_source_table=TABLES[data['source']],
                    raw_observation_date_field=SOURCE_DATE[data['source']],raw_observation_date=raw.get(SOURCE_DATE[data['source']],''),
                    raw_file_sha256=data['sha256'],raw_record_sha256=row_sha(raw))
                rec.update({'raw__'+k:v for k,v in raw.items()})
                raw_records.append(rec)
        for scope,group,client in [('all_clients','','All three clients')]+[('client',g,c) for g,c in CLIENTS.items()]:
            subset=[r for r in ev if not group or r['mastergroup_id']==group]
            ids={r['evidence_id'] for r in subset}
            used={ref for ref,pairs in linked.items() if any(eid in ids for eid,role in pairs)}
            flags=Counter(r['assessment_status'] for r in subset)
            coverage='source_missing' if signal=='SIG03' else 'empty_export' if signal=='SIG04' else 'partial_development_evidence'
            summary=dict(row_type='signal_summary',signal_id=signal,signal_name=name,
                summary_scope=scope,mastergroup_id=group,client=client,
                evidence_rows=len(subset),needs_validation_rows=flags['needs_validation'],unavailable_evidence_rows=flags['unavailable'],
                above_70_test_candidates=sum(r['above_70_for_testing']=='True' for r in subset),
                recent_creation_test_candidates=sum(r['recent_creation_for_testing']=='True' for r in subset),
                zero_imputed_comparisons=sum(r['current_drawn_imputed_zero']=='True' for r in subset),
                populated_application_crr=sum(r['source']=='application_ratings' and bool(r['crr']) for r in subset),
                unavailable_application_crr=sum(r['source']=='application_ratings' and not r['crr'] for r in subset),
                historical_application_contexts=sum(r['source']=='application_ratings' and r['latest_record']=='HISTORICAL' for r in subset),
                multiple_crr_application_rows=sum(r['source']=='application_ratings' and r['multiple_crrs_for_cin']=='True' for r in subset),
                distinct_raw_records_used=len(used),raw_evidence_links=sum(eid in ids for pairs in linked.values() for eid,role in pairs),
                unselected_raw_context_records=sum(r['row_type']=='raw_not_used' for r in raw_records) if not group else '',
                historical_context_records=len(history_rows) if include_history and not group else '',
                coverage_status=coverage,summary_text=note,row_note=COMMON_NOTE)
            all_summaries.append(summary)
        summaries=all_summaries[-4:]
        detail=[dict(r,row_type='signal_evidence',row_note=COMMON_NOTE) for r in ev]
        coverage=[]
        if signal in ('SIG03','SIG04','SIG06'):
            for group,client in CLIENTS.items():
                is_kyc=signal=='SIG04'
                cov=dict(row_type='coverage',signal_id=signal,signal_name=name,mastergroup_id=group,client=client,
                    source='kyc' if is_kyc else 'enquiries' if signal=='SIG03' else 'covenants',
                    assessment_status='unavailable',coverage_status='empty_export' if is_kyc else 'source_missing',
                    row_note=note,source_table=TABLES['kyc'] if is_kyc else '',
                    raw_source_file='data/current_exports/kyc_current.csv' if is_kyc else '',
                    raw_file_sha256=sources['kyc_current.csv']['sha256'] if is_kyc else '')
                coverage.append(cov)
        fields=list(dict.fromkeys(['row_type','signal_id','signal_name','summary_scope','client','mastergroup_id']+
            SUMMARY_FIELDS+evidence_fields+META_FIELDS+['raw__'+k for k in raw_fields]))
        output_rows=summaries+detail+coverage+raw_records
        packages.append(dict(filename=signal+'.csv',matrix=matrix(fields,output_rows)))
        verification[signal]=dict(evidence_rows=len(ev),raw_records_used=len(linked),
            raw_not_used=sum(r['row_type']=='raw_not_used' for r in raw_records),
            historical_context_records=len(history_rows) if include_history else 0,
            coverage_rows=len(coverage),csv_rows=len(output_rows),csv_columns=len(fields))
        # Independent lossless check of every evidence field and native raw field.
        assert [{k:r[k] for k in evidence_fields} for r in detail]==ev
        assert {r['raw_reference'] for r in raw_records if r['row_type']=='raw_used'}=={f'{f}:record {n}' for f,n in linked}
        assert len(raw_records)==sum(len(d['rows']) for d in primary)+(len(history_rows) if include_history else 0)
        for r in raw_records:
            data=history if r['row_type']=='historical_context_not_used' else sources[Path(r['raw_source_file']).name]
            original=data['rows'][int(r['raw_source_record'])-2]
            assert all(r['raw__'+k]==v for k,v in original.items())

    summary_fields=list(dict.fromkeys(['row_type','signal_id','signal_name','summary_scope','mastergroup_id','client']+SUMMARY_FIELDS+['row_note']))
    packages.append(dict(filename='SIGNAL_SUMMARY.csv',matrix=matrix(summary_fields,all_summaries)))
    cp=sources['counterparty_current.csv']
    reference=[dict(reference_role='identity_reference_only',source='counterparty',source_table=TABLES['counterparty'],
        raw_source_file=str(cp['path'].relative_to(ROOT)),raw_source_record=i,
        row_note='Point-in-time mapping reference; no new entity joins or approvals inferred.',**{'raw__'+k:v for k,v in r.items()}) for i,r in enumerate(cp['rows'],2)]
    packages.append(dict(filename='IDENTITY_REFERENCE.csv',matrix=matrix(list(reference[0]),reference)))
    # All curated CSVs are inventoried, including superseded samples and quarantine.
    catalog={r['path']:r for r in read(ROOT/'DATA_CATALOG.csv')[1]}
    inventory=[]
    for path in sorted((ROOT/'data').rglob('*.csv')):
        rel=str(path.relative_to(ROOT))
        fields,records=read(path)
        meta=catalog.get(rel,{})
        if rel in selected_input_hashes:
            role='historical_context_only' if path==history_path else 'identity_reference_only' if path.name=='counterparty_current.csv' else 'selected_input'
        elif 'quarantine' in path.parts:
            role='quarantined_not_ingested'
        elif 'application_ratings' in path.parts and 'profile' not in path.stem:
            role='sample_superseded_by_full_not_ingested'
        elif 'validation_20261105_001' in path.parts:
            role='image_transcribed_profile_not_signal_facts'
        else:
            role='schema_profile_or_reference_not_signal_facts'
        inventory.append(dict(source_file=rel,package_role=role,source=meta.get('detected_source',''),
            rows=len(records),columns=len(fields),sha256=sha(path),original_catalog_role=meta.get('role',''),
            note='Preserved as a separate snapshot; no transitive identity expansion or archive-wide ingestion.'))
    packages.append(dict(filename='SOURCE_DATA_INVENTORY.csv',matrix=matrix(list(inventory[0]),inventory)))
    all_hashes=dict(selected_input_hashes)
    all_hashes.update({r['source_file']:r['sha256'] for r in inventory})
    output.mkdir(parents=True)
    with tempfile.TemporaryDirectory(prefix='bond_radar_signal_csv_') as temporary:
        payload=Path(temporary)/'packages.json'
        payload.write_text(json.dumps(packages,ensure_ascii=False))
        subprocess.run(['node',str(HERE/'write_signal_csvs.mjs'),str(payload),str(output)],check=True)
    # Read saved CSVs independently and require exact round-trip of every cell.
    for package in packages:
        with (output/package['filename']).open(encoding='utf-8-sig',newline='') as handle:
            saved=list(csv.reader(handle))
        assert saved==package['matrix'],package['filename']+' CSV round-trip mismatch'
    assert sum(x['evidence_rows'] for x in verification.values())==626
    assert all(sha(ROOT/path)==value for path,value in all_hashes.items())
    manifest=dict(export_date='2026-11-05',evidence_input=str(EVIDENCE.relative_to(ROOT)),
        evidence_rows=626,per_signal=verification,input_sha256=all_hashes,
        output_sha256={p['filename']:sha(output/p['filename']) for p in packages},
        qualification=COMMON_NOTE,verification='Every CSV cell round-tripped exactly; every evidence and raw field preserved; all source hashes unchanged.')
    (output/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(output=str(output),evidence_rows=626,per_signal=verification),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    export(ROOT/args.out)
