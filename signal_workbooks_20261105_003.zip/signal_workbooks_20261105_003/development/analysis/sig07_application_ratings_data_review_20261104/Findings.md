# SIG07 application-rating sample review

Reviewed **4 November 2026**. Source snapshot: **3 November 2026**.
Inputs: six CSVs in `sql/SIG07/application_ratings`. The SoftBank sample named
`application_ratings_softbank..csv` was recognised and reviewed without renaming.

## Conclusion

Application Ratings now provides actual **internal credit-rating context** for
all three client lookups. The samples also contain agency ratings in alternate
CRA fields for two historical Siemens application records. Advisory-event meaning
is still unresolved, and the capped Vodafone/Siemens samples are insufficient for
selecting current ratings or establishing complete client coverage.

**Next:** extract the complete matched cohort for the same one-day snapshot.
The profiles show only **722 matched rows** in total, so an uncapped extraction
is practical at this development scale and avoids further arbitrary 100-row samples.
Do not extract repeated daily snapshots of the same version history yet.

## Coverage and values

| Client | Rows supplied | Matched rows in profile | CINs sampled | Non-placeholder final_crr rows | Effective-period candidate rows |
| --- | ---: | ---: | ---: | ---: | ---: |
| Vodafone | 100 | 477 | 2 | 42 | 1 |
| Siemens Energy | 100 | 238 | 6 | 95 | 7 |
| SoftBank | 7 | 7 | 2 | 7 | 2 |

These are application/version observations, not group ratings, unique clients or
advisory events. Profile counts reflect the supplied candidate CIN predicates,
window and query time; they do not establish source-wide completeness. SoftBank
is complete relative to that query's seven matched rows, not all possible group CINs.
There are no exact duplicate rows within the supplied samples. All 207 source
record IDs are distinct within their respective client files.

The standard S&P/Moody/Fitch long/short-term fields are blank across all 207 rows.
However, checking alternate fields finds the following repeated rating context:

| Siemens customer | Provider code | Field/value | Rating date |
| --- | --- | --- | --- |
| SIEMENS ENERGY AG, CIN 2020052910083 | MY | long_term_rating_cra_5_fr = Baa1 | 17 December 2025 |
| Same customer | SP | long_term_rating_cra_6_fr = BBB; short_term_rating_cra_6_fr = A-2 | 11 December 2025 |

Those values appear in two application records, approved on 11 and 12 March 2026,
whose record periods ended on 11 March and 1 June respectively. They are not two
independent rating changes and should not automatically become current ratings.
The provider-code mapping and each field's entity/rating scope need confirmation.
The unsampled Vodafone/Siemens rows may contain more agency ratings.

`approved_crr` is blank in every supplied row. `final_crr` is populated on 160
rows, of which 16 are N/A, leaving 144 non-placeholder values. Proposed/manual
and overridden CRR fields also contain values. Preserve these separate states;
do not copy final_crr into approved_crr or average rating codes. Siemens includes
crr_scale 0 and 1, so comparison requires the scale definitions.

## Snapshot freshness and current-rating selection

All rows have run_date 20261103, but the application/approval history is much
older: Vodafone approval dates reach back to 1999, Siemens to 2003, and SoftBank
to 2025. A fresh dataset snapshot does not make every rating/application current.

Using record_start_dt/record_end_dt as a **candidate** validity rule gives ten
rows covering the snapshot: Vodafone one, Siemens seven, SoftBank two. All ten
have latest_approved_appl_flag=1. Six Siemens rows are nevertheless labelled
latest_record=HISTORICAL, so filtering solely on CURRENT would discard them.
This observed agreement does not validate either flag as the production rule.

The seven Siemens candidates cover five CINs. One CIN has multiple open-ended
applications, including different customer names and a final_crr=N/A record.
Do not pick one record per CIN or use MAX(final_crr). First check source/country,
CARM instance, customer/relationship IDs, application/proposal identifiers and
record validity. The entity scope of old mastergroup/customer names must also be
kept separate from the current target cohort association.

For context only, the supplied current-labelled Vodafone Finance row has
final_crr=3.1 and previous_crr=3.1; the two current-labelled SoftBank records also
have final_crr=3.1 for distinct customer/CIN associations. These are not established
group-level ratings or evidence of new advisory engagement.

## Advisory interpretation

scu_engagement_marker is N or blank across all samples; the associated marker
code is 01 or blank. No positive advisory event is identified. That is not proof
of no advisory activity because these fields' meanings have not been established.
Obtain definitions or a known ratings-advisory example before using them as a flag.

If SIG07 is intended to identify credit-rating changes, this source supplies
relevant context and version history, subject to a validated entity key, rating
state, effective date and scale. If SIG07 means advisory engagements, an explicit
business mapping or engagement source is still needed. Keep all three source
candidates while resolving that definition.

## Exact next step

Run the three uncapped, fixed-snapshot SQL files in `next_sql/`:

| SQL | Save CSV as | Expected rows from the previous profiles |
| --- | --- | ---: |
| 01_vodafone_full.sql | application_ratings_vodafone_full.csv | 477 |
| 02_siemens_energy_full.sql | application_ratings_siemens_energy_full.csv | 238 |
| 03_softbank_full.sql | application_ratings_softbank_full.csv | 7 |

Place them in `sql/SIG07/application_ratings_full/`. The queries preserve the
same candidate CIN filters and **pin run_date to 20261103**. They retain all
application versions and source columns, without an arbitrary cap, rating-value
filter or current/approved flag filter. Counts can change if the source is revised.
If that snapshot no longer exists, use the previously prepared client profiles
to identify the available date, then choose the same reviewed snapshot for all
three queries. An empty old snapshot is not absence of client data.

Once the full cohort is returned:

1. Derive the application/entity key and compare effective periods with the
   current/latest-approved flags; retain competing valid applications for review.
2. Normalise ratings into separate provider/type/state rows while preserving raw
   values, scale, rating date, approval date, source snapshot and lineage. Include
   both the named agency fields and alternate CRA/provider fields.
3. Validate one known approved/current rating and one known advisory case with
   the source owner/business. Agree SIG07's event and any change window/threshold.
4. Add the validated rating context to the consolidated signal evidence, retaining
   unavailable and unresolved states and separate entity/group scope.

## Review outputs and checks

- `review_samples.py` reproduces profiling and generates the next SQL files.
- `client_summary.csv` and `key_checks.csv` retain count and key diagnostics.
- `SIG07_application_rating_evidence.csv` contains all 207 preliminary rating
  observations, dates, raw entity/group labels, rating states and marker values;
  advisory_trigger is blank. Filename/CIN cohort association remains a candidate
  mapping, not proof of historical legal membership.
- `review.json` records all six original SHA-256 hashes and local query checks.
  Original input hashes are unchanged. Full queries were executed read-only in
  SQLite against the real supplied samples and preserved all their rows. This
  validates local selection behaviour, not live Starburst counts or field meaning.
- Existing production code, historical findings, consolidated 604-row signal
  evidence and release archives were not modified.
