# Extract the full three-client rating cohort

Run these three SELECTs manually in Starburst. They remove the arbitrary 100-row
sample cap and retain all versions within the **3 November 2026 snapshot**.

| SQL | Save result as |
| --- | --- |
| 01_vodafone_full.sql | application_ratings_vodafone_full.csv |
| 02_siemens_energy_full.sql | application_ratings_siemens_energy_full.csv |
| 03_softbank_full.sql | application_ratings_softbank_full.csv |

Transfer the results to **sql/SIG07/application_ratings_full/** in the project.
The earlier profiles reported 477, 238 and seven matching rows respectively.
Treat those as reconciliation expectations for that source query/time, not
guarantees of current counts or complete group coverage.

Do not filter on rating values, latest_record or latest_approved_appl_flag at
landing. Conflicting/multiple application states are part of the next review.
Preserve leading zeros and long identifiers as text. Download original CSVs
without spreadsheet conversion; keep empty-result headers and query errors.

If run_date 20261103 has been replaced in the source, use the earlier profile
queries to check available dates before changing all three to a consistent,
reviewed snapshot. Do not silently mix different client dates.

All three SQLs were checked locally on the supplied samples using read-only
SQLite. No live Starburst SELECT was executed during this review.
