"""Review actual SIG07 rating samples and prepare fixed-snapshot full-cohort SQL.

No production code or input exports are modified. The full queries remove the
arbitrary 100-row cap while retaining client CIN predicates and one observed
source snapshot. Internal ratings remain context, not advisory triggers.
"""
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT/'pvd_client_cohort_lab'))
from cohort import day, norm

INPUT=ROOT/'sql/SIG07/application_ratings'
SOURCE='"delta"."prod_credit_and_lending_gda"."application_ratings"'
CLIENTS=[('MG001356','VODAFONE','vodafone','application_ratings_vodafone.csv'),
         ('MG102229','Siemens Energy','siemens_energy','application_ratings_siemens_energy.csv'),
         ('MG101624','SOFTBANK','softbank','application_ratings_softbank..csv')]
AGENCY_FIELDS=['s_and_p_long_term_rating','s_and_p_short_term_rating','moody_long_term_rating','moody_short_term_rating','fitch_long_term_rating','fitch_short_term_rating']
EXTRA_CRA_FIELDS=['long_term_rating_cra_5_fr','long_term_rating_cra_6_fr','short_term_rating_cra_6_fr']
SENTINELS={None,'N/A','XNA','NO CRR','NONE','NULL'}


def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);rows=list(r)
        if any(None in row or None in row.values() for row in rows):raise ValueError('Malformed CSV '+str(path))
        return rows


def write(path,rows):
    with path.open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    if (OUT/'review.json').exists() or (OUT/'next_sql').exists():raise ValueError('Review output already exists')
    inputs=sorted(INPUT.glob('*.csv'))
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    plans={r['mastergroup_id']:r for r in read(ROOT/'sql/SIG07/03_generate_client_queries.csv')}
    db=sqlite3.connect(':memory:');db.row_factory=sqlite3.Row
    evidence=[];summary=[];all_rows=[];key_rows=[]
    for group,name,label,filename in CLIENTS:
        rows=read(INPUT/filename);all_rows+=rows
        profile=read(INPUT/f'application_ratings_{label}_profile.csv')
        assert len(profile)==1 and profile[0]['observation_date']=='20261103'
        population=int(profile[0]['raw_rows'])
        assert len(rows)<=population and {r['run_date'] for r in rows}=={'20261103'}
        effective=[]
        for record,row in enumerate(rows,2):
            lower,upper=day(row['record_start_dt']),day(row['record_end_dt'])
            valid_period=bool(lower and lower<='2026-11-03' and (row['record_end_dt']=='99991231' or upper and upper>='2026-11-03'))
            if valid_period:effective.append(row)
            valid_crr=norm(row['final_crr']) not in SENTINELS
            evidence.append(dict(mastergroup_id=group,client=name,source_file=filename,source_record=record,
                snapshot_date=day(row['run_date']),cin=row['cin'],source_system_name=row['source_system_name'],
                country_code=row['country_code'],carm_instance=row['carm_instance'],branch_code=row['branch_code'],
                customer_id=row['customer_id'],relationship_id=row['relationship_id'],customer_name=row['customer_name'],
                original_mastergroup_name=row['mastergroup_name'],credit_proposal_serial_no=row['credit_proposal_serial_no'],
                app_status=row['app_status'],record_start_date=lower or '',record_end_raw=row['record_end_dt'],
                effective_period_candidate=valid_period,latest_record=row['latest_record'],
                latest_approved_appl_flag=row['latest_approved_appl_flag'],approval_date=day(row['approval_dt']) or '',
                crr_scale=row['crr_scale'],proposed_crr=row['proposed_crr'],approved_crr=row['approved_crr'],
                final_crr=row['final_crr'],nonplaceholder_final_crr=valid_crr,previous_crr=row['previous_crr'],
                proposed_manual_crr=row['proposed_manual_crr'],overriden_crr=row['overriden_crr'],
                s_and_p_long_term_rating=row['s_and_p_long_term_rating'],moody_long_term_rating=row['moody_long_term_rating'],
                fitch_long_term_rating=row['fitch_long_term_rating'],
                cra_5_fr=row['cra_5_fr'],long_term_rating_cra_5_fr=row['long_term_rating_cra_5_fr'],cra_date_5_fr=day(row['cra_date_5_fr']) or '',
                cra_6_fr=row['cra_6_fr'],long_term_rating_cra_6_fr=row['long_term_rating_cra_6_fr'],short_term_rating_cra_6_fr=row['short_term_rating_cra_6_fr'],cra_date_6_fr=day(row['cra_date_6_fr']) or '',
                scu_engagement_marker=row['scu_engagement_marker'],
                scu_marker_code_type=row['scu_marker_code_type'],advisory_trigger='',interpretation='credit_rating_context;advisory_mapping_unverified;sample_coverage_limited'))
        summary.append(dict(mastergroup_id=group,client=name,sample_rows=len(rows),profile_matched_rows=population,
            sample_cins=len({r['cin'] for r in rows}),nonblank_final_crr=sum(norm(r['final_crr']) is not None for r in rows),
            nonplaceholder_final_crr=sum(norm(r['final_crr']) not in SENTINELS for r in rows),
            approved_crr_populated=sum(norm(r['approved_crr']) is not None for r in rows),
            standard_agency_fields_populated=sum(any(norm(r[c]) is not None for c in AGENCY_FIELDS) for r in rows),
            alternate_cra_fields_populated=sum(any(norm(r[c]) is not None for c in EXTRA_CRA_FIELDS) for r in rows),
            any_agency_rating_populated=sum(any(norm(r[c]) is not None for c in AGENCY_FIELDS+EXTRA_CRA_FIELDS) for r in rows),
            effective_period_candidate_rows=len(effective),effective_candidate_cins=len({r['cin'] for r in effective}),
            effective_candidate_nonplaceholder_crr=sum(norm(r['final_crr']) not in SENTINELS for r in effective),
            current_label_rows=sum(r['latest_record']=='CURRENT' for r in rows),
            latest_approved_flag_rows=sum(r['latest_approved_appl_flag']=='1' for r in rows),
            scu_marker_counts=json.dumps(dict(Counter(r['scu_engagement_marker'] for r in rows))),
            sample_is_complete_export=(len(rows)==population)))
        for fields in [('source_system_unique_id',),('source_system_name','country_code','cin','credit_proposal_serial_no')]:
            counts=Counter(tuple(r[c] for c in fields) for r in rows)
            key_rows.append(dict(client=name,columns=' | '.join(fields),distinct=len(counts),repeated_keys=sum(n>1 for n in counts.values())))

    folder=OUT/'next_sql';folder.mkdir()
    # Evaluate the full queries against the actual returned sample rows locally.
    columns=list(all_rows[0]);quote=lambda c:'"'+c.replace('"','""')+'"'
    db.execute('CREATE TABLE ratings('+','.join(quote(c)+' TEXT' for c in columns)+')')
    db.executemany('INSERT INTO ratings VALUES ('+','.join('?' for c in columns)+')',([r[c] for c in columns] for r in all_rows))
    db.execute('PRAGMA query_only=ON')
    checks=[]
    for index,(group,name,label,filename) in enumerate(CLIENTS,1):
        profile_sql=plans[group]['profile_sql']
        assert profile_sql.count(' t WHERE ')==1 and profile_sql.count(' GROUP BY ')==1
        where=profile_sql.split(' t WHERE ',1)[1].split(' GROUP BY ',1)[0]
        assert where.count(' AND (')==1
        identifiers='('+where.split(' AND (',1)[1]
        sql=f'''-- READ ONLY. Fixed observed snapshot; retain ALL matched application versions.
-- Expected counts from the earlier profiles are guidance, not a completeness promise.
-- Save as application_ratings_{label}_full.csv. Preserve identifiers as text.
-- Do not filter latest_record, approval flags, CRR or provider fields at landing.
SELECT t.* FROM {SOURCE} t
WHERE t."run_date" = '20261103'
  AND {identifiers}
ORDER BY t.country_code, t.cin, t.carm_instance, t.customer_id,
         t.credit_proposal_serial_no, t.record_start_dt;
'''
        returned=list(db.execute(sql.replace(SOURCE,'ratings')))
        original=read(INPUT/filename)
        # There is no hidden loss from moving from the capped plan to the uncapped query.
        assert len(returned)>=len(original)
        assert {r['run_date'] for r in returned}=={'20261103'}
        path=folder/f'{index:02d}_{label}_full.sql';path.write_text(sql)
        checks.append(dict(client=name,query=path.name,local_returned_sample_rows=len(returned)))
    db.close()
    write(OUT/'client_summary.csv',summary)
    write(OUT/'SIG07_application_rating_evidence.csv',evidence)
    write(OUT/'key_checks.csv',key_rows)
    assert len(evidence)==207
    assert sum(r['profile_matched_rows'] for r in summary)==722
    assert sum(r['nonplaceholder_final_crr'] for r in summary)==144
    assert sum(r['standard_agency_fields_populated'] for r in summary)==0
    assert sum(r['alternate_cra_fields_populated'] for r in summary)==2
    assert sum(r['effective_period_candidate_rows'] for r in summary)==10
    assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
    result=dict(review_date='2026-11-04',snapshot_date='2026-11-03',clients=summary,
        input_hashes=hashes,rows_reviewed=len(evidence),matched_rows_from_profiles=722,
        full_query_local_checks=checks,limitations=['Only supplied sample coverage, not source-wide completeness.',
            'Effective periods and latest-approved flags are candidate selection rules, not approved business semantics.',
            'Standard named agency fields blank; two historical Siemens rows repeat ratings in alternate CRA fields.',
            'No advisory marker mapping or rating-change scale has been approved.'])
    (OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
