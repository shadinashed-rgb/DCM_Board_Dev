"""Reproduce the review of manually returned Starburst exports; never changes inputs."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'pvd_client_cohort_lab'))
from import_exports import inspect_export

def main():
    incoming=ROOT/'sql_sample_extract'
    files=[inspect_export(p) for p in sorted(incoming.glob('*.csv'))]
    targets={'MG001356':'Vodafone','MG102229':'Siemens Energy','MG101624':'SoftBank'}
    pvd_file=incoming/'04_name_candidates_pvd_1-7_to_30_10.csv'
    clo_file=incoming/'04_name_candidates_clo.csv'
    with pvd_file.open(encoding='utf-8-sig',newline='') as f:pvd=list(csv.DictReader(f))
    with clo_file.open(encoding='utf-8-sig',newline='') as f:clo=list(csv.DictReader(f))
    per_group=[];identifiers=[]
    for mg,name in targets.items():
        pr=[r for r in pvd if r['joi_relationship_id']==mg]
        cr=[r for r in clo if r['rct_mastergroup_id']==mg]
        cins=sorted({r['obligor_cin'] for r in cr if r['obligor_cin']});gids=sorted({r['rct_gid'] for r in cr if r['rct_gid']})
        per_group.append(dict(mastergroup_id=mg,name=name,pvd_exact_rows=len(pr),pvd_dates=sorted({r['joi_date'] for r in pr}),clo_exact_rows=len(cr),cins=len(cins),gids=len(gids)))
        for kind,column,values in [('CIN','obligor_cin',cins),('GID','rct_gid',gids)]:
            for value in values:
                support=[r for r in cr if r[column]==value]
                identifiers.append((mg,name,kind,value,'clo',column,len(support),min(r['run_date'] for r in support),max(r['run_date'] for r in support),'observed_on_explicit_source_mastergroup; cross-source namespace pending'))
    with (HERE/'observed_group_identifiers.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(['mastergroup_id','name','identifier_type','identifier_value','source','source_column','supporting_rows','first_observed','last_observed','qualification']);writer.writerows(identifiers)
    summary={'input_files':files,'target_groups':per_group,'pvd_dates':dict(Counter(r['joi_date'] for r in pvd)),'pvd_other_relationship_rows':sum(r['joi_relationship_id'] not in targets for r in pvd),'clo_other_or_missing_group_rows':sum(r['rct_mastergroup_id'] not in targets for r in clo),'clo_distinct_row_hashes':len({hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in clo})}
    exact_clo=[r for r in clo if r['rct_mastergroup_id'] in targets]
    fields=['facility_drawn_amount','facility_limit_amount','ag_acc_bal_drawn_sub_lim_usd','account_balance_drawn_amount_usd','lbs_facility_drawn_amount_usd','lbs_facility_limit_amount_usd']
    summary['clo_amount_population']={field:sum(bool(r.get(field)) for r in exact_clo) for field in fields}
    (HERE/'review.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
    lines=['# Returned Starburst extract review','', 'Review date: 2 November 2026. Input files are preserved in `sql_sample_extract/`; this review uses their contents, not filename assumptions. No live database was queried.','','## What was returned','','| File | Identified content | Rows | Interpretation |','| --- | --- | ---: | --- |']
    for item in files:
        name=Path(item['filename']).name
        detail='Schema/metadata only' if item['kind']=='schema' else 'Query failed; not KYC data' if item['kind']=='error' else 'Header-only query result' if item['kind']=='data' and not item['rows'] else 'Date-profile header only' if item['kind']=='profile' else 'Returned source records'
        if name=='04_name_candidates_clo.csv':detail+='; same row multiset as 04_name_candidates.csv'
        lines.append(f"| {name} | {item['source'] or 'Unknown'} / {item['kind']} | {item['rows']} | {detail} |")
    lines += ['','## Exact target ID observations','','| Group | Mastergroup | PVD exact relationship-ID rows | CLO explicit mastergroup rows | Distinct observed CLO CINs | Distinct observed CLO GIDs |','| --- | --- | ---: | ---: | ---: | ---: |']
    for group in per_group:lines.append(f"| {group['name']} | {group['mastergroup_id']} | {group['pvd_exact_rows']} | {group['clo_exact_rows']} | {group['cins']} | {group['gids']} |")
    lines += ['','Counts are exported historical observations, not independent facilities, clients or signal events. Repeated dates/records must be handled at the source grain. The two CLO files each have 3,622 unique rows and identical content multisets in different orders; adding them would double the same population.','','## KYC error: confirmed query defect','','The supplied KYC file contains `Cannot cast array(varchar) to varchar`, not extracted KYC records. The new KYC DDL confirms `cdd_topco_legal_name array(varchar)`. The old generated name query cast that field directly to VARCHAR. The generator now uses `ARRAY_JOIN` for this known array field and keeps scalar handling for `legal_name` and `mg_parent_legal_name`. A local equivalent-expression test covers a name found only inside the array. Live Starburst execution is still required.','','The DDL also contains `mg_parent_grid`, `groupguci` and `groupguci_sub`; their meanings were not established. They are not automatically treated as the supplied mastergroup IDs. The next KYC candidate lookup instead uses the 10 CIN values observed under the three explicit CLO groups. Cross-source CIN meaning still needs validation against the returned rows.','','## PVD empty October result: date-window evidence','','The seed and October name exports contain headers with zero data rows; the date profile is also header-only. The widened file contains 1,312 rows on 31 July, 31 August and 30 September 2026, with no October observations in that export. This is consistent with the October-only window producing no matches. Actual submitted SQL/execution logs were not supplied, so this cannot establish that the full source lacks October data.','','The 850 exact target-ID rows are Vodafone 379, Siemens Energy 260 and SoftBank 211. The remaining 462 rows have other relationship IDs. Name searches can match supergroup names and return additional groups such as Siemens Gamesa, Fortress and SoftBank Ventures; these may be related, but they are not automatically merged into the three requested IDs.','','The original seed SQL already tested the three IDs against `joi_relationship_id` and `drr_supergroup_id` as well as names. The supplementary `04_name_candidates.sql` files were name-only. The corrected pack now provides an explicit ID-first query and a separate name-discovery query. The returned exact MG values are in `joi_relationship_id`; `drr_supergroup_id` contains different SG values or NO SPG, so supergroup IDs are kept separate.','','The PVD DDL identifies ORC data on HDP45, partitioned by `portfolio` and `etlmonth`. The new optional `$partitions` metadata query helps inspect available partitions before choosing dates; connector support/permissions must be checked. `joi_date` and `etlmonth` are different date concepts, and the returned data includes differing values.','','## CLO and next identifier lookups','','CLO provides 3,350 rows with the three exact mastergroup IDs. The other 272 have another or missing original mastergroup and remain name candidates. This includes Vodafone/Hutchison and SoftBank Ventures labels; no arbitrary reassignment was made. `source_system` is blank in all 3,622 rows, so source-key uniqueness still needs validation using mapping system, booking entity and facility tier.','','The exact-group rows expose 10 distinct CINs and 6 distinct GIDs, preserved as text. Some CIN values have alphabetic prefixes; no prefix stripping or numeric conversion was applied. `observed_group_identifiers.csv` records their provenance. These are candidate lookup keys for additional extraction, not automatic approval of legal-entity equivalence or historical membership.','','`next_queries/` contains observed-ID lookups for KYC and Facilities and expanded CLO/DRR queries. These use ID conditions and do not depend on client-name matching. Counterparty remains catalog-unconfirmed. Covenants remains without a verified relationship/facility route. No DRR, Facilities, Covenants or Counterparty result file was supplied, so their actual execution outcomes cannot be inferred.','','## Manual workflow to use now','','1. Copy the corrected SQL into Starburst and run it manually. Save each result to the drive available from Starburst. Export all rows with headers, preserving identifier text and CSV quoting.','2. Transfer the files into one incoming local folder. Filenames may retain Starburst/query names.','3. Run `cohort.py import-exports` locally. It detects source datasets by headers, skips schema/profile/error payloads, records failed queries and loads an identical whole export only once even if row ordering changed.','4. Run `cohort.py analyse` against the prepared folder. The current review correctly marks KYC `extraction_failed`, not no activity.','5. Use `candidate-sql` for the next source-observed identifier lookups, or `source-sql --approved ...` for reviewed mappings. Both only write SQL files for manual execution. No Python-to-Starburst connection is involved.','','## Current limitations','','- PVD exact IDs can be extracted immediately, but non-MG relationship IDs still need namespace/group verification before cross-source matching.','- Query/filter text and export row limits were not supplied. Saved results alone cannot establish full-group completeness.','- Name matches and supergroup relationships can broaden the scope; review them explicitly.','- No amount totals, utilisation trigger or covenant breach is validated by this identity/coverage review.','- Input checksums and details are retained in review.json and prepared_inputs/import_manifest.json. Raw inputs were not modified.']
    (HERE/'Findings.md').write_text('\n'.join(lines)+'\n')
    diagnostic=HERE/'clo_signal_diagnostics/results/bond_radar.sqlite'
    if diagnostic.exists():
        db=sqlite3.connect(diagnostic)
        status=db.execute('SELECT signal_id,assessment_status,reason,COUNT(*) FROM signal_evidence GROUP BY 1,2,3').fetchall()
        key_missing=db.execute("SELECT affected_count FROM quality_issues WHERE source='clo' AND check_name='missing_scoped_key'").fetchone()
        count=db.execute('SELECT COUNT(*) FROM observations').fetchone()[0];db.close()
        appendix=['','## CLO signal diagnostic on the exact three-group rows','',f'The local runner retained the 3,350 exact-group raw observations, excluded {key_missing[0] if key_missing else 0} rows with no usable facility key, and produced {count} scoped facility/date observations. This is a diagnostic consolidation, not a verified facility population.','','| Configured amount field | Populated exact-group raw rows |','| --- | ---: |']
        appendix += [f'| {field} | {number} |' for field,number in summary['clo_amount_population'].items()]
        appendix += ['','The latest-record signal checks remain unavailable because the configured `facility_drawn_amount` numerator is missing. SIG01 has three unavailable latest assessments; SIG06 utilisation has four. Alternative USD measures are present in some records, but their definitions, participation basis and compatible denominators must be verified before changing the calculation. No automatic fallback from USD drawn amounts to local-currency limits was applied. The raw history and identity data are still useful for the next extraction.']
        with (HERE/'Findings.md').open('a') as f:f.write('\n'.join(appendix)+'\n')

if __name__=='__main__':main()
