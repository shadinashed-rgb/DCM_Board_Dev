-- READ ONLY: run in your Starburst/Trino SQL client; no statement is submitted by this package.
-- Verify live schema, native date format and partition properties. Capture all selected columns.
-- No business materiality/product/utilisation filters. Counts are raw observations, not facilities.
-- SOURCE-OBSERVED CANDIDATE LOOKUP: CIN/GID values come from linked source records.
-- This is extraction discovery, not approval of a shared identifier namespace.
-- EXISTS returns each source row once even if several identifiers match.
WITH cohort(identifier_type, identifier_value, valid_from, valid_to) AS (
  VALUES
    ('MASTERGROUP_ID', 'MG001356', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('MASTERGROUP_ID', 'MG102229', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('MASTERGROUP_ID', 'MG101624', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '1034107555', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G002599455', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '1018544917', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G918302442', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '1095186264', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G611504514', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G390539832', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', 'DE54009015791', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G664906546', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052910221', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2021072908540', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052909382', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('GID', 'G094775446', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052910083', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020120111381', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020061913563', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR))
)
SELECT t.*
FROM "delta"."prod_credit_and_lending_mda"."drr_facility_limits" t
WHERE t."reporting_date" >= '20261001' AND t."reporting_date" <= '20261030'
  AND EXISTS (SELECT 1 FROM cohort c WHERE ((c.identifier_type='MASTERGROUP_ID' AND UPPER(REGEXP_REPLACE(TRIM(CAST(t."drr_mastergroup_id" AS VARCHAR)), '\s+', ' '))=c.identifier_value) OR (c.identifier_type='CIN' AND UPPER(REGEXP_REPLACE(TRIM(CAST(t."cin" AS VARCHAR)), '\s+', ' '))=c.identifier_value) OR (c.identifier_type='GID' AND UPPER(REGEXP_REPLACE(TRIM(CAST(t."gid" AS VARCHAR)), '\s+', ' '))=c.identifier_value)) AND (c.valid_from IS NULL OR t."reporting_date" >= c.valid_from) AND (c.valid_to IS NULL OR t."reporting_date" <= c.valid_to));
