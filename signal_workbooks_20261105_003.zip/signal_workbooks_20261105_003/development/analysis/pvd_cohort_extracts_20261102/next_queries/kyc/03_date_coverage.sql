-- READ ONLY: run in your Starburst/Trino SQL client; no statement is submitted by this package.
-- Verify live schema, native date format and partition properties. Capture all selected columns.
-- No business materiality/product/utilisation filters. Counts are raw observations, not facilities.
WITH cohort(identifier_type, identifier_value, valid_from, valid_to) AS (
  VALUES
    ('CIN', '1034107555', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '1018544917', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '1095186264', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', 'DE54009015791', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052910221', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2021072908540', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052909382', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020052910083', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020120111381', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR)),
    ('CIN', '2020061913563', CAST(NULL AS VARCHAR), CAST(NULL AS VARCHAR))
)
SELECT t."run_date" AS source_date, COUNT(*) AS raw_rows
FROM "delta"."prod_party_gda"."kyc" t
WHERE t."run_date" >= '20261001' AND t."run_date" <= '20261030'
  AND EXISTS (SELECT 1 FROM cohort c WHERE ((c.identifier_type='CIN' AND UPPER(REGEXP_REPLACE(TRIM(CAST(t."cin" AS VARCHAR)), '\s+', ' '))=c.identifier_value)) AND (c.valid_from IS NULL OR t."run_date" >= c.valid_from) AND (c.valid_to IS NULL OR t."run_date" <= c.valid_to))
GROUP BY t."run_date" ORDER BY t."run_date";
