# Source-observed identifier lookups

CIN/GID values were taken from uniquely linked input records. Use these read-only SQL queries to look for corresponding source records; no approval file was created or changed. Verify cross-source identifier meaning, country scope and dates before joining results. Existing source mastergroup conflicts remain quarantined by analyse.

Execute each SQL file manually in Starburst, export to your drive, transfer the files to a local folder, then run import-exports and analyse. Missing routes and the unconfirmed Counterparty catalog remain explicit.
