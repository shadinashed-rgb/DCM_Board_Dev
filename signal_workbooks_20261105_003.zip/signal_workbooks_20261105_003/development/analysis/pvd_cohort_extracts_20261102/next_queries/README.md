# Source-observed candidate SQL pack

These read-only lookups use IDs seen on linked source rows; they do not approve a shared client namespace. Run schema statements separately first, then copy 02_extract.sql into Starburst and execute/export manually. Name queries are supplementary only. Read 02_BLOCKED.txt for missing routes, and inspect observed_identifier_candidates.csv for provenance. No source or approval file is changed by generation.
