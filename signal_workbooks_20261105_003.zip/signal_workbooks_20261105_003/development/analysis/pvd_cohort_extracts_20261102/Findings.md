# Returned Starburst extract review

Review date: 2 November 2026. Input files are preserved in `sql_sample_extract/`; this review uses their contents, not filename assumptions. No live database was queried.

## What was returned

| File | Identified content | Rows | Interpretation |
| --- | --- | ---: | --- |
| 01_pvd_schema.csv | pvd / schema | 0 | Schema/metadata only |
| 02_pvd_discovery.csv | pvd / data | 0 | Header-only query result |
| 03_pvd_date_coverage.csv | pvd / profile | 0 | Date-profile header only |
| 04_name_candidates.csv | clo / data | 3622 | Returned source records |
| 04_name_candidates_clo.csv | clo / data | 3622 | Returned source records; same row multiset as 04_name_candidates.csv |
| 04_name_candidates_kyc.csv | kyc / error | 0 | Query failed; not KYC data |
| 04_name_candidates_pvd.csv | pvd / data | 0 | Header-only query result |
| 04_name_candidates_pvd_1-7_to_30_10.csv | pvd / data | 1312 | Returned source records |
| kyc_schema.csv | kyc / schema | 0 | Schema/metadata only |

## Exact target ID observations

| Group | Mastergroup | PVD exact relationship-ID rows | CLO explicit mastergroup rows | Distinct observed CLO CINs | Distinct observed CLO GIDs |
| --- | --- | ---: | ---: | ---: | ---: |
| Vodafone | MG001356 | 379 | 132 | 2 | 1 |
| Siemens Energy | MG102229 | 260 | 3080 | 7 | 2 |
| SoftBank | MG101624 | 211 | 138 | 1 | 3 |

Counts are exported historical observations, not independent facilities, clients or signal events. Repeated dates/records must be handled at the source grain. The two CLO files each have 3,622 unique rows and identical content multisets in different orders; adding them would double the same population.

## KYC error: confirmed query defect

The supplied KYC file contains `Cannot cast array(varchar) to varchar`, not extracted KYC records. The new KYC DDL confirms `cdd_topco_legal_name array(varchar)`. The old generated name query cast that field directly to VARCHAR. The generator now uses `ARRAY_JOIN` for this known array field and keeps scalar handling for `legal_name` and `mg_parent_legal_name`. A local equivalent-expression test covers a name found only inside the array. Live Starburst execution is still required.

The DDL also contains `mg_parent_grid`, `groupguci` and `groupguci_sub`; their meanings were not established. They are not automatically treated as the supplied mastergroup IDs. The next KYC candidate lookup instead uses the 10 CIN values observed under the three explicit CLO groups. Cross-source CIN meaning still needs validation against the returned rows.

## PVD empty October result: date-window evidence

The seed and October name exports contain headers with zero data rows; the date profile is also header-only. The widened file contains 1,312 rows on 31 July, 31 August and 30 September 2026, with no October observations in that export. This is consistent with the October-only window producing no matches. Actual submitted SQL/execution logs were not supplied, so this cannot establish that the full source lacks October data.

The 850 exact target-ID rows are Vodafone 379, Siemens Energy 260 and SoftBank 211. The remaining 462 rows have other relationship IDs. Name searches can match supergroup names and return additional groups such as Siemens Gamesa, Fortress and SoftBank Ventures; these may be related, but they are not automatically merged into the three requested IDs.

The original seed SQL already tested the three IDs against `joi_relationship_id` and `drr_supergroup_id` as well as names. The supplementary `04_name_candidates.sql` files were name-only. The corrected pack now provides an explicit ID-first query and a separate name-discovery query. The returned exact MG values are in `joi_relationship_id`; `drr_supergroup_id` contains different SG values or NO SPG, so supergroup IDs are kept separate.

The PVD DDL identifies ORC data on HDP45, partitioned by `portfolio` and `etlmonth`. The new optional `$partitions` metadata query helps inspect available partitions before choosing dates; connector support/permissions must be checked. `joi_date` and `etlmonth` are different date concepts, and the returned data includes differing values.

## CLO and next identifier lookups

CLO provides 3,350 rows with the three exact mastergroup IDs. The other 272 have another or missing original mastergroup and remain name candidates. This includes Vodafone/Hutchison and SoftBank Ventures labels; no arbitrary reassignment was made. `source_system` is blank in all 3,622 rows, so source-key uniqueness still needs validation using mapping system, booking entity and facility tier.

The exact-group rows expose 10 distinct CINs and 6 distinct GIDs, preserved as text. Some CIN values have alphabetic prefixes; no prefix stripping or numeric conversion was applied. `observed_group_identifiers.csv` records their provenance. These are candidate lookup keys for additional extraction, not automatic approval of legal-entity equivalence or historical membership.

`next_queries/` contains observed-ID lookups for KYC and Facilities and expanded CLO/DRR queries. These use ID conditions and do not depend on client-name matching. Counterparty remains catalog-unconfirmed. Covenants remains without a verified relationship/facility route. No DRR, Facilities, Covenants or Counterparty result file was supplied, so their actual execution outcomes cannot be inferred.

## Manual workflow to use now

1. Copy the corrected SQL into Starburst and run it manually. Save each result to the drive available from Starburst. Export all rows with headers, preserving identifier text and CSV quoting.
2. Transfer the files into one incoming local folder. Filenames may retain Starburst/query names.
3. Run `cohort.py import-exports` locally. It detects source datasets by headers, skips schema/profile/error payloads, records failed queries and loads an identical whole export only once even if row ordering changed.
4. Run `cohort.py analyse` against the prepared folder. The current review correctly marks KYC `extraction_failed`, not no activity.
5. Use `candidate-sql` for the next source-observed identifier lookups, or `source-sql --approved ...` for reviewed mappings. Both only write SQL files for manual execution. No Python-to-Starburst connection is involved.

## Current limitations

- PVD exact IDs can be extracted immediately, but non-MG relationship IDs still need namespace/group verification before cross-source matching.
- Query/filter text and export row limits were not supplied. Saved results alone cannot establish full-group completeness.
- Name matches and supergroup relationships can broaden the scope; review them explicitly.
- No amount totals, utilisation trigger or covenant breach is validated by this identity/coverage review.
- Input checksums and details are retained in review.json and prepared_inputs/import_manifest.json. Raw inputs were not modified.

## CLO signal diagnostic on the exact three-group rows

The local runner retained the 3,350 exact-group raw observations, excluded 92 rows with no usable facility key, and produced 88 scoped facility/date observations. This is a diagnostic consolidation, not a verified facility population.

| Configured amount field | Populated exact-group raw rows |
| --- | ---: |
| facility_drawn_amount | 0 |
| facility_limit_amount | 3258 |
| ag_acc_bal_drawn_sub_lim_usd | 3350 |
| account_balance_drawn_amount_usd | 46 |
| lbs_facility_drawn_amount_usd | 3172 |
| lbs_facility_limit_amount_usd | 3080 |

The latest-record signal checks remain unavailable because the configured `facility_drawn_amount` numerator is missing. SIG01 has three unavailable latest assessments; SIG06 utilisation has four. Alternative USD measures are present in some records, but their definitions, participation basis and compatible denominators must be verified before changing the calculation. No automatic fallback from USD drawn amounts to local-currency limits was applied. The raw history and identity data are still useful for the next extraction.
