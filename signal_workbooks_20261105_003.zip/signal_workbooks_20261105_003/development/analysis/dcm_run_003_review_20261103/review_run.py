"""Inspect DCM_Run_003 and run the existing local test package without changing it.

The mislabelled covenant file is inventoried but excluded from the canonical
Counterparty input because it repeats its payload with altered observation dates.
Run once into this fresh analysis folder; original exports are read-only.
"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT/'pvd_client_cohort_lab'))
from refresh import read_csv, write_csv, process
from import_exports import inspect_export
from cohort import norm, day

AS_OF = '2026-11-03'
INPUT = ROOT/'sql/DCM_Run_003'


def fingerprint(row, omit=()):
    return hashlib.sha256(json.dumps({k:v for k,v in row.items() if k not in omit},sort_keys=True).encode()).hexdigest()


def main():
    if (OUT/'local_test').exists() or (OUT/'review.json').exists():
        raise ValueError('Review outputs already exist; use a fresh analysis folder')
    records = []
    data = {}
    columns = {}
    for path in sorted(INPUT.glob('*.csv')):
        item = inspect_export(path)
        records.append(item)
        if item['kind'] == 'data':
            columns[path.name], data[path.name] = read_csv(path)
    inventory_fields=['filename','source','kind','rows','distinct_rows','bytes','sha256','date_counts','identifier_counts']
    write_csv(OUT/'file_inventory.csv',inventory_fields,[{k:json.dumps(r[k],sort_keys=True) if isinstance(r.get(k),dict) else r.get(k,'') for k in inventory_fields} for r in records])
    a,b=data['counterparty_current.csv'],data['covenants_extract.csv']
    exact_overlap=sum((Counter(map(fingerprint,a)) & Counter(map(fingerprint,b))).values())
    non_date_overlap=sum((Counter(fingerprint(r,('run_date',)) for r in a) & Counter(fingerprint(r,('run_date',)) for r in b)).values())
    assert exact_overlap==151 and non_date_overlap==167
    names=['clo_current_and_previous.csv','counterparty_current.csv','drr_current.csv','facilities_current.csv','kyc_current.csv','pvd_current.csv']
    for name in names:
        write_csv(OUT/'canonical_exports'/name,columns[name],data[name])
    process(OUT/'canonical_exports',OUT/'local_test',AS_OF,use_test_links=True)
    missing = []
    for name, rows in data.items():
        for col in columns[name]:
            missing.append(dict(file=name,column=col,rows=len(rows),missing=sum(norm(r[col]) is None for r in rows),distinct_nonmissing=len({norm(r[col]) for r in rows if norm(r[col]) is not None})))
    write_csv(OUT/'column_profile.csv',['file','column','rows','missing','distinct_nonmissing'],missing)

    fac=data['facilities_current.csv'];groups=defaultdict(list)
    for row in fac:
        if norm(row['facility_id']):
            groups[(row['source_system_name'],row['country_code'],row['facility_id'])].append(row)
    fac_keys=[]
    for key,rows in sorted(groups.items()):
        fac_keys.append(dict(source_system_name=key[0],country_code=key[1],facility_id=key[2],rows=len(rows),cins=json.dumps(sorted({r['cin'] for r in rows})),products=json.dumps(sorted({r['product_code'] for r in rows})),categories=json.dumps(sorted({r['limit_cat'] for r in rows})),creation_dates=json.dumps(sorted({r['facility_creation_date'] for r in rows})),current_flag_rows=sum(r['latest_record']=='CURRENT' for r in rows),conflicting_fields=json.dumps([c for c in columns['facilities_current.csv'] if len({r[c] for r in rows})>1])))
    write_csv(OUT/'facilities_key_review.csv',list(fac_keys[0]),fac_keys)

    db=sqlite3.connect(OUT/'local_test/signals/results/bond_radar.sqlite');db.row_factory=sqlite3.Row
    assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    evidence=[dict(r) for r in db.execute('SELECT * FROM cohort_signal_evidence')]
    high=[dict(r) for r in evidence if r['source']=='drr' and r['signal_id']=='SIG06' and r['value'] is not None and float(r['value'])>70]
    write_csv(OUT/'high_utilisation_candidates.csv',['cohort_mastergroup_id','record_key','observation_date','value','denominator','currency','assessment_status','reason','details_json'],high)
    stats=[dict(r) for r in db.execute('SELECT cohort_mastergroup_id,signal_id,source,assessment_status,COUNT(*) AS evidence_items,SUM(value IS NOT NULL) AS numeric_items FROM cohort_signal_evidence GROUP BY 1,2,3,4')]
    write_csv(OUT/'signal_evidence_counts.csv',['cohort_mastergroup_id','signal_id','source','assessment_status','evidence_items','numeric_items'],stats)
    for original in records:
        assert hashlib.sha256(Path(original['filename']).read_bytes()).hexdigest()==original['sha256']
    summary=dict(as_of=AS_OF,input_folder=str(INPUT),files=records,
        mislabelled_covenants=dict(detected_source='counterparty',rows=len(b),exact_overlap_with_counterparty=exact_overlap,payload_overlap_ignoring_run_date=non_date_overlap,action='Excluded from canonical test; no covenant data supplied. Confirm the actual query/export before reuse.'),
        facilities=dict(raw_rows=len(fac),missing_facility_id_rows=sum(not norm(r['facility_id']) for r in fac),nonempty_scoped_facility_keys=len(groups),repeated_nonempty_keys=sum(len(v)>1 for v in groups.values()),creation_conflict_keys=sum(len({r['facility_creation_date'] for r in v})>1 for v in groups.values()),product_variant_keys=sum(len({r['product_code'] for r in v})>1 for v in groups.values())),
        signal_counts=stats,high_utilisation_candidates=high,
        counterparty_enrichment=[dict(r) for r in db.execute('SELECT match_status,COUNT(*) AS raw_rows FROM clo_enriched GROUP BY match_status')],
        assessment_status=[dict(r) for r in db.execute('SELECT signal_id,assessment_status,COUNT(*) AS evidence_items FROM signal_evidence GROUP BY 1,2')],
        nonnull_triggers=db.execute('SELECT COUNT(*) FROM signal_evidence WHERE triggered IS NOT NULL').fetchone()[0],
        validation='Original seven input hashes unchanged; SQLite integrity ok; no production code modified; no live SQL executed.')
    (OUT/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['files','high_utilisation_candidates']},indent=2))
    db.close()


if __name__=='__main__':
    main()
