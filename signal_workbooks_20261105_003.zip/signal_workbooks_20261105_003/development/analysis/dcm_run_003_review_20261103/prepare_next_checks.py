"""Write bounded read-only diagnostic SQL, without changing the extraction package."""
from pathlib import Path
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT/'pvd_client_cohort_lab'))
from refresh import read_csv
from cohort import literal, norm

GROUPS={'MG001356','MG102229','MG101624'}
cins=set()
for filename,group_col,cin_col in [
    ('sql/DCM_Run_003/drr_current.csv','drr_mastergroup_id','cin'),
    ('sql/DCM_Run_003/clo_current_and_previous.csv','rct_mastergroup_id','obligor_cin'),
    ('sql/DCM_Run_003/counterparty_current.csv','mastergroup_esr_identifier','customer_relationship_cin_identifier'),
]:
    for r in read_csv(ROOT/filename)[1]:
        if r[group_col] in GROUPS and norm(r[cin_col]):cins.add(norm(r[cin_col]))
old=read_csv(ROOT/'sql/sql_samples/sample_dcm/facilities_cin_lookup.csv')[1]
current=read_csv(ROOT/'sql/DCM_Run_003/facilities_current.csv')[1]
for r in old+current:
    if norm(r['cin']):cins.add(norm(r['cin']))
rels=sorted({norm(r['relationship_id']) for r in old+current if norm(r['relationship_id'])})
fids=sorted({norm(r['facility_id']) for r in old+current if norm(r['facility_id'])})
folder=OUT/'next_checks';folder.mkdir(exist_ok=True)
sql='''-- READ ONLY. Copy/run in Starburst. Save as facilities_partition_dates.csv.
-- Observed candidate CINs; no name search or universal-namespace approval.
-- Profile BEFORE applying any global latest-date or effective-version filter.
SELECT source_system_name, country_code, cin, run_date,
       COUNT(*) AS raw_rows,
       COUNT(DISTINCT NULLIF(TRIM(facility_id), '')) AS nonblank_facility_id_strings
FROM delta.prod_credit_and_lending_gda.facilities_limits
WHERE run_date BETWEEN '20261001' AND '20261103'
  AND UPPER(TRIM(CAST(cin AS VARCHAR))) IN ('''+', '.join(literal(v) for v in sorted(cins))+''')
GROUP BY source_system_name, country_code, cin, run_date
ORDER BY country_code, cin, run_date DESC;
'''
(folder/'01_facilities_partition_dates.sql').write_text(sql)
(folder/'02_covenants_schema.sql').write_text('''-- READ ONLY. Run these statements separately; export schema outputs separately.
SHOW COLUMNS FROM delta.prod_credit_and_lending_gda.covenants;

SHOW CREATE TABLE delta.prod_credit_and_lending_gda.covenants;
''')
sql='''-- READ ONLY. First verify columns with 02_covenants_schema.sql.
-- Save as covenant_candidate_counts.csv. These are unverified ID-discovery routes,
-- not approved cross-source facility or relationship joins.
SELECT run_date, covenant_type, COUNT(*) AS raw_rows,
       SUM(CASE WHEN NULLIF(TRIM(CAST(active_testing_actual_value AS VARCHAR)), '') IS NOT NULL THEN 1 ELSE 0 END) AS actual_value_rows,
       SUM(CASE WHEN NULLIF(TRIM(CAST(active_testing_final_value AS VARCHAR)), '') IS NOT NULL THEN 1 ELSE 0 END) AS final_value_rows,
       SUM(CASE WHEN NULLIF(TRIM(CAST(active_testing_testing_threshold_value AS VARCHAR)), '') IS NOT NULL THEN 1 ELSE 0 END) AS threshold_rows
FROM delta.prod_credit_and_lending_gda.covenants
WHERE run_date BETWEEN '20261001' AND '20261103'
  AND (UPPER(TRIM(CAST(relationship_id AS VARCHAR))) IN ('''+', '.join(literal(v) for v in rels)+''')
       OR UPPER(TRIM(CAST(facility_id AS VARCHAR))) IN ('''+', '.join(literal(v) for v in fids)+'''))
GROUP BY run_date, covenant_type
ORDER BY run_date DESC, covenant_type;
'''
(folder/'03_covenant_candidate_counts.sql').write_text(sql)
(folder/'04_pvd_client_vintages.sql').write_text('''-- READ ONLY. Save as pvd_client_vintages.csv. Retain business and ETL dates.
SELECT joi_relationship_id, portfolio, etlmonth, etlmonth_drr,
       MAX(joi_date) AS latest_business_date, COUNT(*) AS raw_rows
FROM hive.pvd_prod_wave.pvd_omnia_drr
WHERE joi_date BETWEEN '2026-07-01' AND '2026-11-03'
  AND joi_relationship_id IN ('MG001356','MG102229','MG101624')
GROUP BY joi_relationship_id, portfolio, etlmonth, etlmonth_drr
ORDER BY joi_relationship_id, latest_business_date DESC, etlmonth DESC;
''')
print('Prepared four read-only diagnostics in',folder)
