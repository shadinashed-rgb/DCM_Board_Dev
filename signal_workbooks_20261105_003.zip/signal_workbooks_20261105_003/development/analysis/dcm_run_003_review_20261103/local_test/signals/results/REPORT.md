# Local Bond Radar test results

Assessment date: 2026-11-03

Development/test outputs. Business definitions and mappings remain subject to the recorded qualifications.

## Run outputs

- clo_enriched: 265
- observations: 508
- signal_evidence: 604
- signal_assessments: 2502

## Quality checks

| Source | Check | Level | Count | Interpretation |
| --- | --- | --- | --- | --- |
| clo | input_loaded | INFO | 274 | 1 file(s); 401 columns; raw values preserved as text |
| counterparty | input_loaded | INFO | 167 | 1 file(s); 100 columns; raw values preserved as text |
| facilities | input_loaded | INFO | 105 | 1 file(s); 182 columns; raw values preserved as text |
| kyc | input_missing | WARN | 1 | No CSV supplied. Dependent signal assessments remain unavailable. |
| covenants | input_missing | WARN | 1 | No CSV supplied. Dependent signal assessments remain unavailable. |
| drr | input_loaded | INFO | 642 | 1 file(s); 152 columns; raw values preserved as text |
| pvd | input_loaded | INFO | 143 | 1 file(s); 90 columns; raw values preserved as text |
| pvd | source_latest_observation_stale | WARN | 143 | Latest observed date 2026-09-30; lag 34 days. This says nothing about unexported source records. |
| counterparty | prior_settings_unverified | WARN | 1 | Lifecycle, lookback and sentinel settings are previous configuration to validate, not approved Bond Radar defaults. |
| identity | cin_namespace_unverified | WARN | 1 | CIN joins are provisional. Verify country/source scope or supply explicit source-scoped identity links. |
| clo | missing_scoped_key | WARN | 9 | Raw records retained; excluded from derived evidence. Review source/date/key contract. |
| clo | incomplete_source_scope | WARN | 265 | Candidate facility keys retain null source-scope components explicitly; key uniqueness remains unverified. |
| facilities | missing_scoped_key | WARN | 19 | Raw records retained; excluded from derived evidence. Review source/date/key contract. |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030203201151107120201"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030203201151108080205"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030203201151108080206"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030203201151108080207"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030203201151108080208"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030350637340405170101"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030350637340405170103"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030350637340801140104"] date 2026-11-02: conflicting fields product_code,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","AE","AE030350637340801140105"] date 2026-11-02: conflicting fields ccf_approved_pct,ccf_policy_approved_pct,ccf_recommended_value,credit_proposal_serial_no,date_of_expiry,ddf_approved_pct,ddf_policy_approved_pct,ddf_recommended_value,facility_creation_date,facility_expiry_dt,final_lgd_pct,lgd_policy_approved,lgd_recommended_value,previous_limit,proposed_lgd_perc,proposed_limit,record_start_dt,source_system_unique_id,total_weighted_approved_limit_amount; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","GB","00010185449171504230105"] date 2026-11-02: conflicting fields loan_maturity_dt,product_code,product_type,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","GB","00010185449171504230108"] date 2026-11-02: conflicting fields loan_maturity_dt,product_code,product_type,source_system_unique_id; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","GB","00010185449171606080101"] date 2026-11-02: conflicting fields ccf_approved_pct,ccf_policy_approved_pct,credit_proposal_serial_no,date_of_expiry,ddf_approved_pct,ddf_policy_approved_pct,facility_cancelled_ind,facility_creation_date,facility_expiry_dt,facility_grade_code,final_lgd_from_engine,final_lgd_pct,lgd_policy_approved,lgd_recommended_value,limit_cat,manual_lgd,manually_inputed_balance_ind,previous_limit,product_code,product_settlement_flag,product_settlement_type,proposed_downturn_lgd_perc,proposed_lgd_perc,proposed_limit,record_start_dt,source_system_unique_id,total_weighted_approved_limit_amount; metrics withheld |
| facilities | conflicting_observation | WARN | 1 | Key ["CFC","GB","00010185449172401110102"] date 2026-11-02: conflicting fields loan_maturity_dt,product_code,product_type,source_system_unique_id; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","ASIAINDIAVODAFONECAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","EUROPEFRANCEVODAFONECAT-A"] date 2026-09-30: conflicting fields drr_country_inc,drr_crr,drr_pd,drr_utils,joi_sector_b_l0,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","EUROPEUNITED KINGDOMVODAFONECAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","EUROPEUNITED KINGDOMVODAFONECAT-B"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_crr,drr_net_mtm,drr_pd,drr_product,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","EUROPEUNITED KINGDOMVODAFONECAT-S"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_country_inc,drr_crr,drr_pd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","MIDDLE EASTEGYPTVODAFONECAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","MIDDLE EASTEGYPTVODAFONECAT-B"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_crr,drr_pd,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","MIDDLE EASTTURKIYEVODAFONECAT-A"] date 2026-09-30: conflicting fields drr_carm_limit,drr_product,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","MIDDLE EASTTURKIYEVODAFONECAT-B"] date 2026-09-30: conflicting fields drr_carm_limit,drr_msg_grm_country; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","MIDDLE EASTTURKIYEVODAFONECAT-S"] date 2026-09-30: conflicting fields drr_msg_grm_country; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG001356","XNA"] date 2026-09-30: conflicting fields joi_b_country,joi_b_region,joi_facility_category,omn_cr_rwa_mtd,omn_cr_rwa_ytd,omn_direct_income,omn_ead_mtd,omn_ead_ytd,omn_el,omn_gross_ep,omn_income_net_lp,omn_net_ep,omn_op_rwa_mtd,omn_op_rwa_ytd,omn_pbt,omn_total_el_prov,omn_total_opex,omn_total_rwa_mtd,omn_total_rwa_ytd,omn_wa_lgd,omn_wa_lgd_calc,omn_wa_maturity,omn_wa_maturity_calc,omn_wa_pd,omn_wa_pd_calc; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG101624","ASIAHONG KONGSOFTBANKCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_country_inc,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG101624","ASIAJAPANSOFTBANKCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_crr,drr_pd,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG101624","EUROPEUNITED KINGDOMSOFTBANKCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_country_inc,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG101624","XNA"] date 2026-09-30: conflicting fields joi_b_country,joi_b_region,joi_facility_category,omn_cr_rwa_mtd,omn_cr_rwa_ytd,omn_direct_income,omn_ead_mtd,omn_ead_ytd,omn_el,omn_gross_ep,omn_income_net_lp,omn_net_ep,omn_op_rwa_mtd,omn_op_rwa_ytd,omn_pbt,omn_total_el_prov,omn_total_opex,omn_total_rwa_mtd,omn_total_rwa_ytd,omn_wa_lgd,omn_wa_lgd_calc,omn_wa_maturity,omn_wa_maturity_calc,omn_wa_pd,omn_wa_pd_calc; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","ASIACHINASIEMENS ENERGYCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","ASIACHINASIEMENS ENERGYCAT-B"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_crr,drr_net_mtm,drr_non_net_mtm,drr_pd,drr_utils,exposure_usd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","ASIACHINASIEMENS ENERGYCAT-S"] date 2026-09-30: conflicting fields drr_carm_limit,drr_crr,drr_pd,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","EUROPEFRANCESIEMENS ENERGYCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_product,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","EUROPEGERMANYSIEMENS ENERGYCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_commitment,drr_country_inc,drr_crr,drr_pd,drr_product,drr_utils,exposure_usd,joi_sector_b_l0,joi_sector_b_l1,joi_sector_b_l2; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","MIDDLE EASTQATARSIEMENS ENERGYCAT-A"] date 2026-09-30: conflicting fields drr_act_limit,drr_carm_limit,drr_product,drr_utils,exposure_usd; metrics withheld |
| pvd | conflicting_observation | WARN | 1 | Key ["MG102229","XNA"] date 2026-09-30: conflicting fields joi_b_country,joi_b_region,joi_facility_category,omn_direct_income,omn_gross_ep,omn_income_net_lp,omn_net_ep,omn_op_rwa_mtd,omn_op_rwa_ytd,omn_pbt,omn_total_opex,omn_total_rwa_mtd,omn_total_rwa_ytd; metrics withheld |
| counterparty | enrichment_original_preserved | INFO | 265 | Counts are raw borrower-association observations, not distinct clients or recovered facilities. |
| clo | identity_requires_validation | WARN | 7 | Observations retain source-scoped, provisional or ambiguous client identities; inspect mapping_status before cross-source interpretation. |
| facilities | identity_requires_validation | WARN | 63 | Observations retain source-scoped, provisional or ambiguous client identities; inspect mapping_status before cross-source interpretation. |

## How to interpret the results

- `signal_evidence`: metrics and context, with source-row references and qualifications. `triggered` stays blank until applicable definitions/settings are verified.
- `client_signal_summary`: all six signals per observed client identity. No-evidence means unavailable. An assessed no-trigger result only describes supplied records.
- `clo_enriched`: one record per accepted raw CLO association, including both identifier routes and mapping dates.
- `group_signal_summary`: counts of evidence only; no monetary totals across sources. Unverified and ambiguous mappings need review.
- `stale`: observation lag exceeds the configurable development freshness setting; inspect event dates separately.
- `raw_*`: original CSV values as text. `__id` connects derived lineage to source file and CSV line.

## Limits

No live SQL was executed by the local process. Daily coverage, approved production definitions, financial units, facility equivalence and full client mappings are not established by a successful run.
