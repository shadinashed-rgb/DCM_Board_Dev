# Current source and signal test results

Raw imports are in imported/. current_inputs/ contains selected snapshots and
effective Facilities versions. current_selection.csv explains row reductions.
cohort/REPORT.md describes group coverage; signals/results/exports/ contains
candidate signal evidence if any rows were uniquely linked. test_identifiers.csv
records explicit opt-in test associations and any supplied approvals. Never use
development test associations as proof of production identity or legal membership.

SIG01 alone imputes missing drawn amounts to zero and records each imputation;
missing comparison observations and invalid numbers remain unavailable. SIG06
does not inherit zero imputation. SIG07 retains limit_cat as candidate context;
no CAT code automatically proves advisory engagement. Definitions and product
eligibility remain unverified, so trigger booleans remain null by default.

No sums across currencies, dates, overlapping sources, or parent/child limits are
computed. DRR UIDs are candidate exposure keys; shared borrower associations are
consolidated only when non-association attributes agree, otherwise metrics are
withheld. Scientific facility IDs cannot support cross-source facility joins.
