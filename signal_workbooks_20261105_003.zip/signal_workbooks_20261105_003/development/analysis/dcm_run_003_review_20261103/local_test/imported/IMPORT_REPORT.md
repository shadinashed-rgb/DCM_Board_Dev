# Manual Starburst export import

Copy SQL into Starburst, execute/export to your drive, transfer the export folder, then run this importer locally. No database connection is made.

| File | Source | Kind | Rows | Import outcome |
| --- | --- | --- | ---: | --- |
| clo_current_and_previous.csv | clo | data | 276 | imported |
| counterparty_current.csv | counterparty | data | 167 | imported |
| drr_current.csv | drr | data | 660 | imported |
| facilities_current.csv | facilities | data | 105 | imported |
| kyc_current.csv | kyc | data | 0 | imported |
| pvd_current.csv | pvd | data | 143 | imported |

The error files remain recorded in import_manifest.json; coverage will distinguish extraction_failed from missing_file. Header-only exports do not establish absence of source data. Partial overlaps between different exports require review.
