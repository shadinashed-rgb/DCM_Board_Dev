# PVD-first cohort extraction review

Assessment date: 2026-11-03

Reviewed discovery cohort; historical membership is not inferred

## Coverage by group and source

| Group | Source | State | Matched rows | Distinct matched rows | Candidates | Conflicts | Latest matched date |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| VODAFONE (MG001356) | clo | matched | 12 | 12 | 0 | 0 | 2026-11-02 |
| VODAFONE (MG001356) | counterparty | matched | 83 | 83 | 0 | 0 | 2026-11-03 |
| VODAFONE (MG001356) | covenants | missing_file | 0 | 0 | 0 | 0 | Unavailable |
| VODAFONE (MG001356) | drr | matched | 100 | 100 | 0 | 0 | 2026-11-02 |
| VODAFONE (MG001356) | facilities | matched | 67 | 67 | 0 | 0 | 2026-11-02 |
| VODAFONE (MG001356) | kyc | empty_export | 0 | 0 | 0 | 0 | Unavailable |
| VODAFONE (MG001356) | pvd | matched_stale | 65 | 65 | 0 | 0 | 2026-09-30 |
| SOFTBANK (MG101624) | clo | matched | 10 | 10 | 2 | 0 | 2026-11-02 |
| SOFTBANK (MG101624) | counterparty | matched | 39 | 39 | 0 | 0 | 2026-11-03 |
| SOFTBANK (MG101624) | covenants | missing_file | 0 | 0 | 0 | 0 | Unavailable |
| SOFTBANK (MG101624) | drr | matched | 31 | 31 | 0 | 0 | 2026-11-02 |
| SOFTBANK (MG101624) | facilities | matched | 2 | 2 | 0 | 0 | 2026-11-02 |
| SOFTBANK (MG101624) | kyc | empty_export | 0 | 0 | 0 | 0 | Unavailable |
| SOFTBANK (MG101624) | pvd | matched_stale | 34 | 34 | 0 | 0 | 2026-09-30 |
| Siemens Energy (MG102229) | clo | matched | 252 | 252 | 0 | 0 | 2026-11-02 |
| Siemens Energy (MG102229) | counterparty | matched | 41 | 41 | 0 | 0 | 2026-11-03 |
| Siemens Energy (MG102229) | covenants | missing_file | 0 | 0 | 0 | 0 | Unavailable |
| Siemens Energy (MG102229) | drr | matched | 511 | 511 | 0 | 0 | 2026-11-02 |
| Siemens Energy (MG102229) | facilities | matched | 36 | 36 | 0 | 0 | 2026-11-02 |
| Siemens Energy (MG102229) | kyc | empty_export | 0 | 0 | 0 | 0 | Unavailable |
| Siemens Energy (MG102229) | pvd | matched_stale | 44 | 44 | 0 | 0 | 2026-09-30 |

## Interpretation

- PVD exact ID/name discovery remains candidate evidence until the identifier role/group association is reviewed.
- `identifier_review.csv` contains distinct candidate IDs, original source columns, observation ranges and pending decisions. No CIN is inferred from the shape of `joi_key` or `joi_relationship_id`.
- A source row matching conflicting approved group links or disagreeing with its explicit mastergroup is quarantined. Group expansion is not transitive.
- `name_variations.csv` is a discovery/review inventory. Names do not become authoritative join keys.
- Missing, empty, unmatched, candidate-only and conflicting results have separate coverage states. Counts cannot establish source-wide completeness.
- Coverage counts preserve raw observations and separately show distinct row hashes. Financial balances are not summed here.

## Next steps

1. Review identifiers and save reviewed decisions in an approval CSV. Approve only with evidence and the correct namespace/source scope.
2. Generate source SQL from approved links and target mastergroup anchors. Export the resulting source data and rerun analysis.
3. Repeat as DRR/Counterparty/CLO reveal additional CIN/GID/relationship mappings. A new identifier is proposed for review; it is not silently approved.
4. Run the bundled signal tests on uniquely linked rows. Business triggers remain unverified by default.

## Qualifications

- PVD relationship/supergroup/key columns retain their own namespaces. No CIN/GID interpretation was inferred.
- As-of checks use exported observation/processing dates, not historical database version recovery.
- Counterparty table location, PVD grain/units and cross-source facility equivalence still require verification.
