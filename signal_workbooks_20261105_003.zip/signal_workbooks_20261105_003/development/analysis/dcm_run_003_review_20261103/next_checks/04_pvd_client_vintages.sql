-- READ ONLY. Save as pvd_client_vintages.csv. Retain business and ETL dates.
SELECT joi_relationship_id, portfolio, etlmonth, etlmonth_drr,
       MAX(joi_date) AS latest_business_date, COUNT(*) AS raw_rows
FROM hive.pvd_prod_wave.pvd_omnia_drr
WHERE joi_date BETWEEN '2026-07-01' AND '2026-11-03'
  AND joi_relationship_id IN ('MG001356','MG102229','MG101624')
GROUP BY joi_relationship_id, portfolio, etlmonth, etlmonth_drr
ORDER BY joi_relationship_id, latest_business_date DESC, etlmonth DESC;
