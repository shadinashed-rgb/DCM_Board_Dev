# Targeted checks after DCM_Run_003

These files supplement the analysis only. Existing extraction code and archives
are unchanged. Run SQL manually in Starburst; keep diagnostic outputs separate
from data CSVs consumed by the Python pipeline.

1. `01_facilities_partition_dates.sql` → `facilities_partition_dates.csv`.
   Check dates by source/country/CIN, including the earlier Siemens DE identifiers,
   before selecting a global maximum or re-exporting raw Facilities rows.
2. `02_covenants_schema.sql`: run each statement separately and save schema results
   outside the data folder. Expected covenant ID/type/value/threshold columns must
   be present; a Counterparty schema is not a covenant extract.
3. `03_covenant_candidate_counts.sql` → `covenant_candidate_counts.csv`, after the
   schema check. Observed facility/relationship IDs are candidate discovery only;
   no cross-source namespace or client assignment is approved by this query.
4. `04_pvd_client_vintages.sql` → `pvd_client_vintages.csv`. Check business dates
   alongside portfolio and ETL vintages for the exact three client anchors.

The dates are bounded for the 3 November 2026 review. Adjust them deliberately for
a later assessment. Latest available dates, empty selections and profile counts
do not establish source-wide completeness or absence of client activity.
