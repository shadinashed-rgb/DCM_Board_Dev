# DCM_Run_003: source review and signal readiness

Assessment date: **3 November 2026**. Inputs: seven CSVs in `sql/DCM_Run_003`.
The analysis ran the existing local development package on isolated copies of
six canonical exports, with explicit source/date-bounded test associations.
No production code, source export, existing document or release archive changed.
All seven original input hashes were checked again after processing.

## Main conclusion

**SIG06 DRR utilisation is the strongest candidate for the next business test.**
The three clients now have 405 candidate exposure observations after borrower
association consolidation; 57 have usable ratio inputs, and five exceed the
proposed 70% threshold. These are arithmetic candidates, not validated alerts.

SIG01 produces three zero-change RCF assessments for Vodafone/Siemens under the
user's missing-drawn-as-zero policy. SoftBank has no identifiable RCF observation
in this CLO export. SIG02 has eight recent creation-date candidates, but product
meaning and mixed product/facility grain need validation. SIG07 retains category
context, not evidence of an advisory engagement. SIG03, KYC and explicit financial
covenant evidence remain unavailable.

## Source coverage and dates

| Returned file | Actual content / rows | Observed dates / interpretation |
| --- | --- | --- |
| clo_current_and_previous.csv | CLO: 276 rows, 401 columns | 30/31 October and 2 November, with different selected group snapshots. Drawn field blank in all 276 rows. |
| counterparty_current.csv | Counterparty: 167 rows, 100 columns | 30/31 October and 2/3 November. Lifecycle/source variants and mapping snapshots are retained. |
| drr_current.csv | DRR: 660 rows, 152 columns | 659 rows dated 2 November, one non-target row dated 2 August. Native target groups account for 642 rows. |
| facilities_current.csv | Facilities: 105 rows, 182 columns | 2 November; cfc, GB and AE only. All end dates are 99991231. |
| kyc_current.csv | KYC schema with zero data rows | Empty lookup; absence of client activity is not established. |
| pvd_current.csv | PVD: 143 rows, 90 columns | All business dates 30 September, 34 days old. Stale under the configurable 30-day development check. |
| covenants_extract.csv | **Counterparty-shaped data: 167 rows, 100 columns** | No covenant IDs, types, actual values or thresholds. Excluded from the canonical test. |

The alleged covenant file overlaps the Counterparty file on **151 complete rows**.
Ignoring run_date, all **167 payloads match**; the other 16 have changed date
values. Its contents do not establish which query was executed. Confirm the
original SQL/export association before reusing it. Feeding both files to the
importer would add Counterparty observations, not covenant evidence.

### Canonical client matching

| Client | CLO matched raw rows | Counterparty matched raw rows | DRR matched raw rows | Facilities matched raw rows | PVD matched raw rows |
| --- | ---: | ---: | ---: | ---: | ---: |
| Vodafone MG001356 | 12 | 83 | 100 | 67 | 65 |
| Siemens Energy MG102229 | 252 | 41 | 511 | 36 | 44 |
| SoftBank MG101624 | 10 | 39 | 31 | 2 | 34 |

These are observations, not counts of distinct economic facilities. Facilities
and PVD matches use explicit development assumptions recorded in
`local_test/test_identifiers.csv`; they are not production identity approvals.
Two additional CLO rows have missing original groups and remain name candidates.
DRR contains 14 NO MSG rows and four rows in other native groups; these are not
silently allocated to the targets. No approved group-link conflict occurred.

## SIG01: RCF drawing changes

- There are 12 Vodafone REV rows and 252 Siemens REV rows over two snapshots.
  Consolidation yields two current Vodafone RCF keys and one Siemens RCF key.
- For each of those three current RCF assessments, current drawn=0, previous
  drawn=0 and change=0 under the requested imputation policy. Both input balances
  are flagged as imputed, and the actual comparison date/gap is retained.
- All 276 raw drawn values are blank. This is not proof of actual zero borrowing
  or absence of drawing increases. Threshold, currency/participation and period
  definitions still need agreement before business alerts are enabled.
- SoftBank has nine rows with blank product and no usable scoped facility key,
  plus one identifiable TERM row. The export does not support a SoftBank RCF
  change calculation. A missing observation/key is not a zero-valued RCF event.

## SIG02: new facilities and record grain

Of 105 raw Facilities rows, **19 have blank facility_id**. The other 86 rows
represent **63 non-blank source/country/facility keys**. Thirteen keys repeat,
and **all 13 have different product_code values**. Eleven of those keys share one
creation date across products; **two keys have conflicting creation dates**.
Thus repeated records are
not uniformly old versions or duplicate facilities: some are product variants.

The existing conservative engine withholds SIG02 events on all 13 conflicting
keys; 50 keys retain usable creation-date candidates. Of those, eight fall within
the 90-day development lookback (5 August–3 November):

- Seven Vodafone keys have creation date **17 September 2026**, product codes
  including RDS, STR, USC, CCP, GIS12 and ECC. They are candidates for review,
  not seven confirmed new RCF/term-loan/bridge financing events. Validate against
  known business events; facility-ID text must not be used to infer a facility's age.
- One Siemens AE key has creation date **6 October 2026**, product FGL and
  proposed limit **AED 40 million**. Product/creation-event definitions remain open.
- No recent SoftBank creation-date candidate is established by this export.

**Next data model:** a facility parent keyed by source/country/facility ID plus
separate product rows and version/event history. Preserve category sets and
ambiguous dates; do not sum or drop product rows simply because IDs repeat.
Missing facility IDs need recovery from a verified facility reference, not
invention from CIN/customer ID.

### Latest-date coverage risk

The query currently chooses one latest date across the Facilities cohort export.
This round includes GB/AE on 2 November but **no DE rows**, whereas the previous
Siemens sample contained 25 scoped DE facility IDs on 30 October. That does not
establish those facilities disappeared. A global maximum can discard older,
still-relevant country/source partitions. The missing DE population needs a
date-by-country/CIN probe before changing selection to a verified publishing
grain (for example source/country), with per-partition freshness shown explicitly.
This is a hypothesis to test, not proof of the live source's partition behaviour.

## SIG06: utilisation

| Client | Native target raw rows | Candidate exposure observations | Usable ratio inputs | Unavailable | Above 70% |
| --- | ---: | ---: | ---: | ---: | ---: |
| Vodafone | 100 | 93 | 20 | 73 | 1 |
| Siemens Energy | 511 | 281 | 32 | 249 | 2 |
| SoftBank | 31 | 31 | 5 | 26 | 2 |
| Total | 642 | 405 | 57 | 348 | 5 |

DRR UID is a candidate internal exposure key. Repeated agreeing borrower
associations are consolidated with lineage; this is not validation of universal
facility identity or source-wide completeness. The 57 ratios require a positive
approved limit, non-negative utilisation and matching populated currencies.
The remaining observations have missing currencies, zero/non-positive limits,
negative utilisation or combinations of those issues. Defaults do not impute
SIG06 values from the SIG01 zero policy.

| Client | DRR UID | Facility type | Approved limit | Utilisation | Ratio |
| --- | --- | --- | ---: | ---: | ---: |
| Vodafone | 264658583 | FGTE | EGP 927,660 | EGP 874,590 | 94.28% |
| Siemens Energy | 543509314 | FGTE | QAR 1,371,648 | QAR 1,053,379 | 76.80% |
| Siemens Energy | 815898281 | FCTA | EUR 605,104,472 | EUR 449,087,805 | 74.22% |
| SoftBank | 864252253 | FLNS | USD 120,000,000 | USD 120,000,000 | 100.00% |
| SoftBank | 1234654449 | FLNS | USD 1,000,000,000 | USD 1,000,000,000 | 100.00% |

All five are dated **2 November 2026** and none is coded RVCF. Confirm the eligible
product set as well as limit/utilisation definitions with the business. The two
RVCF-coded Vodafone observations have zero utilisation, not a high-utilisation
candidate. No candidate above establishes covenant breach or bond issuance intent.

This re-export contains **no scientific-notation strings in facility_id or
drr_uid**, improving on the earlier file. Original identifier correctness still
requires source provenance; absence of scientific notation alone is not proof.
CLO utilisation remains unavailable because its configured drawn measure is
missing. PVD ratios remain unavailable because currency/grain/measure definitions
are unverified, with conflicting native-key observations as well as stale dates.

## SIG07: advisory classification

The 105 raw Facilities rows contain **85 CAT-A, 11 CAT-B, eight CAT-S and one blank**.
`advised_ind` is 1 on 97 rows and 0 on eight. Facility grade codes are 0, 2 and 3,
while grade descriptions and limit_category_type are blank. These values support
category investigation but do not establish an advisory engagement.

One scoped facility has **both CAT-A and CAT-S on different product/version
rows**. The existing scalar context can retain only one value after consolidation;
the raw category set in `facilities_key_review.csv` must be used for investigation.
The next model should keep categories per product and derive any advisory flag
only from an agreed mapping or a known advisory example. PVD rating/category
context is also retained, with its 30 September business date clearly labelled.

## Counterparty enrichment

The canonical Counterparty export now supplies 167 matching-schema rows.
There are Active/ACTIVE, Inactive, CLOSED, Sleep and blank relationship statuses;
source-system and lifecycle definitions remain to be validated.

For **265 usable CLO borrower-association rows**, valid original mastergroups
were preserved. GID routes return candidates for 259 of them; no CIN-route
candidate was found in this export. No missing CLO mastergroup was recovered.
The two unmatched-group TERM rows share CIN 1034107555, have no GID, and no
matching Counterparty CIN. A separate valid CLO row associates that CIN with
SoftBank, supporting the bounded Facilities test association, not automatically
rewriting the missing original CLO values.

Counterparty also yields additional group-linked CIN/GID candidates for future
coverage expansion. Review source/country namespace, lifecycle and observation
dates before using the full roster; do not turn all historical IDs into current
membership automatically.

## Other signals

- **SIG03:** no enquiry/pricing source supplied.
- **SIG04:** KYC remains a header-only export. Use a known client case and its
  source identifier/date to validate the lookup path; broader name searches alone
  will not establish completeness.
- **SIG06 financial covenants:** no covenant dataset was returned; the file with
  that name is Counterparty data. Confirm and rerun the actual covenant query.
- **SIG05:** excluded from scope.

## Recommended next stage

1. **Validate a small set of known business examples:** the five high-utilisation
   rows, the eight recent creation-date candidates and a known ratings-advisory
   case. Confirm qualifying products, creation meaning, CAT mapping and ratio units.
2. **Resolve the extraction gaps with targeted checks:** correct covenant export;
   Facilities country/CIN dates, especially Siemens DE; current PVD business/ETL
   vintages; and a known KYC case. Avoid repeating all broad extraction until those
   questions have specific answers.
3. **Refine grain and identity:** facility parents, product children and borrower
   links; verified missing-ID routes; category sets rather than first values;
   explicit unavailable/stale/ambiguous states. Keep financial totals separate
   across dates, currencies, overlapping sources and parent/child exposures.
4. **Then build a small evidence view for bankers:** one row per client/signal
   with candidate status, observation/event date, source records, qualifications
   and drill-down. Enable production-like trigger flags only after definitions
   and known examples agree.

## Reproducibility and handoff

- `review_run.py`: inventory, duplicate comparison, source profiles, isolated local
  test, key review and evidence summaries. Input hashes and SQLite integrity checked.
- `file_inventory.csv`, `column_profile.csv`, `review.json`: complete checks.
- `local_test/cohort/REPORT.md`: current development client/source coverage.
- `local_test/signals/results/exports/cohort_signal_evidence.csv`: signal measures,
  raw lineage, imputation flags and reasons; all business triggers remain null.
- `high_utilisation_candidates.csv` and `facilities_key_review.csv`: focused review lists.
- `next_checks/`: four optional read-only SQL diagnostics with exact output names.
  These are generated proposals; no live query was submitted or new package released.
