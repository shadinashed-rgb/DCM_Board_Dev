# SIG07 Application Ratings metadata review

Reviewed **4 November 2026**, using the four files in `sql/SIG07`.

## Conclusion

The schema provides explicit agency ratings, internal CRR values, application
workflow and dates. It offers more direct credit-rating fields than Facilities
`limit_cat`. Actual population, freshness, key grain and advisory interpretation
cannot yet be assessed: the returned files are **metadata and generated query
plans, not application-rating records**.

The next step is to run the three returned client sample queries. They have been
saved as standalone SQL files in `next_sql/`, removing the need to copy SQL out
of a CSV cell. Existing extraction code and original CSVs are unchanged.

## What was returned

| File | Contents | Result |
| --- | --- | --- |
| 01_columns.csv | 227 column definitions | Column names/types now available; no duplicate names. |
| 02_table_definition.csv | One CREATE TABLE definition | Confirms the named Delta object and application-ratings.delta location on HDP45. Only a location property is shown; a native partition strategy is not established by this output. |
| 03_generate_client_queries.csv | Three client plans with sample_sql/profile_sql | All report candidate_sample_sql_ready. Each uses CIN:cin and run_date. |
| 04_rating_column_inventory.csv | 71 matching metadata columns | Supports rating/date/status investigation; these are column definitions, not 71 ratings. |

The table contains `cin` and `mastergroup_name`, but no recognised native
mastergroup-ID or GID column. The plans therefore use candidate CINs from the
existing cohort inventory. Names are not join keys, and a source column called
cin does not independently validate the shared namespace. Application references
include `credit_proposal_serial_no` and `credit_application_number`; their scope
and relationship to Facilities keys still need testing.

## Relevant confirmed fields

| Purpose | Fields present in the schema | Interpretation still needed |
| --- | --- | --- |
| Internal ratings | crr_scale, proposed_crr, approved_crr, final_crr, previous_crr, model_crr, crr_prior_ovrd, crr_post_ovrd | Scale, proposal/approval/final precedence and the meaning/date of previous_crr. |
| S&P | s_and_p_long_term_rating, s_and_p_short_term_rating, s_and_p_rating_date | Population, rating scope, scale and date semantics. |
| Moody's | moody_long_term_rating, moody_short_term_rating, moody_rating_date | Same checks; preserve provider labels and do not compare directly to CRR numbers. |
| Fitch | fitch_long_term_rating, fitch_short_term_rating, fitch_rating_date | Same checks. |
| Application workflow | app_status, latest_approved_appl_flag, latest_record, approval_dt, assessment_approval_dt | Confirm values and actual approval/current-record rules. |
| Time/version evidence | run_date, record_start_dt, record_end_dt, application_creation_dt, assessment_creation_dt | Distinguish snapshot, application, assessment, approval and rating-effective dates. |
| Possible engagement/context clues | scu_engagement_marker, scu_marker_code_type, assessment_type, application_review_type, assessment_review_type, application_l_crr_comments, document_subject_title | Inspect actual values and obtain definitions; no field is yet confirmed to mean ratings-advisory activity. |

The schema also has `sov_*` fields and `ultimate_parent_*` ratings. Keep those
separate from customer/application ratings until their entity scope is confirmed.
Do not label them all as the client's own rating. Numeric approval/rating dates
need their actual format and sentinel treatment checked in returned records.

## Sampling implications

The source uses **wide rating columns**, rather than a recognised rating_type
or rating_agency field. Each generated query therefore returns up to **100 newest
matching rows per client**, retaining all 227 source columns. S&P, Moody's, Fitch
and CRR can coexist within one record; no long-format type quota is applied.

The source observation window is 7 July–4 November 2026, using run_date after
compact/ISO normalisation. Rating/application event dates are preserved without
being used as snapshot dates. Verify the actual run_date format and scan behaviour
in Starburst. The row cap controls returned rows, not scan cost or completeness.
Repeated snapshots or one heavily represented CIN may occupy much of a sample;
the uncapped date profiles are needed alongside it. The samples do not establish
full client/CIN coverage or the latest approved rating.

## Exact next step

Run the following files manually in Starburst:

| SQL in next_sql/ | Save result in sql/SIG07 as |
| --- | --- |
| 01_vodafone_sample.sql | application_ratings_vodafone.csv |
| 02_siemens_energy_sample.sql | application_ratings_siemens_energy.csv |
| 03_softbank_sample.sql | application_ratings_softbank.csv |

Then run profiles 04–06 and save the matching `_profile.csv` files listed in
`next_sql/README.md`. Preserve empty-file headers and original identifiers as text.
These SQL files are exact materialisations of the returned plan, with no new
business rule, source predicate or sampling rule substituted during this review.

## What to decide after the samples arrive

1. Measure non-missing agency/CRR values and actual source/rating dates for each
   client; do not equate a present schema field with a populated/usable rating.
2. Test client mapping and row grain using source/country/carm_instance, CIN,
   proposal/application identifiers, assessment and version dates. Keep provider
   and rating state separate; do not deduplicate on CIN or application alone.
3. Validate proposed vs approved vs final CRR and the latest approval flags on
   known examples. Define a comparable rating-change window and approved scale
   mapping before interpreting upgrades/downgrades.
4. Obtain definitions or a known advisory example for the engagement markers.
   If they do not identify the advisory activity, use this source for credit-rating
   context and continue the advisory-event source investigation separately.
5. Compare with Facilities categories and PVD only after keys, dates and business
   meanings are aligned. No source winner or SIG07 trigger is selected yet.

## Review validation

`review_metadata.py` records input SHA-256 hashes, verifies 227 unique columns
and three ready plans, and writes `review.json`. All six returned SELECTs were
executed in read-only SQLite against a synthetic 227-column source: client
separation, date bounds, preservation of wide ratings and profile counts passed.
This tests local selection logic, not live Starburst data, permissions, pushdown
or actual field meanings. All four original file hashes remain unchanged.
