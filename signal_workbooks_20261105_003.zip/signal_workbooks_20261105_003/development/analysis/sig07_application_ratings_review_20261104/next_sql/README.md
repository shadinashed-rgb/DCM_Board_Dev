# Run the three rating samples next

These six files contain the SQL returned by `sql/SIG07/03_generate_client_queries.csv`.
They access delta.prod_credit_and_lending_gda.application_ratings and use candidate
CIN matches. No database query was submitted during the local review.

First run sample files 01–03 manually in Starburst:

| SQL file | Save CSV as |
| --- | --- |
| 01_vodafone_sample.sql | application_ratings_vodafone.csv |
| 02_siemens_energy_sample.sql | application_ratings_siemens_energy.csv |
| 03_softbank_sample.sql | application_ratings_softbank.csv |

Then run the uncapped date-count profiles:

| SQL file | Save CSV as |
| --- | --- |
| 04_vodafone_profile.sql | application_ratings_vodafone_profile.csv |
| 05_siemens_energy_profile.sql | application_ratings_siemens_energy_profile.csv |
| 06_softbank_profile.sql | application_ratings_softbank_profile.csv |

Place the six CSVs in `sql/SIG07/` alongside the existing schema/plan files. Keep
headers even when empty, and save any query errors separately. Download original
CSV files without spreadsheet conversion of long IDs or leading zeros.

The sample cap is 100 rows per client. Ratings are separate columns, so the same
record can contain S&P, Moody's, Fitch and CRR values. The source-date window is
7 July–4 November 2026; preserve older rating-effective/approval dates as returned.
Plan-ready and sample rows are discovery evidence, not approval of CIN namespaces,
current-rating selection, source completeness or advisory-engagement interpretation.
