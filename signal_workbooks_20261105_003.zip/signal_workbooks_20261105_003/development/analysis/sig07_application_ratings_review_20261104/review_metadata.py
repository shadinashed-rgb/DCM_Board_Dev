"""Review the returned SIG07 metadata and materialise its client queries.

Original four CSVs are read-only. Query checks use synthetic ratings in a local
SQLite database with query_only enabled, not live source data or Starburst.
"""
import csv
import hashlib
import json
from pathlib import Path
import sqlite3

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
INPUT=ROOT/'sql/SIG07'
TABLE='"delta"."prod_credit_and_lending_gda"."application_ratings"'
CLIENTS=[('MG001356','vodafone','1018544917'),('MG102229','siemens_energy','2020052910083'),('MG101624','softbank','JPHSBC009054222')]


def read(path):
    with path.open(encoding='utf-8-sig',newline='') as handle:
        reader=csv.DictReader(handle);rows=list(reader)
        if any(None in r or None in r.values() for r in rows):raise ValueError('Malformed CSV: '+str(path))
        return rows


def main():
    if (OUT/'next_sql').exists():raise ValueError('Review output already exists')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUT.glob('*.csv')}
    columns=read(INPUT/'01_columns.csv')
    definition=read(INPUT/'02_table_definition.csv')[0]['Create Table']
    plans=read(INPUT/'03_generate_client_queries.csv')
    rating_inventory=read(INPUT/'04_rating_column_inventory.csv')
    names=[c['Column'] for c in columns]
    assert len(names)==len(set(names))==227
    assert 'CREATE TABLE delta.prod_credit_and_lending_gda.application_ratings' in definition
    assert {p['mastergroup_id'] for p in plans}=={g for g,_,_ in CLIENTS}
    assert all(p['plan_status']=='candidate_sample_sql_ready' and p['matched_columns']=='CIN:cin' and p['snapshot_column']=='run_date' for p in plans)
    assert all(p['sample_dimensions']=='' for p in plans)
    db=sqlite3.connect(':memory:');db.row_factory=sqlite3.Row
    quoted=lambda value:'"'+value.replace('"','""')+'"'
    db.execute('CREATE TABLE ratings ('+','.join(quoted(n)+' TEXT' for n in names)+')')
    fixtures=[]
    for group,label,cin in CLIENTS:
        for observed in ['20261103','20261030','20261105','20260101']:
            row=dict(cin=cin,run_date=observed,country_code='TEST',source_system_name='SYNTHETIC',
                     customer_name='SYNTHETIC '+label,app_status='SYNTHETIC',
                     final_crr='TEST_CRR',s_and_p_long_term_rating='TEST_SP',
                     moody_long_term_rating='TEST_MOODY',fitch_long_term_rating='TEST_FITCH',
                     s_and_p_rating_date='20000101')
            fixtures.append([row.get(n,'') for n in names])
    db.executemany('INSERT INTO ratings VALUES ('+','.join('?' for _ in names)+')',fixtures)
    db.execute('PRAGMA query_only=ON')
    output=OUT/'next_sql';output.mkdir()
    checks=[]
    for index,(group,label,cin) in enumerate(CLIENTS,1):
        plan=next(p for p in plans if p['mastergroup_id']==group)
        for kind in ('sample_sql','profile_sql'):
            text=plan[kind]
            assert TABLE in text and '\\n' not in text and '\\"' not in text
            result=list(db.execute(text.replace(TABLE,'ratings')))
            assert len(result)==2
            if kind=='sample_sql':
                assert {r['cin'] for r in result}=={cin}
                assert {r['_sig07_observation_date'] for r in result}=={'20261103','20261030'}
                assert all(r['s_and_p_long_term_rating']=='TEST_SP' and r['final_crr']=='TEST_CRR' for r in result)
                prefix=index;suffix='sample'
            else:
                assert sum(r['raw_rows'] for r in result)==2
                prefix=index+3;suffix='profile'
            filename=f'{prefix:02d}_{label}_{suffix}.sql'
            # Save the exact returned SQL so no predicate or sampling rule changes.
            (output/filename).write_text(text.rstrip()+'\n')
            checks.append(dict(mastergroup_id=group,query=kind,file=filename,synthetic_rows=len(result)))
    db.close()
    summary=dict(assessment_date='2026-11-04',input_folder=str(INPUT),columns=len(columns),
        rating_inventory_rows=len(rating_inventory),client_plans=len(plans),
        data_records_supplied=0,source_table=TABLE,source_date_column='run_date',
        client_lookup='cin; candidate cross-source namespace, not approved identity',
        rating_shape='wide columns; S&P, Moody, Fitch and CRR coexist in a row',
        available_fields={
            'client_and_application':['cin','customer_id','relationship_id','credit_proposal_serial_no','credit_application_number','country_code','source_system_name','carm_instance'],
            'internal_ratings':['crr_scale','proposed_crr','approved_crr','final_crr','previous_crr','crr_prior_ovrd','crr_post_ovrd','model_crr'],
            'external_ratings':['s_and_p_long_term_rating','s_and_p_short_term_rating','s_and_p_rating_date','moody_long_term_rating','moody_short_term_rating','moody_rating_date','fitch_long_term_rating','fitch_short_term_rating','fitch_rating_date'],
            'workflow_dates':['app_status','approval_dt','application_creation_dt','assessment_creation_dt','assessment_approval_dt','record_start_dt','record_end_dt','latest_record','latest_approved_appl_flag'],
            'interpretation_candidates':['scu_engagement_marker','scu_marker_code_type','assessment_type','application_review_type','assessment_review_type','application_l_crr_comments','document_subject_title']},
        source_hashes=hashes,local_sql_checks=checks,
        validation='227-column synthetic source; client/date/type-column checks passed with SQLite query_only; no live data SQL executed')
    assert all(n in names for fields in summary['available_fields'].values() for n in fields)
    assert all(hashlib.sha256((INPUT/n).read_bytes()).hexdigest()==digest for n,digest in hashes.items())
    (OUT/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['available_fields','source_hashes']},indent=2))


if __name__=='__main__':main()
