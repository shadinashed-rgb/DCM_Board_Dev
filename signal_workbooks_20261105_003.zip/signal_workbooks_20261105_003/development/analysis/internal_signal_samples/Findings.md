# Internal signal sample review

**Later development decisions:** see the [3 November current-data review](../source_refresh_review_20261103/Findings.md).
Counterparty's catalog is corrected to Delta, SIG01 missing drawn values are
zero-imputed for testing, and Facilities `limit_cat` remains a SIG07 candidate.
The dated sample observations below are preserved as historical evidence.

Sample review date: 28 October 2026 | Planning reconciliation: 29 October 2026

The current approach is broader candidate-data capture across the identified sources, starting with CLO, followed by refinement and source selection through testing. Use a shared client cohort for later interpretation and join checks rather than assuming it must restrict the whole raw extraction. This follows the [updated planning notes](../../Bond%20Radar%20Signal%20Planning%20Notes.md).

The observations below remain findings from the supplied samples. Later candidate mappings and the Counterparty code review are separate evidence; they do not change the original records or establish current source-wide coverage. SIG05 and PVD sector aggregate are outside the active plan.

## File matching

The original review received seven 100-row source samples and corresponding schemas. Six remain active signal-data candidates; the sector aggregate is retained only as historical review evidence. No Counterparty Core sample has been supplied. Schema exports use three formats: tabular `information_schema.columns`, `SHOW COLUMNS` and a `SHOW CREATE TABLE` result. Every sampled column appears in its matched schema.

| Source | Matched schema | Matched sample | Schema columns |
| --- | --- | --- | --- |
| `hive.clo_prod.clo_cda_contract_lvl` | `clo_schema.csv` | `clo_sample.csv` | 400 |
| `delta.prod_credit_and_lending_gda.facilities_limits` | `facilities_limits_schema.csv` | `facilities_limits_sample.csv` | 181 |
| `delta.prod_party_gda.kyc` | `kyc_schema.csv` | `kyc_samples.csv` | 325 |
| `delta.prod_credit_and_lending_gda.covenants` | `covenants_schema.csv` | `covenant_samples.csv` | 106 |
| `delta.prod_credit_and_lending_mda.drr_facility_limits` | `drr_facility_schema.csv` | `drr_facility_samples.csv` | 151 |
| `hive.pvd_prod_wave.pvd_omnia_drr` | `omina_drr_schema.csv` | `omina_drr_samples.csv` | 89 |
| `hive.pvd_prod_wave.pvd_omnia_drr_agg_sec_app` | `omina_drr_agg_schema.csv` | `omina_drr_agg_sample.csv` | 16 |

The `omina` filename spelling is matched to `omnia` using the qualified identifiers in those schema files. Facilities Limits is matched by filename, matching columns and the existing query because its SHOW COLUMNS export has no qualified table identifier. The other six schemas identify their source explicitly.

Input files are in [sql_samples](../../sql/sql_samples). The additional CLO outputs are `03_date_and_grain_profile.csv` and `04_facility_history_sample.csv`. No source-discovery result file or execution log is present.

## SIG01 RCF drawings

The [CLO raw sample](../../sql/sql_samples/clo_sample.csv) contains 100 rows, all from `LIQ_HBHK` on `20260914`. There are 38 scoped candidate facility keys, using source, mapping system, booking entity and the established identifier fallback. A facility appears up to 29 times, and five rows are exact duplicates across the 19 exported columns. Repeated rows must not be summed as independent facility amounts.

The pre-aggregated drawn field is populated in 92 rows, compared with 76 rows for account drawn amount. These are distinct measures. Mastergroup ID is blank in 85 rows, although obligor CIN is populated in all 100. `facility_id` is blank in every row, while `sub_lim_id` is populated in all rows. Eight candidate keys have multiple obligor CINs, so selecting one borrower with MAX would lose relationships. No conflicting non-null limit or pre-aggregated drawn values were found within the 38 sampled scoped keys.

The [date profile](../../sql/sql_samples/03_date_and_grain_profile.csv) has 639 grouped rows covering `20260730` through `20261028`. Latest observed dates differ between mapping systems. These are raw exploded-record counts by date and source scope, not client counts or unique facility counts across history.

The [history export](../../sql/sql_samples/04_facility_history_sample.csv) contains its 26-column header and zero data rows. It does not establish that the source lacks history. The saved history query, translated to DuckDB and run on the supplied 100 raw rows as the entire local source, returned 20 facility-date rows. That check does not reproduce Starburst or establish the cause of the empty remote export.

Next: confirm the actual submitted history SQL, date bounds, successful completion and export. Re-run against a fixed small set of scoped keys, checking the bounded, seed, cohort and join stages if the result remains empty. Then capture the agreed broader source scope, including repeated observations and group-enrichment fields, and use fixed clients/facilities for validation. Confirm HSBC share, full-facility amounts and currency treatment before applying materiality rules.

## Counterparty Core enrichment planning

The missing CLO mastergroups justify investigating a supporting enrichment source. The [previous handover archive](../../clo_counterparty_production_handover.zip) was reviewed for its matching feature only. It reads Counterparty Core from `hdfs://HDP46/apps/hive/warehouse/data-refinery/party/party/counterparty-core.delta`; the proposed current catalog table `hive.prod_party_gda.counterparty_core` remains unconfirmed.

The code maps CLO `obligor_cin` and `rct_gid` to `customer_relationship_cin_identifier` and `customer_relationship_gid_identifier`, obtaining candidates from `mastergroup_esr_identifier`. It preserves valid original IDs, flags source conflicts and fills missing/invalid IDs only when the combined CIN/GID candidate set has one distinct result. Multiple candidates remain ambiguous and missing matches unresolved.

This is code evidence, not a measured recovery result. The initial CLO raw sample lacks `rct_gid`, so the next capture needs that field. No Counterparty schema/sample or current matching coverage has been verified. The code does not fill mastergroup names. Validate per-route dates and historical as-of policy, lifecycle/sentinel settings, borrower relationships and row/amount preservation before adopting the feature. Do not adopt the old solution's full extraction or publication contract.

The [planning notes](../../Bond%20Radar%20Signal%20Planning%20Notes.md#counterparty-core-enrichment-of-clo-mastergroup-data) contain the full mapping and audit requirements.

## SIG02 New facilities

The [Facilities Limits sample](../../sql/sql_samples/facilities_limits_sample.csv) is entirely `cfb`, country `TH`, `run_date = 20240616`, with `latest_record = HISTORICAL`. `facility_creation_date`, `loan_approva_dt`, CIN, relationship ID and customer ID are all blank in the 100 sampled rows. `record_start_dt` and `record_end_dt` are populated, but their names and values do not establish a signing date.

The actual schema field is **`facility_creation_date`**, rather than `facility_creation_dt` in the earlier investigation notes. In addition, `active_facility_ind` contains date-shaped values in all 100 rows, rather than a conventional flag. This needs source-definition or export-mapping confirmation before it is used as an eligibility predicate.

Next: profile coverage by country, source, available date and `latest_record` value. Obtain recent records with populated client and creation fields, including verified RCF, term-loan and bridge product codes. Validate creation dates against known events. This historical subset is insufficient to accept or reject the source for new-facility detection.

## SIG04 KYC events

The [KYC sample](../../sql/sql_samples/kyc_samples.csv) has `run_date = 20261027`, with populated CIN and case ID in every row. The review purposes are New to Bank, Trigger, Periodic and Remediation. All sampled cases have status `COMPLT`.

`related_case_resolved_time` is populated in every row and ranges from 19 May 2017 to 7 October 2026. Only four sampled cases were resolved between 30 July and 28 October 2026. Request creation time is populated in 81 rows. Explicit event-trigger details, review decision date, assignment date and next-review date are blank in this sample.

Next: use case dates to obtain recent New to Bank and Trigger examples, alongside Periodic and Remediation examples for comparison. Confirm the meaning of the purpose codes and resolved timestamps with the KYC source team. Determine whether snapshots repeat the same case and whether multiple cases per client are retained. No sampled evidence yet establishes a signatory-change signal, and Trigger reviews must not automatically be interpreted as financing activity.

## SIG06 Covenants and utilisation

The [covenant sample](../../sql/sql_samples/covenant_samples.csv) contains five covenants on one facility in `AE`, all classified as `NonFinancial` and `NonFinancialMIReporting`. Status is Compliant in 76 rows and Overdue in 24 rows; these are repeated observations and testing instances, not 24 independent breaches. Financial threshold and actual-value fields are blank throughout this sample. Overdue non-financial reporting cannot establish financial covenant pressure.

`covenant_id + run_date` gives only 63 distinct combinations across 100 rows. Adding `active_testing_id` gives 100 distinct combinations in this sample. The testing-instance grain needs to be retained and validated before any latest-record selection. The DDL points to an `HDP45` HDFS location, so a future Spark extraction must not assume the earlier HDP46 path context applies to this table.

The [DRR Facility Limits sample](../../sql/sql_samples/drr_facility_samples.csv) has populated CIN, mastergroup, facility ID, approved limit and utilisation fields. Its reporting dates are from May to July 2023. Approved limit is zero in 45 rows, and currency fields are missing or differ in some rows. The waiver field `covenaint_waiver_date` contains `99991231` in 99 rows, which should not be treated as a real upcoming waiver event.

Next: request financial covenants with populated measures, comparison operators, testing dates and approved results. Independently obtain recent, client-matched DRR records for utilisation analysis. Confirm measure units and denominator treatment. A 70% utilisation indicator remains distinct from a covenant breach or covenant-headroom measure.

No facility IDs overlap between the independent Facilities Limits, covenant and DRR samples. This does not measure production join coverage: their countries, dates and selected clients are not aligned. Establish a common cohort and authoritative identifier bridge before judging joins.

## PVD OMNIA DRR and current candidate mappings

The [PVD OMNIA sample](../../sql/sql_samples/omina_drr_samples.csv) offers relationship-level identifiers and limit/utilisation fields, but its sampled business dates span 2020 to July 2025. Thirty rows have no DRR amounts. Retain it as another SIG06 utilisation candidate during planning/testing, pending amount definitions, compatible units, denominator, current coverage and grain checks. Its exposed schema has no explicit facility ID or currency field.

The [aggregated PVD schema](../../sql/sql_samples/omina_drr_agg_schema.csv) was inspected in the original review and has no client or facility identifier. It is excluded from the current collection plan and both updated flowcharts. Its historical input files and recorded profile remain unchanged.

**SIG07 now has unverified candidates.** PVD exposes `drr_crr`, `drr_fac_category` and `joi_facility_category`; the sample includes rating-like values and CAT-A/B/S classifications. Facilities Limits exposes `limit_cat`, `limit_category_type` and `advised_ind`, with grade/rating-impact fields present but blank in its sample. Category/rating definitions and the intended SIG07 event must be confirmed. These are not verified ratings-advisory engagement records.

**SIG03 still has no identified source.** Enquiry or pricing-request data needs discovery with the derivatives/hedging team; executed trades alone may miss the early request.

## Recommended next extraction

1. Agree source-specific date, country and client bounds, then capture available candidate attributes/history across CLO, Facilities Limits, KYC, Covenants, DRR and PVD. Preserve raw data, schemas, table definitions, queries/parameters and extraction metadata. Defer business trigger filters to refinement.
2. Start with CLO and resolve the empty history export. Include `rct_gid`, original mastergroup fields and borrower associations; use fixed scoped keys to validate history and repeated amounts.
3. Confirm the proposed Counterparty table/schema and test the combined CIN/GID enrichment feature, including ambiguous matches, conflicts, names and historical dates. Keep raw inputs and audit evidence.
4. Collect broader Facilities Limits and KYC examples. Use `facility_creation_date`, verify product/flag semantics, and preserve KYC business timestamps and routine comparison categories.
5. Obtain financial covenant examples and recent DRR/PVD measures. Check grain, currencies and denominators before testing utilisation above 70%; keep it distinct from covenant evidence.
6. Use a shared client/date cohort to validate interpretations and joins, then refine source choices with bankers. Confirm SIG07 definitions and continue SIG03 source discovery.

Candidate outputs should retain client/entity/source-record references, business and observation dates, evidence, freshness and unresolved qualifications. Missing evidence is unavailable rather than a negative signal. Counterparty supports identity enrichment; it does not change financial trigger definitions.

## Evidence and limits

[review_samples.py](review_samples.py) reproduces the source matching, field profiles, date ranges, key checks and limited-sample overlaps. [sample_profile.json](sample_profile.json) retains the calculations and input checksums. [clo_history_local_check.json](clo_history_local_check.json) records the separate translated history check and its limitations.

No live database was queried in this review or reconciliation, and no input CSV, recorded profile, archive or extraction SQL was modified. Unordered 100-row samples cannot establish source-wide null rates, freshness, completeness or join performance. Local schemas and observations establish candidate fields; their business meaning still requires source-owner confirmation.
