"""Reproducible, local review of returned SQL samples. Does not modify inputs."""
from pathlib import Path
from collections import Counter
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import csv
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
INPUT = ROOT / 'sql' / 'sql_samples'
OUT = Path(__file__).resolve().parent
MAPPINGS = [
    ('clo', 'clo_schema.csv', 'clo_sample.csv', 'hive.clo_prod.clo_cda_contract_lvl'),
    ('facilities_limits', 'facilities_limits_schema.csv', 'facilities_limits_sample.csv', 'delta.prod_credit_and_lending_gda.facilities_limits'),
    ('kyc', 'kyc_schema.csv', 'kyc_samples.csv', 'delta.prod_party_gda.kyc'),
    ('covenants', 'covenants_schema.csv', 'covenant_samples.csv', 'delta.prod_credit_and_lending_gda.covenants'),
    ('drr_facility_limits', 'drr_facility_schema.csv', 'drr_facility_samples.csv', 'delta.prod_credit_and_lending_mda.drr_facility_limits'),
    ('pvd_omnia_drr', 'omina_drr_schema.csv', 'omina_drr_samples.csv', 'hive.pvd_prod_wave.pvd_omnia_drr'),
    ('pvd_omnia_drr_agg_sec_app', 'omina_drr_agg_schema.csv', 'omina_drr_agg_sample.csv', 'hive.pvd_prod_wave.pvd_omnia_drr_agg_sec_app'),
]
def load(name):
    p = INPUT / name
    with p.open(encoding='utf-8-sig', newline='') as f:
        r = csv.DictReader(f)
        rows = list(r)
        assert all(None not in row and None not in row.values() for row in rows), name
        return list(r.fieldnames or []), rows

def normal(value):
    value = (value or '').strip()
    return None if value.lower() in ('', 'null', r'\n', 'none') else value

def number(value):
    try:
        v = Decimal(value)
        return v if v.is_finite() else None
    except (InvalidOperation, TypeError):
        return None

def parse_date(value):
    if value is None or value in ('0', '00000000'):
        return None
    try:
        if re.fullmatch(r'\d{8}', value):
            return datetime.strptime(value, '%Y%m%d').date().isoformat()
        if re.match(r'^\d{4}-\d{2}-\d{2}', value):
            return date.fromisoformat(value[:10]).isoformat()
    except ValueError:
        pass
    return None

def profile(columns, rows):
    result = {}
    n = len(rows)
    for c in columns:
        values = [normal(r[c]) for r in rows]
        populated = [v for v in values if v is not None]
        counts = Counter(populated)
        d = {'rows': n, 'populated': len(populated), 'missing': n-len(populated), 'distinct_nonblank': len(counts)}
        if re.search(r'(date|_dt$|_dt_|month|timestamp|time_stamp|_time$)', c):
            parsed = [parse_date(v) for v in populated]
            valid = [v for v in parsed if v]
            d['dates'] = {'valid': len(valid), 'min': min(valid) if valid else None,
                          'max': max(valid) if valid else None,
                          'zero_sentinels': sum(v in ('0','00000000') for v in populated),
                          'unparsed_nonblank': sum(v is None for v in parsed)}
        numeric = [number(v) for v in populated]
        valid_num = [v for v in numeric if v is not None]
        if valid_num:
            d['numbers'] = {'parseable': len(valid_num), 'invalid_nonblank': len(populated)-len(valid_num),
                            'zero': sum(v == 0 for v in valid_num), 'negative': sum(v < 0 for v in valid_num),
                            'min': str(min(valid_num)), 'max': str(max(valid_num))}
        # Exclude personal names, customer IDs and free-form comments from value listings.
        if re.search(r'(status|^event_trigger$|^review_purpose|^related_case_type$|^related_case_class$|trigger.*type|^covenant_type$|^covenant_sub_type$|^covenant_financial_derived_type$|^covenant_category_type$|^last_testing_result$|^historic_final_result$|^active_testing_.*result$|threshold_operator|^local_product_type_lbs$|^mapping_system$|^source_system$|^source_system_name$|^country_code$|^product_type$|^product_code$|^latest_record$|^cancellation_ind$|^active_facility_ind$|^facility_cancelled_ind$)', c):
            d['values'] = dict(counts.most_common(15))
        result[c] = d
    return result

report = {'scope': 'Supplied CSV exports only; arbitrary LIMIT samples are not population estimates.',
          'sources': {}, 'clo_profile': {}, 'history_export': {}}
loaded = {}
for source, schema_file, sample_file, qualified in MAPPINGS:
    sc, sr = load(schema_file)
    if 'column_name' in sc:
        schema = {r['column_name']: r['data_type'] for r in sr}
        recorded_tables = sorted({'.'.join(r[k] for k in ('table_catalog','table_schema','table_name')) for r in sr})
        assert recorded_tables == [qualified], recorded_tables
        fmt = 'information_schema.columns'
    elif 'Column' in sc:
        schema = {r['Column']: r['Type'] for r in sr}
        fmt = 'SHOW COLUMNS'
    elif sc == ['Create Table']:
        ddl = sr[0]['Create Table']
        assert qualified in ddl, qualified
        body = ddl.split('(\n',1)[1].split('\n)',1)[0]
        schema = {}
        for line in body.splitlines():
            name, typ = line.strip().rstrip(',').split(' ',1)
            schema[name] = typ
        fmt = 'SHOW CREATE TABLE'
    else:
        raise ValueError(schema_file)
    columns, rows = load(sample_file)
    loaded[source] = (columns, rows)
    result = {'source': qualified, 'schema_file': schema_file, 'sample_file': sample_file,
              'source_match_basis': 'Filename and matching sample/schema columns' if fmt == 'SHOW COLUMNS' else 'Qualified source identifier in schema export',
              'schema_format': fmt, 'schema_columns': len(schema), 'sample_columns': len(columns),
              'sample_rows': len(rows), 'exact_duplicate_rows': len(rows)-len({tuple(r[c] for c in columns) for r in rows}),
              'sample_columns_absent_from_schema': sorted(set(columns)-set(schema)),
              'schema_columns_absent_from_sample': sorted(set(schema)-set(columns)),
              'schema': schema, 'columns': profile(columns, rows)}
    if source == 'covenants':
        result['recorded_hdfs_location'] = re.search(r"location = '([^']+)'",ddl).group(1)
    report['sources'][source] = result

cc, clo = loaded['clo']
def clo_key(r):
    for tier, c in [('SUB_LIMIT','sub_lim_id'),('RCT_REF','rct_facility_ref'),('FACILITY_ID','facility_id')]:
        if normal(r[c]):
            return (normal(r['source_system']), normal(r['mapping_system']), normal(r['hsbc_booking_legal_entity']), tier+':'+normal(r[c]))
    return None
key_counts = Counter(clo_key(r) for r in clo if clo_key(r))
report['sources']['clo']['scoped_candidate_keys'] = len(key_counts)
report['sources']['clo']['rows_without_candidate_key'] = sum(clo_key(r) is None for r in clo)
report['sources']['clo']['max_rows_per_scoped_key'] = max(key_counts.values(),default=0)
profile_columns, profile_rows = load('03_date_and_grain_profile.csv')
date_summary = {}
systems = {}
for r in profile_rows:
    day = r['run_date']
    stats = date_summary.setdefault(day, {'raw_rows':0,'raw_rev_rows':0,'rows_without_facility_key':0,'sum_group_distinct_keys':0})
    for c in ('raw_rows','raw_rev_rows','rows_without_facility_key'):
        stats[c] += int(r[c])
    stats['sum_group_distinct_keys'] += int(r['distinct_candidate_facility_keys'])
    sys = r['mapping_system'] or '(blank)'
    a = systems.setdefault(sys, {'min_date':day,'max_date':day,'raw_rows':0,'raw_rev_rows':0})
    a['min_date'] = min(a['min_date'],day)
    a['max_date'] = max(a['max_date'],day)
    a['raw_rows'] += int(r['raw_rows'])
    a['raw_rev_rows'] += int(r['raw_rev_rows'])
report['clo_profile'] = {'file':'03_date_and_grain_profile.csv','export_rows':len(profile_rows),
                         'min_date':min(date_summary,default=None),'max_date':max(date_summary,default=None),
                         'by_date':date_summary,'by_mapping_system':systems,
                         'sum_raw_rows':sum(v['raw_rows'] for v in date_summary.values()),
                         'sum_raw_rev_rows':sum(v['raw_rev_rows'] for v in date_summary.values()),
                         'sum_rows_without_key':sum(v['rows_without_facility_key'] for v in date_summary.values())}
hc, history = load('04_facility_history_sample.csv')
report['history_export'] = {'file':'04_facility_history_sample.csv','rows':len(history),'columns':len(hc)}

# Overlap in independent limited samples is diagnostic only, never a production match rate.
overlaps=[]
for left,lk,right,rk in [('facilities_limits','facility_id','covenants','facility_id'),
                        ('facilities_limits','facility_id','drr_facility_limits','facility_id'),
                        ('covenants','facility_id','drr_facility_limits','facility_id'),
                        ('facilities_limits','cin','drr_facility_limits','cin'),
                        ('facilities_limits','cin','kyc','cin')]:
    a={normal(r[lk]) for r in loaded[left][1] if normal(r[lk])}
    b={normal(r[rk]) for r in loaded[right][1] if normal(r[rk])}
    overlaps.append({'left':left+'.'+lk,'right':right+'.'+rk,'left_distinct':len(a),
                     'right_distinct':len(b),'intersection':len(a&b),
                     'qualification':'Independent LIMIT samples; not a join coverage estimate.'})
report['limited_sample_key_overlap'] = overlaps
report['additional_checks'] = {}
clo_groups = {}
for row in clo:
    key = clo_key(row)
    if key:
        clo_groups.setdefault(key, []).append(row)
report['additional_checks']['clo_scoped_keys_with_multiple_obligor_cins'] = sum(
    len({normal(r['obligor_cin']) for r in rows if normal(r['obligor_cin'])}) > 1
    for rows in clo_groups.values())
report['additional_checks']['clo_scoped_keys_with_conflicting_nonblank_amounts'] = {
    c:sum(len({number(normal(r[c])) for r in rows if number(normal(r[c])) is not None}) > 1
          for rows in clo_groups.values())
    for c in ('facility_limit_amount','ag_acc_bal_drawn_sub_lim_usd')}
cov = loaded['covenants'][1]
report['additional_checks']['covenant_candidate_grains'] = {
    ','.join(keys):len({tuple(normal(r[k]) for k in keys) for r in cov})
    for keys in [('covenant_id',),('covenant_id','run_date'),('covenant_id','active_testing_id','run_date')]}
kyc = loaded['kyc'][1]
report['additional_checks']['kyc_cases_resolved_in_example_date_window'] = sum(
    '2026-07-30' <= (parse_date(normal(r['related_case_resolved_time'])) or '') <= '2026-10-28'
    for r in kyc)
fac = loaded['facilities_limits'][1]
report['additional_checks']['facility_active_indicator_values_parseable_as_yyyymmdd_dates'] = sum(
    bool(re.fullmatch(r'\d{8}',r['active_facility_ind'])) and parse_date(r['active_facility_ind']) is not None
    for r in fac)
drr = loaded['drr_facility_limits'][1]
report['additional_checks']['drr_waiver_date_99991231_sentinel_rows'] = sum(
    parse_date(normal(r['covenaint_waiver_date'])) == '9999-12-31' for r in drr)
report['input_sha256'] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(INPUT.glob('*.csv'))}
(OUT/'sample_profile.json').write_text(json.dumps(report,indent=2)+'\n')
print('Source mapping and overview:')
for key,r in report['sources'].items():
    print(key,':',r['sample_rows'],'rows;',r['schema_columns'],'schema columns;',r['exact_duplicate_rows'],'duplicate rows; schema mismatch:',r['sample_columns_absent_from_schema'])
print('CLO scoped keys:',len(key_counts),'maximum repeated rows:',max(key_counts.values(),default=0))
print('CLO profile:',{k:v for k,v in report['clo_profile'].items() if k not in ('by_date','by_mapping_system')})
print('History export:',report['history_export'])
print('Evidence:',OUT/'sample_profile.json')
