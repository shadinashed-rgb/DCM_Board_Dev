"""Execute delivered selection SQL on local exports using a SQLite compatibility adapter.

This checks selected rows/window logic, not live Starburst types or permissions.
Counterparty is synthetic because no current Counterparty export was supplied.
"""
import csv
from datetime import datetime
import json
from pathlib import Path
import sqlite3
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'pvd_client_cohort_lab'))
from refresh import read_csv
from cohort import engine


def parsed(value, pattern):
    try:
        return datetime.strptime(value, pattern).isoformat()
    except (TypeError, ValueError):
        return None


def main():
    db = sqlite3.connect(':memory:')
    db.create_function('DATE_PARSE', 2, parsed)
    db.create_function('TRY', 1, lambda value: value)
    sources = {
        'clo':'sql_sample_extract/04_name_candidates_clo.csv',
        'pvd':'sql_sample_extract/04_name_candidates_pvd_1-7_to_30_10.csv',
        'drr':'sql/sql_samples/drr_mastergroup_ids_sample.csv',
        'facilities':'sql/sql_samples/sample_dcm/facilities_cin_lookup.csv',
        'kyc':'sql/sql_samples/kyc_samples.csv',
        'covenants':'sql/sql_samples/covenant_samples.csv',
    }
    for source, name in sources.items():
        columns, rows = read_csv(ROOT/name)
        db.execute('CREATE TABLE '+engine.ident(source)+' ('+','.join(engine.ident(c)+' TEXT' for c in columns)+')')
        db.executemany('INSERT INTO '+engine.ident(source)+' VALUES ('+','.join('?' for c in columns)+')',([r[c] for c in columns] for r in rows))
    db.execute('CREATE TABLE counterparty(run_date TEXT,customer_relationship_cin_identifier TEXT,customer_relationship_gid_identifier TEXT,mastergroup_esr_identifier TEXT,customer_relationship_lifecycle_status_code TEXT)')
    db.executemany('INSERT INTO counterparty VALUES (?,?,?,?,?)',[(d,'1018544917','G_TEST',mg,'A') for d,mg in [('20260901','MG001356'),('20261029','MG001356'),('20261030','MG001356'),('20261102','MG_OUTSIDE')]])
    results = []
    for source in engine.SOURCES:
        query = (ROOT/f'pvd_client_cohort_lab/sql_templates/current_20261103/{source}_extract.sql').read_text()
        for dataset, spec in engine.SOURCES.items():
            query = query.replace('.'.join(engine.ident(p) for p in spec['table'].split('.')),engine.ident(dataset))
        cursor = db.execute(query)
        columns = [d[0] for d in cursor.description]
        rows = [dict(zip(columns,r)) for r in cursor]
        results.append(dict(source=source,selected_rows=len(rows),fixture='synthetic' if source=='counterparty' else sources[source]))
        if source == 'clo':
            assert sum(r['rct_mastergroup_id'] in ('MG001356','MG102229','MG101624') for r in rows)==296
        if source == 'counterparty':
            assert {r['run_date'] for r in rows}=={'20261029','20261030','20261102'}
            assert any(r['mastergroup_esr_identifier']=='MG_OUTSIDE' for r in rows)
        if source == 'facilities':
            assert len(rows)==25
        if source == 'drr':
            assert len(rows)==100 and {r['reporting_date'] for r in rows}=={'20261030'}
        if source == 'pvd':
            assert len(rows)==143
    db.close()
    (OUT/'sql_validation.json').write_text(json.dumps(dict(adapter='SQLite with DATE_PARSE/TRY adapters; no live Starburst execution',results=results),indent=2)+'\n')
    print(json.dumps(results,indent=2))


if __name__ == '__main__':
    main()
