# Source repetition and current signal review

Assessment: **3 November 2026**. Scope: supplied local CSVs and the three target
groups. No live Starburst query was executed. All 28 inventoried input-file hashes
were unchanged after analysis.

## Evidence reviewed

`export_inventory.csv` and `inventory.json` cover CSVs under `sql/sql_samples/`
(including sample_dcm) and `sql_sample_extract/`: 13 recognised data exports,
nine schemas, one profile, one query-error export and four other files. Identifier
review and excluded/unsupported aggregate formats were not treated as facility
data. Reordered copies of the CLO name export contain the same row multiset.

Current client tests use the full CLO/PVD client exports plus the newly supplied
Vodafone DRR and Siemens Facilities data. Older unrelated samples remain in the
inventory, not the three-client signal population. Recent Siemens/SoftBank DRR
counts were pasted in a report, but their raw exports have not been supplied
locally. No current Counterparty or financial-covenant client export was supplied.
The latest KYC lookups were reported empty; the old KYC sample does not establish
coverage for the target clients.

## Row reduction

| Source / scope | Raw target rows | Selected rows | Derived observations |
| --- | ---: | ---: | --- |
| CLO, three groups | 3,350 | 296 | 8 over two dates; **4 current** facility observations |
| DRR, Vodafone | 2,998 | 100 | **93** current candidate exposure observations |
| Facilities, Siemens | 349 | 25 | **25** current effective versions |
| PVD, three groups | 850 | 143 | **33** native relationship/key observations; grain unverified |

CLO retains 29 and 30 October for comparison. A key present only on the earlier
date is not resurrected as current. Multiple borrower associations are preserved
at landing; agreeing facility measures are consolidated with lineage.

DRR retains reporting date 30 October, loaded 31 October. Seven shared exposure
keys each have two agreeing borrower-association rows, explaining 100 to 93.
UID is an internal candidate exposure key, not a verified economic or cross-source
facility identity. Fifteen latest rows still contain facility_id `1.01854E+19`;
UID does not restore the original digits. Parent/child limits are not summed.

Facilities excludes 324 out-of-period versions using record_start_dt/record_end_dt.
The remaining 25 open-ended rows include 12 CURRENT and 13 HISTORICAL labels;
filtering solely on latest_record would lose 13 rows. Each selected facility ID
has one row in this sample. Effective-period semantics still need validation;
overlapping or unknown versions remain for conflict checks, not arbitrary ranking.

PVD's latest date is 30 September, **34 days old**, and stale under the configurable
30-day development freshness check. Native keys, currency and grain remain
unverified; 33 keys must not be labelled 33 validated facilities.

Original observations remain in the test's imported/ folder; current_inputs/ is
a separate derived view. No sums across dates, currencies or sources are made.
These counts cannot establish source-wide completeness.

## Signal results after the requested changes

| Signal | Local result | Remaining limitation |
| --- | --- | --- |
| SIG01 | Three RCF assessments show current=0, previous=0, change=0. | Both balances are explicitly imputed under the user's missing-drawn rule. They do not prove actual zero borrowing. Gap is one day; materiality, participation and FX rules remain open. |
| SIG02 | 25 Siemens creation-event candidates; selected dates range from 10 September 2020 to 4 May 2026. | No recent event established. Confirm creation/product/version meanings. Other clients have no Facilities rows in this export. |
| SIG06 CLO | Four current observations remain unavailable. | The configured numerator is missing; SIG01 zero imputation does not apply. |
| SIG06 DRR | 20 of 93 observations have usable arithmetic; 73 unavailable. One ratio is 94.28%, above the proposed 70%. | That row is FGTE/local GTE, not RVCF. Validate product eligibility and amount meanings; missing currencies, zero limits and negative amounts remain qualified. |
| SIG06 PVD / covenants | PVD ratios unavailable; no current client covenant evidence supplied. | Currency/grain/definitions and financial covenant measures/mappings remain unresolved. |
| SIG07 | All 25 selected Siemens rows retain limit_cat=CAT-A; PVD adds rating/category context. | Candidate advisory classification only; CAT codes do not yet establish an advisory engagement. |

No non-null business trigger flags are emitted by the default development run.
Candidate measures and raw threshold comparisons are retained where possible.
An unvalidated flag does not establish absence of client activity.

## Counterparty and next round

The corrected route is **delta.prod_party_gda.counterparty_core**. Run live schema
checks first; column/date/lifecycle semantics and equivalence to the previous
Delta path remain unverified. The new queries use target MG IDs OR observed
CIN/GID values, preserving contradictory/non-target mappings. Keep the latest
snapshot plus snapshots preceding the selected CLO dates.

Optional development associations fill a missing/invalid CLO group only from one
combined CIN/GID target group at the latest eligible per-key prior date. Valid
originals are preserved; latest state is selected before lifecycle filtering.
An older active mapping is not resurrected after a later inactive mapping.
The existing lifecycle settings remain unverified. Counterparty handoff keeps
all in-date reference rows so cohort filtering cannot hide contradictions.

Use the seven-source pack at `pvd_client_cohort_lab/sql_templates/current_20261103/`
and [CURRENT_WORKFLOW.md](../../pvd_client_cohort_lab/CURRENT_WORKFLOW.md).
Observed identifier routes are discovery, with explicit opt-in test associations
for local development. Covenant relationship namespaces are not automatically
approved. All attributes remain available this round; dates/versions control volume.

## Reproduce and verify

- `reproduce_client_test.py` stages supplied target records and runs local current
  selection, bounded test associations, coverage and signal tests.
  `client_input_manifest.json` records paths/hashes/scope counts.
- `client_current_test/current_selection.csv`, its cohort report and its signal
  evidence exports retain the calculations and lineage. The SQLite result passed
  its integrity check.
- `verify_generated_sql.py` executed all seven delivered SELECTs locally using
  SQLite DATE_PARSE/TRY adapters. Selection against real CLO/DRR/Facilities/PVD
  files matched expectations; old KYC/covenant samples returned no client matches.
  Counterparty used synthetic data including a contradictory group.
  `sql_validation.json` retains these results. The adapter does not verify live
  Trino schemas, permissions, partition pushdown or completeness.
- The inventory contains raw hashes for all 28 supplied CSV files. The source
  input hashes were checked again after processing; no original export changed.

Validation: **57 automated tests passed** (35 cohort/import/refresh and 22 signal-engine tests).
