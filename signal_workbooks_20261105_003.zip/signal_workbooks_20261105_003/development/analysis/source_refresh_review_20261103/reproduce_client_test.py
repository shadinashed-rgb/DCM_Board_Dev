"""Reproduce bounded current-view testing from the four supplied client exports.

The wider CSV inventory, including older unrelated samples and query errors,
is separate in export_inventory.csv. All original files remain read-only.
"""
import csv
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'pvd_client_cohort_lab'))
from refresh import read_csv, write_csv, process

TARGETS = {'MG001356', 'MG102229', 'MG101624'}
SOURCES = [
    ('clo', 'sql_sample_extract/04_name_candidates_clo.csv', 'rct_mastergroup_id'),
    ('pvd', 'sql_sample_extract/04_name_candidates_pvd_1-7_to_30_10.csv', 'joi_relationship_id'),
    ('facilities', 'sql/sql_samples/sample_dcm/facilities_cin_lookup.csv', None),
    ('drr', 'sql/sql_samples/drr_mastergroup_ids_sample.csv', 'drr_mastergroup_id'),
]


def main():
    incoming = OUT / 'client_exports'
    if incoming.exists():
        raise ValueError('Client staging output already exists; choose a new review folder')
    manifest = []
    for source, name, group_column in SOURCES:
        original = ROOT / name
        before = hashlib.sha256(original.read_bytes()).hexdigest()
        columns, rows = read_csv(original)
        selected = [r for r in rows if not group_column or r[group_column] in TARGETS]
        write_csv(incoming / (source + '.csv'), columns, selected)
        assert before == hashlib.sha256(original.read_bytes()).hexdigest()
        manifest.append(dict(source=source, input=name, sha256=before, raw_rows=len(rows), target_rows=len(selected)))
    (OUT / 'client_input_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    process(incoming, OUT / 'client_current_test', '2026-11-03', use_test_links=True)
    for item in manifest:
        assert item['sha256'] == hashlib.sha256((ROOT / item['input']).read_bytes()).hexdigest()
    print('Completed current client test; original input hashes unchanged.')


if __name__ == '__main__':
    main()
