"""Review the supplied Facilities/CIN files and exercise scoped local test links.

Run from any directory with Python 3.10+. Raw files and existing approvals are
read-only. Outputs must not already exist. No Starburst connection is made.
"""
import csv
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
LAB = ROOT / 'pvd_client_cohort_lab'
sys.path.insert(0, str(LAB))
import cohort
from import_exports import import_exports


def load(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        assert all(None not in row and None not in row.values() for row in rows), path
        return rows


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, columns, rows):
    with path.open('x', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def main():
    incoming = ROOT / 'sql/sql_samples/sample_dcm'
    review_path = incoming / 'identifier_review.csv'
    facilities_path = incoming / 'facilities_cin_lookup.csv'
    clo_path = ROOT / 'analysis/pvd_cohort_extracts_20261102/prepared_inputs/clo/part-001.csv'
    approval_path = LAB / 'inputs/facilities_test_links.csv'
    for path in [approval_path, OUT / 'imported', OUT / 'baseline', OUT / 'mapped',
                 OUT / 'cin_mapping_evidence.csv', OUT / 'checks.json', OUT / 'README.md']:
        if path.exists():
            raise ValueError(f'Output already exists: {path}')
    fingerprints = {str(p.relative_to(ROOT)): sha(p) for p in [review_path, facilities_path, clo_path]}
    review, facilities, clo = map(load, [review_path, facilities_path, clo_path])
    cin_counts = Counter(row['cin'] for row in facilities)
    assert facilities and all(row['run_date'] == '20261030' for row in facilities)
    assert all(row['source_system_name'] == 'cfc' and row['country_code'] == 'DE' for row in facilities)
    groups = defaultdict(set)
    for row in review:
        if row['proposed_type'] == 'CIN':
            groups[row['identifier_value']].add(row['mastergroup_id'])
    approvals, evidence = [], []
    for cin, count in sorted(cin_counts.items()):
        assert groups[cin] == {'MG102229'}, (cin, groups[cin])
        proposals = [r for r in review if r['identifier_value'] == cin
                     and r['origin_source'] == 'clo' and r['origin_column'] == 'obligor_cin'
                     and r['proposed_type'] == 'CIN']
        assert len(proposals) == 1, cin
        proposal = proposals[0]
        supporting = [r for r in clo if r['obligor_cin'] == cin]
        assert supporting and {r['rct_mastergroup_id'] for r in supporting} == {'MG102229'}
        assert any(cohort.day(r['run_date']) == '2026-10-30' for r in supporting)
        assert proposal['first_observed'] <= '2026-10-30' <= proposal['last_observed']
        row = dict(proposal)
        row.update(
            review_id='facilities-test-20261030-' + cin,
            approved_type='CIN', target_source='facilities', decision='approve',
            valid_from='2026-10-30', valid_to='2026-10-30',
            scope_json=json.dumps({'source_system_name': 'cfc', 'country_code': 'DE'}, sort_keys=True),
            evidence=(f'Development test link only. Supplied identifier_review.csv row '
                      f'{proposal["review_id"]} associates CLO obligor_cin={cin} with '
                      f'MG102229; independently checked {len(supporting)} stored CLO observations '
                      f'in analysis/pvd_cohort_extracts_20261102/prepared_inputs/clo/part-001.csv, '
                      f'including 2026-10-30. Facilities cin exactly equals this value. '
                      f'No competing group in supplied CIN review. Scope: facilities/cfc/DE, '
                      f'2026-10-30 only. Shared CIN meaning is a test assumption, not a '
                      f'production identity or historical legal-membership certification.'))
        approvals.append(row)
        evidence.append(dict(cin=cin, mastergroup_id='MG102229', facilities_rows=count,
                             stored_clo_rows=len(supporting), origin_review_id=proposal['review_id']))
    write(approval_path, cohort.REVIEW_COLUMNS, approvals)
    write(OUT / 'cin_mapping_evidence.csv', list(evidence[0]), evidence)
    cfg = cohort.config(LAB / 'config.json')
    links = cohort.read_approvals(approval_path, cfg)
    for row in facilities:
        assert cohort.classify('facilities', row, '2026-10-30', cfg, links)[0][0:2] == ('MG102229', 'matched')
        for col, value in [('country_code', 'GB'), ('source_system_name', 'another_system'), ('cin', 'UNSEEN_CIN')]:
            assert not cohort.classify('facilities', dict(row, **{col: value}), '2026-10-30', cfg, links)
        assert not cohort.classify('facilities', row, '2026-10-29', cfg, links)
        assert not cohort.classify('facilities', row, '2026-10-31', cfg, links)
    import_exports(incoming, OUT / 'imported')
    cohort.analyse(OUT / 'imported', OUT / 'baseline', '2026-11-02', LAB / 'config.json')
    cohort.analyse(OUT / 'imported', OUT / 'mapped', '2026-11-02', LAB / 'config.json', approval_path)
    before = [r for r in load(OUT / 'baseline/coverage.csv') if r['source'] == 'facilities']
    after = [r for r in load(OUT / 'mapped/coverage.csv') if r['source'] == 'facilities']
    assert sum(int(r['matched_rows']) for r in before) == 0
    assert sum(int(r['matched_rows']) for r in after) == len(facilities)
    assert all(int(r['matched_rows']) == 0 for r in after if r['mastergroup_id'] != 'MG102229')
    assert sum(int(r['conflict_rows']) for r in after) == 0
    assert all(sha(ROOT / name) == value for name, value in fingerprints.items())
    counts = dict(raw_rows=len(facilities), distinct_cins=len(cin_counts),
                  distinct_facility_ids=len({r['facility_id'] for r in facilities}),
                  exact_duplicate_rows=len(facilities) - len({tuple(r.items()) for r in facilities}),
                  latest_record_counts=dict(Counter(r['latest_record'] for r in facilities)),
                  open_end_date_rows=sum(r['record_end_dt'] == '99991231' for r in facilities),
                  source_files_sha256=fingerprints, matched_rows_after=349,
                  negative_scope_checks='other country/source/CIN and adjacent dates do not match')
    (OUT / 'checks.json').write_text(json.dumps(counts, indent=2) + '\n')
    (OUT / 'README.md').write_text('''# Facilities mapping review, 3 November 2026

The supplied Facilities export contains 349 distinct raw rows, seven CINs,
and 25 distinct facility IDs, all on run_date 20261030, source cfc, country DE.
Each CIN maps only to Siemens Energy (MG102229) in the supplied identifier review.
The stored earlier CLO export independently contains the same seven CINs with
explicit rct_mastergroup_id MG102229, including observations on 30 October.
This is a check against original CLO rows, not independent validation of the
underlying CLO group classification.

The development mapping file is
`pvd_client_cohort_lab/inputs/facilities_test_links.csv`.
Its seven links target Facilities only, restricted to cfc/DE and 30 October 2026.
The software decision `approve` enables this bounded local test. Exact CIN equality
across these sources remains a test assumption; this is not a production identity
approval, proof of legal membership, or permission to expand the mapping to all
dates/countries/sources. No PVD, GID, relationship or facility-ID approvals were added.
Existing approval files and all raw supplied files remain unchanged.

The unchanged cohort analyser was run before and after applying these links:
0 matched Facilities rows before; 349 for Siemens Energy after, zero for the other
two groups, no conflicts. Negative checks rejected other source/country/CIN values
and adjacent observation dates. The local test includes only the supplied Facilities
export; other sources show missing_file here because they were not supplied for
this test. Rerun against the complete imported/round_003 folder on the extraction
machine to retain the other sources' coverage. See mapped/REPORT.md and checks.json.

## Interpretation limits

- 349 rows are not 349 facilities. All 25 scoped facility IDs repeat within this
  single run_date; there are no exact duplicate rows. Preserve versions at landing.
- latest_record has 337 HISTORICAL and 12 CURRENT rows, while 25 rows have
  record_end_dt 99991231 (13 HISTORICAL and 12 CURRENT). Do not select current
  versions using either field until the validity/lifecycle rules are confirmed.
- active_facility_ind contains 20260602 on 204 rows and blanks on 145, so its
  meaning/type needs checking before it is treated as an active/inactive flag.
- Vodafone and SoftBank are absent from this Facilities export. This does not
  establish that they have no facilities in the underlying system.
- The supplied files contain no KYC records; this review does not resolve KYC
  source coverage. PVD mappings remain pending.
- Group matching does not validate balances, rating meanings or SIG02/SIG07
  triggers. Version selection and source-field definitions remain to be tested.

## Next command on the extraction machine

Place the mapping file in the package inputs folder, then run from inside
`pvd_client_cohort_lab` (choose a fresh output name if round_004 already exists):

```sh
python3 cohort.py analyse \\
  --input imported/round_003 \\
  --approved inputs/facilities_test_links.csv \\
  --as-of 2026-11-02 \\
  --out runs/round_004
```

Review runs/round_004/REPORT.md. With the same six input exports, expected
Facilities coverage is Siemens Energy matched 349, Vodafone and SoftBank
no_matches_in_supplied_export. These links do not change PVD or KYC coverage.
''')
    print(json.dumps({k: v for k, v in counts.items() if k != 'source_files_sha256'}, indent=2))
    print('Mapping file:', approval_path)


if __name__ == '__main__':
    main()
