# Facilities mapping review, 3 November 2026

The supplied Facilities export contains 349 distinct raw rows, seven CINs,
and 25 distinct facility IDs, all on run_date 20261030, source cfc, country DE.
Each CIN maps only to Siemens Energy (MG102229) in the supplied identifier review.
The stored earlier CLO export independently contains the same seven CINs with
explicit rct_mastergroup_id MG102229, including observations on 30 October.
This is a check against original CLO rows, not independent validation of the
underlying CLO group classification.

The development mapping file is
`pvd_client_cohort_lab/inputs/facilities_test_links.csv`.
Its seven links target Facilities only, restricted to cfc/DE and 30 October 2026.
The software decision `approve` enables this bounded local test. Exact CIN equality
across these sources remains a test assumption; this is not a production identity
approval, proof of legal membership, or permission to expand the mapping to all
dates/countries/sources. No PVD, GID, relationship or facility-ID approvals were added.
Existing approval files and all raw supplied files remain unchanged.

The unchanged cohort analyser was run before and after applying these links:
0 matched Facilities rows before; 349 for Siemens Energy after, zero for the other
two groups, no conflicts. Negative checks rejected other source/country/CIN values
and adjacent observation dates. The local test includes only the supplied Facilities
export; other sources show missing_file here because they were not supplied for
this test. Rerun against the complete imported/round_003 folder on the extraction
machine to retain the other sources' coverage. See mapped/REPORT.md and checks.json.

## Interpretation limits

- 349 rows are not 349 facilities. All 25 scoped facility IDs repeat within this
  single run_date; there are no exact duplicate rows. Preserve versions at landing.
- latest_record has 337 HISTORICAL and 12 CURRENT rows, while 25 rows have
  record_end_dt 99991231 (13 HISTORICAL and 12 CURRENT). Do not select current
  versions using either field until the validity/lifecycle rules are confirmed.
- active_facility_ind contains 20260602 on 204 rows and blanks on 145, so its
  meaning/type needs checking before it is treated as an active/inactive flag.
- Vodafone and SoftBank are absent from this Facilities export. This does not
  establish that they have no facilities in the underlying system.
- The supplied files contain no KYC records; this review does not resolve KYC
  source coverage. PVD mappings remain pending.
- Group matching does not validate balances, rating meanings or SIG02/SIG07
  triggers. Version selection and source-field definitions remain to be tested.

## Next command on the extraction machine

Place the mapping file in the package inputs folder, then run from inside
`pvd_client_cohort_lab` (choose a fresh output name if round_004 already exists):

```sh
python3 cohort.py analyse \
  --input imported/round_003 \
  --approved inputs/facilities_test_links.csv \
  --as-of 2026-11-02 \
  --out runs/round_004
```

Review runs/round_004/REPORT.md. With the same six input exports, expected
Facilities coverage is Siemens Energy matched 349, Vodafone and SoftBank
no_matches_in_supplied_export. These links do not change PVD or KYC coverage.
