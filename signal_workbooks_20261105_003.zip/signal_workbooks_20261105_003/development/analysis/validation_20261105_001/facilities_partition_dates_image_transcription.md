# Facilities partition-date image transcription — 5 November 2026

CSV: `data/validation_20261105_001/facilities_partition_dates.csv`

Provenance: manually transcribed from the seven visible result rows in the user-supplied image in this conversation, at the user's request. This is a derived transcription, not the original Starburst download. The image itself has not been saved as a local artifact.

Headers were restored from `analysis/dcm_run_003_review_20261103/next_checks/01_facilities_partition_dates.sql` because the image truncates/overlaps header labels. All seven visible rows show source `cfc`, country `DE` and `run_date=20261103`. CIN values are written as exact text strings without numeric conversion.

Checks: CSV round-trip matches the transcribed header and seven rows. The `raw_rows` values total 349. Per-CIN distinct facility-ID counts must not be treated as a deduplicated cross-CIN total. No engine ingestion or current-record selection change was performed.

Expected query: the existing profile query for candidate CINs over 1 October–3 November 2026. The exact submitted SQL, source export time, query execution time, download row cap and overall result completeness are unconfirmed. No error is visible in the image; this does not establish that the underlying extraction had no errors. Transcription remains subject to reconciliation against the original CSV if supplied later.

CSV SHA-256: `171f7fb07cc49df1f1de1df88e2ada3cf179f809c8dcd594515093ef1016da49`
