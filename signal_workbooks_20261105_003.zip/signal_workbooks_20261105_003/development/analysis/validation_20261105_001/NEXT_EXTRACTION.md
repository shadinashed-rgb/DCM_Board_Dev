# Targeted Facilities DE follow-up — 5 November 2026

**Deferred at the user's request on 5 November 2026.** Continue with existing-evidence validation in `runs/validation_20261105_001/`. The query below remains an optional unresolved extraction; it has not been run locally and no new DE source data was ingested.

Run `02_facilities_siemens_de_20261103.sql` manually in Starburst and save the original CSV to `data/validation_20261105_001/facilities_siemens_de_20261103.csv`. Retain headers even for an empty result. Preserve identifiers as text; do not resave the download through Excel. If Starburst returns an error, keep it as an error artifact in this evidence folder rather than disguising it as source data.

The supplied image profile shows seven CFC/DE/CIN partitions at 3 November, with 349 raw rows. The archived DE export at 30 October has exactly the same per-CIN counts. Equal counts do not establish equal records, versions, products, amounts or dates. The selected current Facilities export separately contains 105 GB/AE rows dated 2 November. A current profile returning DE only does not prove that GB/AE data is absent from the full source.

This query captures all rows at the observed DE snapshot without imposing period/current-status/deduplication rules. The source/country publishing model and reason for the previous omission remain unverified. The latest combined 626-row evidence run is unchanged.

Store the exact SQL actually submitted here with export notes recording: source table, fixed source date (3 November 2026), CFC/DE/seven-CIN scope, execution/export time and timezone, download row-limit setting, returned row count and errors. The existing partition profile is image-transcribed evidence, not a native CSV download.

After transfer, reconcile headers, raw/per-CIN counts, strings, versions and amounts against the image-derived profile and the original 30 October export. Review facility/product/borrower grains before deriving effective/current records or considering an engine change. Keep the GB/AE export as a separate snapshot; do not blindly concatenate all three files. This validation folder contains both aggregate profile and source data, so it must not be passed directly to the generic multi-source refresh.
