"""Validate existing Bond Radar evidence locally; never approves business triggers."""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        if len(reader.fieldnames) != len(set(reader.fieldnames)) or any(None in r or None in r.values() for r in rows):
            raise ValueError(f'Malformed CSV: {path}')
        return reader.fieldnames, rows


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def day(value):
    if value == '99991231':
        return date.max
    if '-' in value:
        return date.fromisoformat(value[:10])
    return date(int(value[:4]), int(value[4:6]), int(value[6:8]))


def save(path, rows):
    with path.open('x', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def validate(output):
    if output.exists():
        raise ValueError('Use a fresh --out directory')
    fields, rows = read(EVIDENCE)
    paths = [EVIDENCE, ROOT / 'results/ALL_SIGNALS_WITH_CRR.csv',
             ROOT / 'analysis/dcm_run_003_review_20261103/DCM_Run_003_All_Signal_Evidence.csv',
             ROOT / 'REFERENCE_EXPECTATIONS.json', ROOT / 'runs/reference_002/RUN_SUMMARY.json',
             ROOT / 'runs/crr_full_001/manifest.json']
    raw_paths = list((ROOT / 'data/current_exports').glob('*.csv')) + list((ROOT / 'data/application_ratings_full').glob('*.csv'))
    paths += raw_paths
    original_hashes = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    raw = {p.name: read(p)[1] for p in raw_paths}
    checks = []

    def check(name, passed, scope):
        checks.append(dict(check=name, status='PASS' if passed else 'FAIL', scope=scope))

    def trace(text):
        result = []
        for ref in text.split(' | '):
            match = re.fullmatch(r'([^:]+):record (\d+)', ref)
            if not match:
                raise ValueError(f'Invalid lineage reference: {ref}')
            filename, number = match[1], int(match[2])
            if filename not in raw or not 2 <= number <= len(raw[filename]) + 1:
                raise ValueError(f'Unresolvable lineage: {ref}')
            result.append(raw[filename][number - 2])
        return result

    check('Unique evidence identifiers', len(rows) == len({r['evidence_id'] for r in rows}) == 626, 'All combined rows')
    check('Targets and excluded signals', {r['mastergroup_id'] for r in rows} == {'MG001356','MG102229','MG101624'}
          and not any(r['signal_id']=='SIG05' for r in rows), 'All combined rows; identity approvals are not inferred')
    check('No confirmed business triggers', all(not r['business_trigger'] for r in rows), 'All combined rows')
    linked = {r['evidence_id']: trace(r['source_record_references']) for r in rows}
    for r in rows:
        if r['previous_source_record_references']:
            trace(r['previous_source_record_references'])
    check('Source record references resolve', len(linked)==626, 'Every current and supplied previous reference; this is not proof of entity membership')
    base_fields, base = read(paths[2])
    core = {r['evidence_id']: r for r in rows if r['source']!='application_ratings'}
    check('Core fields preserved', len(core)==len(base)==604 and all(
        r['evidence_id'] in core and all(core[r['evidence_id']][k]==r[k] for k in base_fields) for r in base), 'Every original core field')
    expected = json.loads((ROOT / 'REFERENCE_EXPECTATIONS.json').read_text())
    check('Reference input hashes unchanged', all(sha(ROOT / p)==h for p,h in expected['input_sha256'].items()), 'All selected reference inputs')
    reference = json.loads((ROOT / 'runs/reference_002/RUN_SUMMARY.json').read_text())
    check('Existing reference controls', reference['reference_verified'] and reference['counts']==expected['counts'],
          'Reuse reference_002 with matching input hashes; no source/engine logic changed')

    utilisation = [r for r in rows if r['component']=='utilisation' and r['metric_value']]
    util_review = []
    for r in utilisation:
        sources = linked[r['evidence_id']]
        ratio = Decimal(r['utilisation_amount']) / Decimal(r['approved_limit']) * 100
        check('Utilisation arithmetic '+r['evidence_id'], Decimal(r['metric_value'])==ratio
              and (r['above_70_for_testing']=='True')==(ratio>70), 'Source-specific numerator/denominator; strict >70')
        check('Utilisation raw values '+r['evidence_id'], all(
            Decimal(s['utilisation'])==Decimal(r['utilisation_amount']) and Decimal(s['approved_limit'])==Decimal(r['approved_limit'])
            and s['approved_limit_ccy']==s['utilisation_ccy']==r['currency'] and day(s['reporting_date']).isoformat()==r['observation_date']
            for s in sources), 'Every linked DRR row; units/share interpretation remains unverified')
        if r['above_70_for_testing']!='True':
            continue
        first=sources[0]
        questions = ['Confirm product eligibility, numerator/denominator units and participation scope; >70% is a development threshold.']
        if first['unconditionally_cancellable']=='Y':
            questions.append('Confirm eligibility and interpretation of unconditionally_cancellable=Y alongside committed_flag=Y.')
        if first['facility_as_parent'] not in ('','N'):
            questions.append('Define facility_as_parent='+first['facility_as_parent']+' and exposure hierarchy; do not sum parent/child limits.')
        util_review.append(dict(client=r['client'], drr_uid=r['drr_uids'], product_code=r['product_codes'],
            approved_limit=r['approved_limit'], utilisation=r['utilisation_amount'], currency_label=r['currency'],
            recomputed_percent=str(ratio), reporting_date=r['observation_date'],
            committed_flag=first['committed_flag'], unconditionally_cancellable=first['unconditionally_cancellable'],
            facility_as_parent=first['facility_as_parent'], facility_as_child=first['facility_as_child'],
            shared_facility_flag=first['shared_facility_flag'], raw_limit_lcy=first['approved_limit_lcy'], raw_utilisation_lcy=first['utilisation_lcy'],
            arithmetic_status='PASS', business_eligibility='UNVERIFIED', owner_question=' '.join(questions),
            evidence_id=r['evidence_id'], source_record_references=r['source_record_references']))
    check('Utilisation counts', len(utilisation)==57 and len(util_review)==5, '57 usable DRR ratios; five arithmetic candidates')
    check('Unavailable ratios remain blank', all(not r['metric_value'] and r['above_70_for_testing']!='True'
          for r in rows if r['component']=='utilisation' and r['assessment_status']=='unavailable'), '385 unavailable utilisation contexts across sources')

    creation = [r for r in rows if r['signal_id']=='SIG02']
    creation_review=[]
    for r in creation:
        if r['assessment_status']=='unavailable':
            check('Ambiguous creation withheld '+r['evidence_id'], not r['event_date'] and r['recent_creation_for_testing']!='True', 'Ambiguous product/date context')
            continue
        age=(day(r['assessment_date'])-day(r['event_date'])).days
        sources=linked[r['evidence_id']]
        key=json.loads(r['record_key'])
        all_context=[s for s in raw['facilities_current.csv'] if [s['source_system_name'].upper(),s['country_code'].upper(),s['facility_id']]==key]
        check('Creation date and age '+r['evidence_id'], age==int(r['event_age_days']) and all(day(s['facility_creation_date']).isoformat()==r['event_date'] for s in sources)
              and (r['recent_creation_for_testing']=='True')==(0<=age<=int(r['event_lookback_days'])), 'Saved assessment date and development lookback; does not establish signing')
        check('Creation context uniqueness '+r['evidence_id'], len({s['product_code'] for s in all_context})==1
              and len({s['facility_creation_date'] for s in all_context})==1, 'Source/country/facility scope; borrower associations kept')
        if r['recent_creation_for_testing']=='True':
            first=sources[0]
            creation_review.append(dict(client=r['client'], facility_id=r['facility_ids'], product_code=r['product_codes'],
                creation_date=r['event_date'], assessment_date=r['assessment_date'], age_days=age, test_lookback_days=r['event_lookback_days'],
                proposed_limit=r['proposed_limit'], currency=r['currency'], source_rows=len(all_context),
                commitment_ind=first['commitment_ind'], unconditional_cancel_ind=first['unconditional_cancel_ind'],
                arithmetic_status='PASS', business_eligibility='UNVERIFIED',
                owner_question='Confirm facility_creation_date means signing/new financing rather than amendment, migration or administration; define product, commitment/cancellation flags and amount scope. Validate CIN membership.',
                evidence_id=r['evidence_id'], source_record_references=r['source_record_references']))
    check('Creation counts', len(creation)==63 and len(creation_review)==8 and sum(r['assessment_status']=='unavailable' for r in creation)==13,
          '50 usable contexts, 13 withheld, eight recent under original 90-day test')

    crr=[r for r in rows if r['source']=='application_ratings']
    crr_review=[]
    expected_crr_refs=set()
    for filename, records in raw.items():
        if not filename.startswith('application_ratings_'):
            continue
        check('CRR single source snapshot '+filename, {r['run_date'] for r in records}=={'20261103'}, 'Independent period reconciliation is bounded to this one supplied snapshot')
        expected_crr_refs.update(f'{filename}:record {i}' for i,r in enumerate(records,2)
                                if day(r['record_start_dt'])<=day(r['run_date'])<=day(r['record_end_dt']))
    check('CRR period selection reconciles', {r['source_record_references'] for r in crr}==expected_crr_refs and len(crr)==len(expected_crr_refs)==22,
          'All 722 raw application rows; selection evaluated at source snapshot, not validation date')
    for r in crr:
        source=linked[r['evidence_id']][0]
        placeholder=source['final_crr'].strip().upper() in ('','N/A')
        peers={p['crr'] for p in crr if p['crr'] and all(p[k]==r[k] for k in ['mastergroup_id','source_countries','cins'])}
        check('CRR raw state '+r['evidence_id'], r['crr_raw']==source['final_crr'].strip()
              and r['crr']==('' if placeholder else source['final_crr'].strip()) and r['crr_scale']==source['crr_scale']
              and r['multiple_crrs_for_cin']==str(len(peers)>1)
              and all(r[k]==source[k].strip() for k in ['previous_crr','proposed_crr','approved_crr','proposed_manual_crr','overriden_crr']),
              'Raw categorical values preserved; no fallback or numeric direction')
        questions=['Define CRR scale, version flags, application periods and any advisory trigger; validate candidate CIN membership.']
        if r['latest_record']=='HISTORICAL':
            questions.append('Confirm HISTORICAL application with open period/latest-approved flag is eligible context.')
        if len(peers)>1:
            questions.append('Resolve competing CRRs without MAX, averaging or numeric-direction assumptions.')
        if placeholder:
            questions.append('Final CRR is unavailable; retain raw blank/N/A without fallback.')
        crr_review.append(dict(client=r['client'], cin=r['cins'], application_serial=r['credit_proposal_serial_no'],
            final_crr_raw=r['crr_raw'], displayed_crr=r['crr'], scale=r['crr_scale'], latest_record=r['latest_record'],
            multiple_crrs_for_cin=r['multiple_crrs_for_cin'], local_check='PASS', business_eligibility='UNVERIFIED',
            owner_question=' '.join(questions), evidence_id=r['evidence_id'], source_record_references=r['source_record_references']))
    check('CRR counts', len(crr)==22 and sum(bool(r['crr']) for r in crr)==18 and sum(not r['crr'] for r in crr)==4, '18 populated, four unavailable')

    sig01=[r for r in rows if r['signal_id']=='SIG01']
    check('SIG01 zero policy retained', len(sig01)==3 and all(r['current_drawn_imputed_zero']==r['previous_drawn_imputed_zero']=='True'
          and Decimal(r['current_drawn'])==Decimal(r['previous_drawn'])==Decimal(r['metric_value'])==0 for r in sig01), 'Three flagged imputed comparisons; not observed zero drawings')
    check('SIG01 raw missing and dates', all(all(not s.get('facility_drawn_amount','').strip() for s in linked[r['evidence_id']]+trace(r['previous_source_record_references']))
          and (day(r['observation_date'])-day(r['previous_observation_date'])).days==int(r['comparison_gap_days']) for r in sig01), 'Current/prior missing values and actual comparison gap')
    check('No imputation outside SIG01', all(r['current_drawn_imputed_zero']!='True' and r['previous_drawn_imputed_zero']!='True'
          for r in rows if r['signal_id']!='SIG01'), 'No propagation to utilisation or CRR')
    manifest=json.loads((ROOT/'runs/crr_full_001/manifest.json').read_text())
    check('Full CRR inputs match saved hashes', all(sha(Path(p))==h for p,h in manifest['input_sha256'].items()), 'Base, CIN inventory and uploaded full files')
    check('Inputs unchanged during validation', all(sha(ROOT/p)==h for p,h in original_hashes.items()), 'Raw, prior outputs, metadata and reference inputs')
    summary=dict(validation_date='2026-11-05', dataset_as_of='Original core 2026-11-03; CRR assessment 2026-11-04; no dates rebased',
        readiness='Share with caveats: development evidence only; business eligibility remains unverified',
        checks=dict(Counter(c['status'] for c in checks)), rows=626, usable_utilisation_ratios=57, high_utilisation_candidates=5,
        recent_creation_candidates=8, application_crr_contexts=22, populated_crr=18, unavailable_crr=4,
        by_signal=dict(Counter(r['signal_id'] for r in rows)), deferred='Additional DE extraction deferred at user request; publishing/current-selection completeness remains unresolved',
        owner_validation='Product eligibility, amount units/share and hierarchy, creation-event semantics, CRR scale/version rules, reviewed identity mappings and business triggers',
        gaps='SIG03 enquiries unidentified; target KYC export empty; genuine financial covenants missing; PVD dated 2026-09-30',
        input_sha256=original_hashes)
    output.mkdir(parents=True)
    save(output/'CHECKS.csv',checks)
    save(output/'SIG06_OWNER_REVIEW.csv',util_review)
    save(output/'SIG02_OWNER_REVIEW.csv',creation_review)
    save(output/'SIG07_CRR_OWNER_REVIEW.csv',crr_review)
    (output/'VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='input_sha256'},indent=2))
    if any(c['status']=='FAIL' for c in checks):
        raise SystemExit('Validation found failed local checks; inspect CHECKS.csv')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    validate(ROOT / args.out)
