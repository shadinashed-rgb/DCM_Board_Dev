-- READ ONLY. Copy/run manually in Starburst.
-- Save the original download as:
-- data/validation_20261105_001/facilities_siemens_de_20261103.csv
-- Targeted follow-up to the user image transcribed into facilities_partition_dates.csv.
-- Candidate CIN scope only; not approval of mastergroup identity or historical membership.
-- Retain ALL rows/versions/products/borrower associations at this exact snapshot.
-- No DISTINCT, latest_record, effective-period filter, aggregation or row limit.
-- The image profile suggests 349 raw rows: 3/23/33/9/249/24/8 by CIN below.
-- Reconcile differences; do not force the result to the expected count.
SELECT t.*
FROM "delta"."prod_credit_and_lending_gda"."facilities_limits" t
WHERE t."run_date" = '20261103'
  AND UPPER(TRIM(CAST(t."source_system_name" AS VARCHAR))) = 'CFC'
  AND UPPER(TRIM(CAST(t."country_code" AS VARCHAR))) = 'DE'
  AND UPPER(TRIM(CAST(t."cin" AS VARCHAR))) IN (
    '2020052909382',
    '2020052910083',
    '2020052910221',
    '2020061913563',
    '2020120111381',
    '2021072908540',
    'DE54009015791'
  )
ORDER BY t."cin", t."facility_id", t."record_start_dt", t."record_end_dt";
