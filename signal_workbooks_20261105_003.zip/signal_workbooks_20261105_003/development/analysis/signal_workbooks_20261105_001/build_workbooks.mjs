import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile, FileBlob } from '@oai/artifact-tool';

const plan=process.argv[2]==='--format-existing'?null:JSON.parse(await fs.readFile(process.argv[2],'utf8'));
const output=process.argv[3];
const previews=path.join(output,'previews');
await fs.mkdir(previews,{recursive:true});
const font='Arial';
const checks=[];
const sheetRegistry=new WeakMap();
let tableCount=0;
function allocate(wb,names=[]){
 if(!sheetRegistry.has(wb))sheetRegistry.set(wb,new Map());
 const map=sheetRegistry.get(wb);
 for(const name of names)if(!map.has(name))map.set(name,wb.worksheets.add(name));
 return map;
}
const chars=index=>{let out='';for(let n=index+1;n;n=Math.floor((n-1)/26))out=String.fromCharCode(65+(n-1)%26)+out;return out;};
const numeric=new Set(['current_drawn','previous_drawn','utilisation_amount','approved_limit','proposed_limit','event_age_days','event_lookback_days','comparison_gap_days']);

function baseSheet(wb,name,title,description){
 const sheets=allocate(wb,[name]);
 const sheet=sheets.get(name);
 sheet.showGridLines=false;
 sheet.getRange('A1:L25').format.font={name:font,size:10,color:'#20252B'};
 sheet.getRange('A2').values=[[title]];
 sheet.getRange('A2').format.font={name:font,size:14,bold:true,color:'#20252B'};
 sheet.getRange('A2:L2').format.rowHeight=25;
 sheet.getRange('A3').values=[[description]];
 sheet.getRange('A3:L3').format.rowHeight=22;
 return sheet;
}

function addTable(wb,name,title,headers,data,description,source='',role='detail'){
 const sheet=baseSheet(wb,name,title,description);
 if(source)sheet.getRange('A4').values=[[source]];
 const cols=headers.length, rows=data.length;
 const range=sheet.getRangeByIndexes(5,0,Math.max(1,rows+1),cols);
 range.setNumberFormat('@');
 range.format.font={name:font,size:10,color:'#20252B'};
 range.format.columnWidth=23;
 range.format.verticalAlignment='center';
 range.format.rowHeight=30;
 sheet.getRangeByIndexes(5,0,1,cols).values=[headers];
 for(let start=0;start<rows;start+=128){
  const block=data.slice(start,start+128);
  sheet.getRangeByIndexes(6+start,0,block.length,cols).values=block;
 }
 const head=sheet.getRangeByIndexes(5,0,1,cols);
 head.format={fill:'#343A40',font:{name:font,size:10,bold:true,color:'#FFFFFF'},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center',rowHeight:48};
 if(rows){
  sheet.tables.add(`A6:${chars(cols-1)}${rows+6}`,true,'Table'+(++tableCount));
  // Preserve deliberately chosen header contrast independently of table defaults.
  head.format.fill='#343A40';head.format.font.color='#FFFFFF';
 }
 for(let col=0;col<cols;col++){
  const header=headers[col];
  const key=header.toLowerCase().replaceAll(' ','_');
  const width=/evidence_id|record_key|references|source_file|source_table|source_reference|raw_reference|csv_file/.test(key)?72:
    /definition|finding|action|question|description|reason|row_note|summary_text|^role$/.test(key)?72:
    /name|client|source|component|status|usage|topic/.test(key)?30:23;
  const column=sheet.getRangeByIndexes(5,col,Math.max(1,rows+1),1);
  column.format.columnWidth=width;
  if(role==='narrative' || /reason|definition|finding|action|question|description|row_note|summary_text|source_file|source_table|^role$/.test(key))column.format.wrapText=true;
 }
 if(role==='narrative' && rows)sheet.getRangeByIndexes(6,0,rows,cols).format.rowHeight=78;
 if(name==='Sources' && rows)sheet.getRangeByIndexes(6,0,rows,cols).format.rowHeight=48;
 if(rows>8)sheet.freezePanes.freezeRows(6);
 if(cols>8)sheet.freezePanes.freezeColumns(2);
 const saved=sheet.getRangeByIndexes(5,0,rows+1,cols).values;
 const original=[headers,...data];
 for(let i=0;i<original.length;i++)for(let j=0;j<cols;j++){
  const actual=saved[i][j]===null || saved[i][j]===undefined?'':String(saved[i][j]);
  if(actual!==String(original[i][j]??''))throw new Error(`Value changed: ${name} row ${i+6}, column ${headers[j]}`);
 }
 return sheet;
}

function colRange(headers,field,n){return `'Evidence detail'!$${chars(headers.indexOf(field))}$7:$${chars(headers.indexOf(field))}$${Math.max(7,n+6)}`;}
function createSummary(wb,item){
 const sheet=baseSheet(wb,'Summary',item.signal+' — '+item.title,'Development evidence. Business triggers remain unverified.');
 sheet.tabColor='#343A40';
 sheet.getRange('A4').values=[['Core assessment: 3 Nov 2026. CRR assessment: 4 Nov 2026. Export: 5 Nov 2026.']];
 sheet.getRange('A5').values=[['Evidence records']];
 sheet.getRange('B5').formulas=[['=COUNTA('+colRange(item.evidenceHeaders,'evidence_id',item.evidenceData.length)+')']];
 sheet.getRange('A5:B5').format.font={name:font,size:12,bold:true,color:'#20252B'};
 const header=['Client','Mastergroup','Evidence records','Needs validation','Unavailable evidence','>70% test','Recent creation test','Populated CRR'];
 sheet.getRange('A9:H9').values=[header];
 sheet.getRange('A9:H9').format={fill:'#343A40',font:{name:font,size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:36,horizontalAlignment:'center',verticalAlignment:'center'};
 const groups=[['VODAFONE','MG001356'],['Siemens Energy','MG102229'],['SOFTBANK','MG101624']];
 const ranges=field=>colRange(item.evidenceHeaders,field,item.evidenceData.length);
 for(let i=0;i<groups.length;i++){
  const row=i+10;sheet.getRange(`A${row}:B${row}`).values=[groups[i]];
  sheet.getRange(`C${row}:H${row}`).formulas=[[
   `=COUNTIF(${ranges('mastergroup_id')},B${row})`,
   `=COUNTIFS(${ranges('mastergroup_id')},B${row},${ranges('assessment_status')},"needs_validation")`,
   `=COUNTIFS(${ranges('mastergroup_id')},B${row},${ranges('assessment_status')},"unavailable")`,
   `=COUNTIFS(${ranges('mastergroup_id')},B${row},${ranges('above_70_for_testing')},"True")`,
   `=COUNTIFS(${ranges('mastergroup_id')},B${row},${ranges('recent_creation_for_testing')},"True")`,
   `=COUNTIFS(${ranges('mastergroup_id')},B${row},${ranges('source')},"application_ratings",${ranges('assessment_status')},"needs_validation")`]];
 }
 sheet.getRange('A9:H12').format.columnWidth=22;
 sheet.getRange('A10:H12').format.rowHeight=26;
 sheet.getRange('C10:H12').setNumberFormat('#,##0');
 const notes=item.signal==='SIG03'?['No enquiry/pricing source supplied. Zero evidence is not proof of no activity.']:
  item.signal==='SIG04'?['KYC export is empty. Raw KYC retains the supplied column headers.']:
  item.signal==='SIG01'?['All three comparisons use flagged current/prior zero-imputation. Raw blanks remain blank.']:
  item.signal==='SIG06'?['Five ratios exceed the test threshold. Product, units and scope remain unverified.','Financial covenants are missing. Utilisation is not a covenant-breach test.']:
  item.signal==='SIG07'?['18 populated and four unavailable CRRs. Existing Facilities/PVD context remains separate.','Keep competing Siemens applications and HISTORICAL/open-period candidates.']:
  ['Eight recent-date candidates. Confirm signing/event and product meaning.','DE history is a separate archived snapshot. Additional extraction is deferred.'];
 notes.push('Signal data is the compact view. Evidence detail preserves original fields.');
 notes.push('Raw sheets preserve native fields. Lineage connects raw records to evidence.');
 notes.forEach((text,index)=>sheet.getRange('A'+(15+index)).values=[[text]]);
 return sheet;
}

async function finish(wb,filename,expected){
 wb.recalculate();
 const bookChecks=[];
 for(const sheet of allocate(wb).values()){
  const inspection=await wb.inspect({kind:'table',range:`'${sheet.name}'!A1:F12`,tableMaxRows:12,tableMaxCols:6,maxChars:1600});
  const imagePath=filename.replace('.xlsx','')+'__'+sheet.name.replaceAll(' ','_')+'.png';
  const reusable=process.env.BOND_RADAR_PREVIEWS_FROM && sheet.name!=='Signal data';
  if(reusable){
   await fs.copyFile(path.join(process.env.BOND_RADAR_PREVIEWS_FROM,imagePath),path.join(previews,imagePath));
  }else{
   const image=await wb.render({sheetName:sheet.name,range:sheet.name==='Summary'?'A1:H21':'A1:F12',scale:1,format:'png'});
   await fs.writeFile(path.join(previews,imagePath),new Uint8Array(await image.arrayBuffer()));
  }
  bookChecks.push({sheet:sheet.name,preview:imagePath,inspection:inspection.ndjson});
 }
 const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},maxChars:2000});
 const summary=wb.worksheets.getItem('Summary');
 if(expected!==null){
  const actual=Number(summary.getRange('B5').values[0][0]);
  if(actual!==expected)throw new Error('Summary evidence count mismatch '+filename+': '+actual+' != '+expected);
 }
 const file=await SpreadsheetFile.exportXlsx(wb);
 await file.save(path.join(output,filename));
 checks.push({file:filename,evidenceRows:expected,sheets:bookChecks,errorInspection:errors.ndjson,status:'PASS: source cells checked, counts reconciled, previews rendered; saved XLSX checked separately'});
 console.log(filename+': '+allocate(wb).size+' sheets');
}

if(!plan){
 for(const signal of ['SIG01','SIG02','SIG03','SIG04','SIG06','SIG07']){
  const filePath=path.join(output,signal+'.xlsx');
  const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(filePath));
  const sheet=wb.worksheets.getItem('Signal data');
  const all=sheet.getRange('A6:CV6').values[0];
  const headers=[];for(const h of all){if(!h)break;headers.push(String(h));}
  // Worksheet text output must display literal identifiers, including leading zeros.
  const rows=Number(wb.worksheets.getItem('Summary').getRange('B5').values[0][0]);
  if(rows){
   sheet.getRangeByIndexes(6,0,rows,headers.length).setNumberFormat('@');
   headers.forEach((field,col)=>{
    if(numeric.has(field) || field==='metric_value' && signal!=='SIG07')sheet.getRangeByIndexes(6,col,rows,1).setNumberFormat(/days/.test(field)?'#,##0':'#,##0.00');
   });
  }
  wb.recalculate();
  const preview=await wb.render({sheetName:'Signal data',range:'A1:F12',scale:1,format:'png'});
  await fs.writeFile(path.join(previews,signal+'__Signal_data.png'),new Uint8Array(await preview.arrayBuffer()));
  const blob=await SpreadsheetFile.exportXlsx(wb);
  const temporary=filePath+'.formatting.tmp.xlsx';await blob.save(temporary);await fs.rename(temporary,filePath);
  console.log(signal+': identifier display formatting verified');
 }
 process.exit(0);
}

for(const item of plan.signals){
 const wb=Workbook.create();
 allocate(wb,['Summary','Signal data','Definitions','Findings','Sources',
  ...(item.ownerReview?['Owner review']:[]),...(item.coverage.length?['Coverage']:[]),
  'Lineage','Evidence detail',...item.raw.map(r=>r.name)]);
 createSummary(wb,item);
 // These source values are literal strings, retaining original IDs, CRRs and placeholders.
 const detail=addTable(wb,'Evidence detail',item.signal+' original evidence',item.evidenceHeaders,item.evidenceData,
  'Original evidence fields and values. No new trigger or assessment date.','Source: development/runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv');
 // Create the compact view first in the logical navigation; underlying source remains authoritative.
 const view=addTable(wb,'Signal data',item.signal+' signal data',item.mainHeaders,[],
  'Compact view linked to Evidence detail. Categorical CRRs remain text.');
 const headers=item.evidenceHeaders;
 if(item.evidenceData.length){
  const formulas=item.evidenceData.map((record,index)=>item.mainHeaders.map(field=>{
   const ref=`'Evidence detail'!${chars(headers.indexOf(field))}${index+7}`;
   const useNumber=numeric.has(field) || field==='metric_value' && item.signal!=='SIG07';
   return `=IF(LEN(${ref})=0,"",${useNumber?'VALUE('+ref+')':ref})`;
  }));
  view.getRangeByIndexes(6,0,formulas.length,item.mainHeaders.length).setNumberFormat('@');
  view.getRangeByIndexes(6,0,formulas.length,item.mainHeaders.length).formulas=formulas;
  view.tables.add(`A6:${chars(item.mainHeaders.length-1)}${formulas.length+6}`,true,'SignalView');
  view.getRangeByIndexes(6,0,formulas.length,item.mainHeaders.length).format.font={name:font,size:10,color:'#20252B'};
  view.getRangeByIndexes(6,0,formulas.length,item.mainHeaders.length).format.rowHeight=30;
  item.mainHeaders.forEach((field,col)=>{
   if(numeric.has(field) || field==='metric_value' && item.signal!=='SIG07')view.getRangeByIndexes(6,col,formulas.length,1).setNumberFormat(/days/.test(field)?'#,##0':'#,##0.00');
  });
  view.freezePanes.freezeRows(6);view.freezePanes.freezeColumns(2);
 }
 addTable(wb,'Definitions',item.signal+' definitions',['Topic','Current definition','Status','Source reference'],item.definitions,
  'Business purpose, development rules and unresolved definitions are distinguished.','Latest user decisions override older archived requirements.','narrative');
 addTable(wb,'Findings',item.signal+' findings',['Topic','Finding','Required action','Validation state'],item.findings,
  'Current findings and cross-signal limitations. Original dated reports are included in the package.','','narrative');
 const sourceRows=item.raw.map(raw=>[raw.name,raw.sourceFile,raw.sourceTable,raw.data.length,raw.role]);
 if(!sourceRows.length)sourceRows.push(['Not supplied','','',0,'Missing enquiry source; no events inferred']);
 addTable(wb,'Sources',item.signal+' sources',['Sheet','Workspace source file','Source table','Raw rows','Role'],sourceRows,
  'Workspace-relative source files are preserved under development/.');
 const lineage=[];
 for(const row of item.evidenceData){
  const r=Object.fromEntries(headers.map((h,i)=>[h,row[i]]));
  for(const [field,role] of [['source_record_references','current_evidence'],['previous_source_record_references','prior_comparison']]){
   for(const ref of r[field]?r[field].split(' | '):[]){
    const match=ref.match(/^([^:]+):record (\d+)$/);
    lineage.push([r.evidence_id,r.client,r.mastergroup_id,r.source,match[1],match[2],role,r.observation_date]);
   }
  }
 }
 addTable(wb,'Lineage',item.signal+' source lineage',['Evidence ID','Client','Mastergroup','Source','CSV file','CSV record','Role','Evidence observation date'],lineage,
  'One row per evidence-to-source link. Prior comparison records retain their own raw source dates.');
 if(item.coverage.length)addTable(wb,'Coverage',item.signal+' missing-data coverage',['Client','Mastergroup','Source','Coverage state','Reason'],
  item.coverage.map(r=>[r.client,r.mastergroup_id,r.source,r.coverage_status,r.row_note]),'Missing or empty source data is not negative client activity.','','narrative');
 if(item.ownerReview){
  const [h,records]=item.ownerReview;
  addTable(wb,'Owner review',item.signal+' validation questions',h,records.map(r=>h.map(k=>r[k])),
   'Local arithmetic checks pass. Eligibility and source definitions remain unverified.');
 }
 for(const raw of item.raw){
  // A separate normalized Lineage sheet replaces long repeated evidence-ID lists.
  const rawHeaders=raw.headers[0]==='audit_record'?[raw.headers[0],raw.headers[1],raw.headers[3],...raw.headers.slice(4)]:raw.headers;
  const rawData=raw.headers[0]==='audit_record'?raw.data.map(r=>[r[0],r[1],r[3],...r.slice(4)]):raw.data;
  addTable(wb,raw.name,item.signal+' — '+raw.name,rawHeaders,rawData,raw.role,
   'Source: '+raw.sourceTable+' | '+raw.sourceFile,'raw');
 }
 await finish(wb,item.signal+'.xlsx',item.evidenceData.length);
}

const overview=plan.overview;
const wb=Workbook.create();
const summary=baseSheet(wb,'Summary','Bond Radar — signal overview','626 development evidence records. Business triggers remain unverified.');
summary.getRange('A5').values=[['Evidence records']];summary.getRange('B5').values=[[626]];
const all=overview.summary.filter(r=>r.summary_scope==='all_clients');
const h=['Signal','Name','Evidence records','Needs validation','Unavailable evidence','>70% test','Recent creation test','Populated CRR','Coverage'];
summary.getRange('A9:I15').values=[h,...all.map(r=>[r.signal_id,r.signal_name,Number(r.evidence_rows),Number(r.needs_validation_rows),Number(r.unavailable_evidence_rows),Number(r.above_70_test_candidates),Number(r.recent_creation_test_candidates),Number(r.populated_application_crr),r.coverage_status])];
summary.getRange('A9:I9').format={fill:'#343A40',font:{name:font,size:10,color:'#FFFFFF',bold:true},wrapText:true,rowHeight:42};
summary.getRange('A9:I15').format.columnWidth=22;summary.getRange('B9:B15').format.columnWidth=42;
summary.getRange('A10:I15').format.rowHeight=32;summary.getRange('C10:H15').setNumberFormat('#,##0');
summary.getRange('A18').values=[['SIG03 has no enquiry source. SIG04 has an empty KYC export. Neither proves no activity.']];
summary.getRange('A19').values=[['Use each signal workbook for definitions, findings, full evidence and separate raw-source sheets.']];
const client=overview.summary.filter(r=>r.summary_scope==='client');
addTable(wb,'Client summary','Signal evidence by client',overview.summaryHeaders,client.map(r=>overview.summaryHeaders.map(k=>r[k])),
 'Evidence counts and development-test flags. Do not interpret as confirmed alerts.');
addTable(wb,'Definitions','All signal definitions',['Signal','Topic','Current definition','Status'],overview.definitions,'Latest decisions and unresolved rules.','','narrative');
addTable(wb,'Findings','All current findings',['Signal','Topic','Finding','Required action'],overview.findings,'Current consolidated findings. Dated originals are included separately.','','narrative');
addTable(wb,'Source inventory','Curated data inventory',overview.inventoryHeaders,overview.inventory.map(r=>overview.inventoryHeaders.map(k=>r[k])),
 'Source roles distinguish selected inputs, archive context, superseded samples, metadata and quarantine.');
addTable(wb,'Counterparty raw','Shared Counterparty identity reference',overview.counterpartyHeaders,overview.counterparty.map(r=>overview.counterpartyHeaders.map(k=>r[k])),
 '167 native rows. Reference only; no new entity joins or approvals inferred.','delta.prod_party_gda.counterparty_core | development/data/current_exports/counterparty_current.csv','raw');
await finish(wb,'SIGNAL_OVERVIEW.xlsx',626);
await fs.writeFile(path.join(output,'WORKBOOK_CHECKS.json'),JSON.stringify(checks,null,2)+'\n',{flag:'wx'});
