"""Independently verify saved XLSX values using only ZIP and XML readers."""
import argparse
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[2]
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'


def read(path):
 with path.open(encoding='utf-8-sig',newline='') as f:
  r=csv.DictReader(f);return r.fieldnames,list(r)


def col(index):
 result=''
 while index>=0:
  result=chr(65+index%26)+result;index=index//26-1
 return result


def sheets(path):
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  shared=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   shared=[''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',NS)]
  relationships={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  result={}
  for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',NS):
   target=relationships[sheet.attrib[REL]]
   xmlpath=target.lstrip('/') if target.startswith('/') else 'xl/'+target
   cells={};formulas={}
   for cell in ET.fromstring(z.read(xmlpath)).findall('.//s:sheetData/s:row/s:c',NS):
    kind=cell.attrib.get('t');value=cell.find('s:v',NS)
    assert kind!='e',(path.name,sheet.attrib['name'],cell.attrib['r'],value.text if value is not None else '')
    text='' if value is None or value.text is None else value.text
    if kind=='s':text=shared[int(text)]
    elif kind=='inlineStr':text=''.join(cell.find('s:is',NS).itertext())
    cells[cell.attrib['r']]=text
    f=cell.find('s:f',NS)
    if f is not None:formulas[cell.attrib['r']]=f.text or ''
   result[sheet.attrib['name']]=(cells,formulas)
  return result


def verify(folder):
 fields,evidence=read(ROOT/'runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv')
 expected_total=0;results=[]
 for signal in ['SIG01','SIG02','SIG03','SIG04','SIG06','SIG07']:
  book=sheets(folder/(signal+'.xlsx'))
  assert list(book)[:5]==['Summary','Signal data','Definitions','Findings','Sources']
  rows=[r for r in evidence if r['signal_id']==signal]
  expected_total+=len(rows)
  detail=book['Evidence detail'][0]
  assert [detail.get(col(i)+'6','') for i in range(len(fields))]==fields
  for index,row in enumerate(rows,7):
   assert all(detail.get(col(i)+str(index),'')==row[k] for i,k in enumerate(fields)),(signal,index,'evidence value')
  summary=book['Summary'][0]
  assert Decimal(summary['B5'])==len(rows)
  for i,group in enumerate(['MG001356','MG102229','MG101624'],10):
   subset=[r for r in rows if r['mastergroup_id']==group]
   expected=[len(subset),sum(r['assessment_status']=='needs_validation' for r in subset),
      sum(r['assessment_status']=='unavailable' for r in subset),sum(r['above_70_for_testing']=='True' for r in subset),
      sum(r['recent_creation_for_testing']=='True' for r in subset),sum(r['source']=='application_ratings' and r['assessment_status']=='needs_validation' for r in subset)]
   assert [Decimal(summary[col(j)+str(i)]) for j in range(2,8)]==expected,(signal,group,'cached summaries')
  view,formulas=book['Signal data']
  view_headers=[]
  for i in range(100):
   if col(i)+'6' not in view:break
   view_headers.append(view[col(i)+'6'])
  numeric={'current_drawn','previous_drawn','utilisation_amount','approved_limit','proposed_limit','event_age_days','event_lookback_days','comparison_gap_days'}
  for index,row in enumerate(rows,7):
   for i,field in enumerate(view_headers):
    address=col(i)+str(index);actual=view.get(address,'');expected=row[field]
    assert address in formulas,(signal,address,'missing live formula')
    if expected and (field in numeric or field=='metric_value' and signal!='SIG07'):
     assert abs(Decimal(actual)-Decimal(expected))<=max(Decimal('0.000000001'),abs(Decimal(expected))*Decimal('1e-13')),(signal,address,'numeric view')
    else:assert actual==expected,(signal,address,field,actual,expected)
  # Reconcile every native raw field from source-specific sheets.
  source_cells=book['Sources'][0]
  raw_count=0
  for index in range(7,100):
   sheet_name=source_cells.get('A'+str(index),'')
   source_file=source_cells.get('B'+str(index),'')
   if not sheet_name or not source_file:continue
   native_fields,native=read(ROOT/source_file)
   raw_cells=book[sheet_name][0]
   offset=0 if sheet_name=='Raw KYC' else 3
   assert [raw_cells.get(col(i+offset)+'6','') for i in range(len(native_fields))]==native_fields
   for rnum,row in enumerate(native,7):
    assert all(raw_cells.get(col(i+offset)+str(rnum),'')==row[k] for i,k in enumerate(native_fields)),(signal,sheet_name,rnum,'native value')
   raw_count+=len(native)
  results.append(dict(file=signal+'.xlsx',sheets=len(book),evidence_rows=len(rows),native_rows_checked=raw_count,
      checks='All saved evidence/native cells, compact-view cached values/formulas, summary counts, ZIP integrity and absence of Excel error cells',status='PASS'))
 assert expected_total==626
 overview=sheets(folder/'SIGNAL_OVERVIEW.xlsx')
 assert Decimal(overview['Summary'][0]['B5'])==626
 headers,raw=read(ROOT/'data/current_exports/counterparty_current.csv')
 for index,row in enumerate(raw,7):
  assert all(overview['Counterparty raw'][0].get(col(i)+str(index),'')==row[k] for i,k in enumerate(headers))
 results.append(dict(file='SIGNAL_OVERVIEW.xlsx',sheets=len(overview),counterparty_rows_checked=167,status='PASS'))
 manifest=json.loads((folder/'PACKAGE_MANIFEST.json').read_text())
 assert all(hashlib.sha256((folder/name).read_bytes()).hexdigest()==h for name,h in manifest['workbooks'].items())
 (folder/'SAVED_XLSX_CHECKS.json').write_text(json.dumps(dict(status='PASS',unique_evidence_records=626,results=results),indent=2)+'\n')
 print(json.dumps(dict(status='PASS',unique_evidence_records=626,workbooks=len(results),results=results),indent=2))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('folder')
 verify(ROOT/parser.parse_args().folder)
