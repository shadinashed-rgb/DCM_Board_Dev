"""Build organized signal workbooks and a portable development snapshot."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
CSV_ROOT=ROOT/'runs/signal_extracts_20261105_002'
NAMES={'SIG01':'RCF drawing increase','SIG02':'New facilities','SIG03':'Enquiry and pre-hedging activity',
       'SIG04':'KYC activity','SIG06':'Utilisation and covenant evidence','SIG07':'Rating and advisory context'}
BASE='PROJECT_STATE.md; DATA_MODEL.md; current development updates'
DEFINITIONS={
 'SIG01':[
  ('Business purpose','Investigate a material increase in RCF drawings that could merit banker review.','Business definition incomplete'),
  ('Primary input','CLO REV/RCF observations; keep source-native facility/borrower grain and the latest two available group snapshots.','Development rule'),
  ('Calculation','Current drawn minus prior drawn, with the actual comparison dates/gap retained. Absent prior observations stay unavailable.','Development rule'),
  ('Missing values','Blank/missing drawn is zero only for SIG01; retain raw blanks and current/prior imputation flags. Invalid numeric values remain unavailable.','User decision'),
  ('Materiality','EUR50m total investment-grade whole-facility drawings was a stakeholder baseline; it is not an agreed increase threshold.','Unverified business rule'),
  ('Open definitions','Increase amount/percentage, comparison period, qualifying products, currency/FX date and whole-facility versus HSBC share.','Unresolved')],
 'SIG02':[
  ('Business purpose','Investigate newly signed RCF, term-loan or bridge facilities as possible financing context.','Business definition incomplete'),
  ('Primary input','Facilities Limits; observed field facility_creation_date. Keep facility parents, products, borrowers and versions separately.','Observed source'),
  ('Calculation','Age in days = original assessment date minus creation date. The 90-day inclusive lookback is a development test.','Development rule'),
  ('Ambiguity','Withhold contexts with conflicting products or creation dates rather than selecting arbitrary first/MAX values.','Development rule'),
  ('Open definitions','Confirm signing versus amendment, migration or administration; define eligible products, amount scope and event deduplication.','Unresolved'),
  ('Publishing scope','Country/source partitions may publish on different dates; additional DE extraction is deferred and global latest selection remains unresolved.','Unresolved')],
 'SIG03':[
  ('Business purpose','Investigate derivatives/pre-hedge or swap-pricing enquiries that could relate to financing.','Business definition incomplete'),
  ('Primary input','No suitable enquiry/pricing-request source has been identified. Executed trades or facilities do not substitute for enquiries.','Missing source'),
  ('Required event fields','Entity identifiers, enquiry/request ID and date, product/type, status, amount/currency and financing purpose.','Required contract'),
  ('Open definitions','Enquiry eligibility, business-event date, repeated-request rules and an approved identity route.','Unresolved')],
 'SIG04':[
  ('Business purpose','Investigate entity onboarding or relevant KYC case activity, distinguishing business events from routine refreshes.','Business definition incomplete'),
  ('Primary input','delta.prod_party_gda.kyc; the selected target export is valid but header-only.','Empty export'),
  ('Development fields','review_request_created_time_stamp and candidate NTB/TRG purpose codes; 90-day lookback remains unverified.','Development rule'),
  ('Identity and schema','cdd_topco_legal_name is an array. mg_parent_grid/groupguci are not automatically mastergroup IDs; names are review clues.','Source constraints'),
  ('Open definitions','Known target case/entity, NTB/Trigger/Periodic/Remediation meanings, case dates, signatory coverage and event eligibility.','Unresolved')],
 'SIG06':[
  ('Business purpose','Investigate compatible utilisation pressure separately from explicit financial covenant tests.','Business definition incomplete'),
  ('Calculation','Utilisation percent = valid utilisation / compatible approved limit x 100; candidate test is strictly >70%.','Development rule'),
  ('Compatibility','Numerator/denominator must share currency, units, scope, date and participation basis. Missing/zero denominator or unknown/conflicting scope is unavailable.','Required validation'),
  ('No aggregation','Do not sum across sources, currencies, snapshots, parent/child limits or whole-facility versus HSBC share. Shared borrower rows consolidate only if exposure attributes agree.','Source constraints'),
  ('Missing values','No missing-as-zero, no fallback FX conversion and no utilisation-based inference of a covenant breach.','User decisions'),
  ('Covenants','Require genuine financial terms, actual/final value, threshold, operator, test date and result/approval state. Supplied mislabelled Counterparty payload is quarantined.','Missing source'),
  ('Open definitions','Eligible products/commitments, threshold approval, base/LCY units, participation, cancellation flags and exposure hierarchy.','Unresolved')],
 'SIG07':[
  ('Business purpose','Investigate rating/advisory context; an engagement, rating change or category trigger has not been defined.','Business definition incomplete'),
  ('Source scope','Retain existing Facilities/PVD context. Application Ratings adds CRR only, not agency ratings or new category/advisory inference.','User decision'),
  ('Displayed CRR','Non-placeholder final_crr with crr_scale. Preserve previous/proposed/approved/manual/overridden states separately; blank/N/A stays unavailable without fallback.','User decision'),
  ('Version selection','Latest supplied snapshot per source/country/CARM scope, then candidate effective periods at that snapshot. HISTORICAL can coexist with an open period.','Development rule'),
  ('Multiple ratings','Keep competing applications and multiple CRRs per CIN. No MAX, averaging, group rating or assumed numeric direction.','Source constraints'),
  ('Open definitions','CRR scales, effective periods/version flags, latest-approved scope, reviewed CIN associations and any advisory engagement criterion.','Unresolved')]
}
GLOBAL_FINDINGS=[
 ('Scope','Three target mastergroups: Vodafone MG001356, Siemens Energy MG102229 and SoftBank MG101624. SIG05 and PVD sector aggregate excluded.','Preserve scope.'),
 ('Evidence versus alerts','626 records are development evidence; business_trigger remains blank.','Define and review business rules before confirming triggers.'),
 ('Assessment dates','Original core assessed 3 November 2026; CRR assessed 4 November from the 3 November snapshot.','Do not silently rebase dates to export date.'),
 ('Identity','CIN, GID and PVD key/relationship/supergroup namespaces differ. Names and identifier shapes never establish joins.','Use explicit reviewed, date-scoped mappings; keep conflicts and native groups.'),
 ('Counterparty','Preserve valid original CLO mastergroups; only fill missing groups from a unique combined point-in-time candidate under explicit assumptions.','No arbitrary first/MAX or transitive expansion; no missing groups recovered in this baseline.'),
 ('Development associations','Observed links and inherited unique_reviewed_cohort_group labels are not production approvals or historical membership proof.','Keep the development qualification visible.'),
 ('Freshness','PVD observation date is 30 September. Daily refresh is a preference, not verified capability.','Show actual source dates; do not treat stale or empty data as no activity.'),
 ('Validation','269 local assertions and 70 tests passed in the prior validation run; source-wide completeness and business eligibility remain unverified.','Use the recorded scope and owner-review questions.'),
 ('DE publishing','Image-transcribed profile suggests seven DE partitions at 3 November. Additional raw extraction is deferred.','Treat transcription as derived evidence; publishing/current-selection completeness unresolved.'),
 ('Provenance gaps','Exact submitted SQL, native export times and download caps were not supplied for every round.','Keep unknowns explicit; do not use file modification time as export time.')]
FINDINGS={
 'SIG01':[
  ('Drawing comparisons','Three comparisons: Vodafone two and Siemens one. Both current and prior drawn values were imputed, yielding zero delta.','Do not describe these as observed zero drawings or a confirmed increase.'),
  ('SoftBank coverage','No identifiable REV record; nine rows lack product/facility keys and one is TERM.','No assessable RCF comparison does not establish no drawing activity.'),
  ('Comparison gap','Current 2 November versus prior 30 October; actual gap three days.','Agree comparison horizon and materiality separately from EUR50m baseline.')],
 'SIG02':[
  ('Raw grain','105 supplied current rows; 19 blank facility IDs, 86 ID-bearing rows, 63 source/country/facility keys.','Preserve product and borrower child contexts.'),
  ('Ambiguity','13 keys have multiple products; two also have conflicting creation dates. 50 contexts remain usable and 13 withheld.','Do not resolve with arbitrary row selection.'),
  ('Recent candidates','Eight under the 90-day test: seven Vodafone dated 17 September and one Siemens AE dated 6 October, FGL, AED40m proposed limit.','Confirm real signing/new-financing meaning and product eligibility.'),
  ('German history','349 archived DE rows at 30 October are shown separately, not added as current transactions.','Additional extraction remains deferred; source/country publishing needs validation.')],
 'SIG03':[
  ('Missing events','No assessable enquiry/pricing events in the combined evidence.','Identify the actual enquiry source and event contract; do not infer events from facilities or trades.')],
 'SIG04':[
  ('Empty target export','Zero supplied KYC rows with 326 native headers retained. Earlier unrelated cases only supported schema inspection.','Locate a known target case through a verified identity route.'),
  ('Purpose ambiguity','NTB, Trigger, Periodic and Remediation meanings and dates are unverified.','A Trigger case alone is not a financing event.')],
 'SIG06':[
  ('DRR exposures','642 native target rows reduce to 405 candidate exposures: 57 usable ratios and 348 unavailable DRR contexts.','Preserve shared borrower lineage without multiplying limits.'),
  ('Other context','Four CLO and 33 PVD utilisation contexts are unavailable; 385 unavailable utilisation contexts overall.','Do not force alternative CLO USD or stale PVD ratios without units/grain validation.'),
  ('High ratios','Five arithmetic candidates: Vodafone 94.28%; Siemens 76.80% and 74.22%; SoftBank two at 100%. All observed 2 November.','No qualifying financing eligibility has been confirmed.'),
  ('Products and flags','Candidates use FGTE, FCTA and FLNS; none is RVCF. Both FGTE rows have committed=Y and unconditionally_cancellable=Y. FCTA parent flag is G.','Define products, cancellation flags and hierarchy before inclusion/exclusion.'),
  ('Amounts','Three candidates differ between base and LCY amounts despite matching numerator/denominator currency labels.','Currency labels alone do not prove units, share or measurement basis.'),
  ('Covenants','Genuine financial covenant tests are missing. Counterparty payload labelled covenants is quarantined; Overdue reporting obligations are not breaches.','Obtain genuine terms/tests before deriving pressure or breach signals.')],
 'SIG07':[
  ('Full CRR inputs','722 rows supplied: Vodafone 477, Siemens 238, SoftBank 7, all 3 November. Earlier 207 samples reconcile as a subset.','Full scoped exports do not prove full group coverage or approved CIN links.'),
  ('Current evidence','118 SIG07 contexts: 96 existing Facilities/PVD plus 22 Application Ratings contexts (Vodafone 8, Siemens 12, SoftBank 2).','Keep each component and application separate.'),
  ('Availability','18 populated final CRRs, four unavailable: one Vodafone blank, two Siemens blanks and one Siemens N/A.','Keep raw placeholders and no fallback.'),
  ('Historical flags','Nine retained open-period contexts are HISTORICAL: two Vodafone and seven Siemens.','Validate source period/version/latest-approved semantics.'),
  ('Competing CRRs','Siemens CIN AEBBME035063734 has 2.1, 3.1 and N/A across three retained applications.','Retain all three, flagged multiple_crrs_for_cin; no numeric direction.'),
  ('Historical agency fields','Older alternate CRA fields contain two historical Siemens records repeating MY:Baa1 and SP:BBB/A-2. Their periods ended in March/June 2026.','Excluded from the CRR-only contribution; not proof of current agency ratings or independent changes.'),
  ('Raw codes','Three Siemens raw historical rows have 0000000; none passes the current period rule. All populated retained CRRs have scale 1.','Define code/scale meanings; do not assign grade direction or agency equivalence.')]
}
EXTRA={
 'SIG01':['facility_ids','clo_sub_limit_ids','product_codes','current_drawn','previous_drawn','metric_value','previous_observation_date','comparison_gap_days','current_drawn_imputed_zero','previous_drawn_imputed_zero','currency'],
 'SIG02':['facility_ids','product_codes','event_date','event_age_days','event_lookback_days','proposed_limit','currency','recent_creation_for_testing','conflicting_fields'],
 'SIG03':['event_date','validation_reason'], 'SIG04':['event_date','validation_reason'],
 'SIG06':['drr_uids','facility_ids','product_codes','utilisation_amount','approved_limit','currency','metric_value','above_70_for_testing','conflicting_fields'],
 'SIG07':['facility_ids','cins','product_codes','limit_categories','advised_ind_values','rating_values','crr','crr_raw','crr_scale','previous_crr','proposed_crr','approved_crr','latest_record','multiple_crrs_for_cin','credit_proposal_serial_no']}


def read(path):
 with path.open(encoding='utf-8-sig',newline='') as handle:
  r=csv.DictReader(handle);rows=list(r);fields=r.fieldnames or []
 assert len(fields)==len(set(fields)) and all(None not in r and None not in r.values() for r in rows)
 return fields,rows


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main(out):
 if out.exists():raise ValueError('Choose a fresh output folder')
 fields,evidence=read(ROOT/'runs/crr_full_001/DCM_Run_003_All_Signal_Evidence_With_CRR.csv')
 inputs={str(p.relative_to(ROOT)):sha(p) for p in CSV_ROOT.glob('*.csv')}
 plans=[]
 for signal in NAMES:
  _,mixed=read(CSV_ROOT/(signal+'.csv'))
  ev=[r for r in evidence if r['signal_id']==signal]
  summaries=[r for r in mixed if r['row_type']=='signal_summary']
  raw=[]
  for source_file in dict.fromkeys(r['raw_source_file'] for r in mixed if r['row_type'] in ('raw_used','raw_not_used','historical_context_not_used')):
   native_fields,native=read(ROOT/source_file)
   selected=[r for r in mixed if r['raw_source_file']==source_file and r['row_type'] in ('raw_used','raw_not_used','historical_context_not_used')]
   assert len(native)==len(selected)
   metadata=['audit_record','audit_usage','audit_evidence_ids','audit_roles']
   data=[[r['raw_source_record'],r['row_type'],r['linked_evidence_ids'],r['linked_roles']]+[r['raw__'+k] for k in native_fields] for r in selected]
   assert all(data[i][4:]==[r[k] for k in native_fields] for i,r in enumerate(native))
   basename=Path(source_file).name
   name='DE history' if 'history/' in source_file else 'Raw CLO' if 'clo_' in basename else 'Raw DRR' if 'drr_' in basename else 'Raw PVD' if 'pvd_' in basename else 'Raw Facilities' if 'facilities_' in basename else 'Raw CRR Vodafone' if 'vodafone' in basename else 'Raw CRR Siemens' if 'siemens' in basename else 'Raw CRR SoftBank'
   raw.append(dict(name=name,headers=metadata+native_fields,data=data,sourceFile=source_file,sourceTable=selected[0]['raw_source_table'],role='Historical context; excluded from current evidence' if name=='DE history' else 'Native records; audit_usage distinguishes linked and unused records'))
  if signal=='SIG04':
   native_fields,native=read(ROOT/'data/current_exports/kyc_current.csv')
   raw.append(dict(name='Raw KYC',headers=native_fields,data=[],sourceFile='data/current_exports/kyc_current.csv',sourceTable='delta.prod_party_gda.kyc',role='Empty target export; native headers preserved'))
  leading=['client','mastergroup_id']
  if signal=='SIG07':leading+=['source','component','cins','crr','crr_scale','rating_values','limit_categories']
  main_fields=list(dict.fromkeys(leading+EXTRA[signal]+['source','component','assessment_status','business_trigger','observation_date','assessment_date','stale','validation_reason','evidence_id']))
  coverage=[r for r in mixed if r['row_type']=='coverage']
  plans.append(dict(signal=signal,title=NAMES[signal],summaries=summaries,evidenceHeaders=fields,evidenceData=[[r[k] for k in fields] for r in ev],mainHeaders=main_fields,
     raw=raw,coverage=coverage,definitions=[[a,b,c,BASE] for a,b,c in DEFINITIONS[signal]],
     findings=[[a,b,c,'Business eligibility unverified'] for a,b,c in FINDINGS[signal]+GLOBAL_FINDINGS],
     ownerReview=read(ROOT/'runs/validation_20261105_001'/('SIG06_OWNER_REVIEW.csv' if signal=='SIG06' else 'SIG02_OWNER_REVIEW.csv' if signal=='SIG02' else 'SIG07_CRR_OWNER_REVIEW.csv')) if signal in ('SIG02','SIG06','SIG07') else None))
 inventory_fields,inventory=read(CSV_ROOT/'SOURCE_DATA_INVENTORY.csv')
 cp_fields,cp=read(ROOT/'data/current_exports/counterparty_current.csv')
 overview=dict(summaryHeaders=['signal_id','signal_name','summary_scope','client','mastergroup_id','evidence_rows','needs_validation_rows','unavailable_evidence_rows','above_70_test_candidates','recent_creation_test_candidates','populated_application_crr','coverage_status'],
     summary=read(CSV_ROOT/'SIGNAL_SUMMARY.csv')[1],inventoryHeaders=inventory_fields,inventory=inventory,
     counterpartyHeaders=cp_fields,counterparty=cp,definitions=[[s,a,b,c] for s in NAMES for a,b,c in DEFINITIONS[s]],
     findings=[[s,a,b,c] for s in NAMES for a,b,c in FINDINGS[s]]+[['All',a,b,c] for a,b,c in GLOBAL_FINDINGS])
 out.mkdir(parents=True)
 with tempfile.TemporaryDirectory(prefix='bond_radar_workbooks_') as temp:
  payload=Path(temp)/'plan.json';payload.write_text(json.dumps(dict(signals=plans,overview=overview),ensure_ascii=False))
  subprocess.run(['node',str(HERE/'build_workbooks.mjs'),str(payload),str(out)],check=True)
 # Copy the continuing workspace without recursive runs, installed dependencies or caches.
 dev=out/'development';dev.mkdir()
 ignore=shutil.ignore_patterns('node_modules','__pycache__','.DS_Store','.git','.pytest_cache')
 for p in ROOT.iterdir():
  if p.name in ('runs','node_modules','__pycache__','.git','.DS_Store'):continue
  target=dev/p.name
  if p.is_dir():shutil.copytree(p,target,ignore=ignore,symlinks=False)
  elif p.is_file():shutil.copy2(p,target)
 (dev/'runs').mkdir()
 if (ROOT/'runs/README.md').exists():shutil.copy2(ROOT/'runs/README.md',dev/'runs/README.md')
 for name in ['crr_full_001','validation_20261105_001','signal_extracts_20261105_002','reference_002']:
  shutil.copytree(ROOT/'runs'/name,dev/'runs'/name,ignore=ignore)
 docs=out/'findings_and_definitions';docs.mkdir()
 # Retain dated findings and requirements verbatim alongside consolidated current notes.
 for p in ROOT.glob('*'):
  if p.is_file() and p.suffix in ('.md','.txt','.docx','.xlsx'):
   shutil.copy2(p,docs/p.name)
 for p in (ROOT/'analysis').rglob('*.md'):
  if 'node_modules' in p.parts:continue
  target=docs/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 for name in ['crr_full_001','validation_20261105_001']:
  shutil.copytree(ROOT/'runs'/name,docs/name,ignore=ignore)
 definition_text='# Signal definitions — current development scope\n\nAuthority: explicit user decisions and latest dated updates supersede older discovery notes. No business triggers are confirmed. Core assessment is 3 November 2026; CRR assessment is 4 November.\n\n'
 for s in NAMES:
  definition_text+='## '+s+' — '+NAMES[s]+'\n\n'
  for a,b,c in DEFINITIONS[s]:definition_text+=f'- **{a} ({c}):** {b}\n'
  definition_text+='\n'
 (out/'SIGNAL_DEFINITIONS.md').write_text(definition_text)
 finding_text='# Findings and limitations — 5 November 2026\n\nThe 626 records are development evidence. The additional DE extraction is deferred. Historical source/report copies retain their original dates and may be superseded by current decisions.\n\n'
 for s,items in [('All signals',GLOBAL_FINDINGS)]+[(s+' — '+NAMES[s],FINDINGS[s]) for s in NAMES]:
  finding_text+='## '+s+'\n\n'
  for a,b,c in items:finding_text+=f'- **{a}:** {b} {c}\n'
  finding_text+='\n'
 (out/'FINDINGS_AND_LIMITATIONS.md').write_text(finding_text)
 assert all(sha(ROOT/p)==h for p,h in inputs.items())
 snapshot_files=[p for p in dev.rglob('*') if p.is_file()]
 copied_checks=[]
 for p in snapshot_files:
  rel=p.relative_to(dev);original=ROOT/rel
  assert original.is_file() and sha(original)==sha(p),str(rel)
  copied_checks.append(str(rel))
 manifest=dict(export_date='2026-11-05',input_sha256=inputs,evidence_rows=626,
   workbooks={p.name:sha(p) for p in out.glob('*.xlsx')},development_files=len(copied_checks),
   verification='All development copies hash-identical; workbook native/evidence values verified before export; saved XLSX independent verification recorded separately.',
   workbook_checks=json.loads((out/'WORKBOOK_CHECKS.json').read_text()))
 (out/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(dict(output=str(out),workbooks=list(manifest['workbooks']),development_files=len(copied_checks)),indent=2))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True)
 main(ROOT/parser.parse_args().out)
