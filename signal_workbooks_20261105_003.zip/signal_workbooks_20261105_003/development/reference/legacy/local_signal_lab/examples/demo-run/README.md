# Synthetic demonstration

These made-up records exercise the workflow. The demo configuration deliberately confirms synthetic definitions to test both positive and negative branches. Never use it for real data; start real runs with the package config.json.
