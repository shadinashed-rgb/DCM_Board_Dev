# Place your CSV exports here

Use one file per source: `clo.csv`, `counterparty.csv`, `facilities.csv`, `kyc.csv`, `covenants.csv`, `drr.csv`, `pvd.csv`.

For larger exports use folders such as `clo/part-001.csv`, `clo/part-002.csv`. Every chunk for one source must have the same headers/order; date/country windows should not overlap. Do not keep a flat file and a chunk folder for the same source.

Put schema exports and DDL under a separate `schemas/` folder, not inside the source data folders. The loader validates CSV headers against its source contracts and profiles all supplied columns. Schema files are retained for human review, not treated as data inputs.

Optional metadata sidecars: `clo.metadata.json` beside `clo.csv`, or `part-001.metadata.json` beside a chunk. See generated SQL metadata examples. Fill actual source location, SQL, dates, filters, extraction time and outcome. Inputs remain unchanged.

`identity_links.csv` is deliberately empty. Add only verified source-to-client links. `valid_from` and `valid_to` are inclusive ISO dates, blank for an open bound. Supported identifier types are CIN, GID, RELATIONSHIP_ID, CUSTOMER_ID and JOI_RELATIONSHIP_ID. Source is one of the seven package source IDs or `*` for an explicitly verified shared namespace. Contradictory overlapping mappings remain unresolved.

Keep identifiers as text during export and transfer. Open the original CSV directly with the pipeline; spreadsheet software can remove leading zeros before the pipeline sees them.
