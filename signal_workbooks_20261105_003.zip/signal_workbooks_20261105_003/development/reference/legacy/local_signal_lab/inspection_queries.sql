-- SQLite only: run these against a local run's bond_radar.sqlite, one at a time.
-- CLI: python3 bond_radar.py query --database runs/real-001/bond_radar.sqlite --sql "SELECT ..."

SELECT * FROM source_profile ORDER BY source;
SELECT * FROM quality_issues ORDER BY source, check_name;

SELECT source, signal_id, component, assessment_status, stale, COUNT(*) AS records
FROM signal_evidence
GROUP BY source, signal_id, component, assessment_status, stale;

SELECT * FROM client_signal_summary ORDER BY client_id, signal_id;
SELECT * FROM group_signal_summary ORDER BY mastergroup_id, signal_id;

-- Inspect ambiguous matches and disagreements without choosing an arbitrary group.
SELECT raw_id, cin, gid, original_mastergroup, final_mastergroup, match_status,
       cin_candidates, gid_candidates, cin_mapping_date, gid_mapping_date
FROM clo_enriched
WHERE match_status IN ('ambiguous', 'source_conflict', 'unmatched');

-- Trace each CLO evidence item to its original CSV file/record and values.
-- JSON1 support is supplied by normal current Python SQLite builds.
SELECT e.evidence_id, e.signal_id, e.component, e.value, e.assessment_status,
       r.__file, r.__line, r.*
FROM signal_evidence e
JOIN json_each(e.source_rows) j
JOIN raw_clo r ON r.__id = j.value
WHERE e.source = 'clo'
LIMIT 30;

-- All observations for a facility; replace the record key using one from observations.
SELECT record_key, observation_date, client_id, mastergroup_id, mapping_status, payload
FROM observations
WHERE source = 'clo'
ORDER BY record_key, observation_date;

-- Counts reconcile at the stored raw-association grain, not at unique facility grain.
SELECT (SELECT COUNT(*) FROM raw_clo) AS raw_clo_rows,
       (SELECT COUNT(*) FROM clo_enriched) AS accepted_enriched_associations,
       (SELECT COUNT(*) FROM observations WHERE source='clo') AS facility_date_observations;

-- The raw Counterparty input remains available to review route/date/status decisions.
SELECT * FROM raw_counterparty LIMIT 30;
