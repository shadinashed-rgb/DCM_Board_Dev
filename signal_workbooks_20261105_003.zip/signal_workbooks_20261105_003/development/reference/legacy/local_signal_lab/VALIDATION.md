# Development validation

Validated locally on **29 October 2026**, using Python 3.12.7 and its bundled SQLite. The supported target is Python 3.10 or newer. No live Starburst/Trino queries were executed.

## Automated checks

`python3 -m unittest discover -s tests -v`: **18 tests passed**.

Coverage includes:

- Identifier normalisation with leading zeros; valid, invalid and sentinel dates.
- Repeated CLO amounts consolidated once; raw associations retained.
- Both Counterparty routes combined; ambiguous mappings unresolved; valid original IDs preserved and source conflicts recorded.
- Historical mapping cutoff; a later mapping does not leak into an earlier CLO observation.
- Latest inactive Counterparty state does not resurrect an earlier active mapping.
- Multiple borrowers/groups remain unallocated rather than duplicating a facility.
- Strictly greater-than-70% boundary, zero limits, negative utilisation and currency mismatch.
- Amount-increase thresholds do not cross currencies without a matching configured threshold currency.
- Old KYC and financial covenant events in a recent extract do not become current candidates.
- Non-financial overdue covenants do not become financial breaches; SIG07 categories do not become advisory engagements.
- Unverified real-data defaults leave all `triggered` values NULL.
- Future observations/processing dates and contradictory identity links.
- Header-only exports, missing sources, malformed rows and conflicting input routes.
- Chunk-level lineage points to the actual contributing files rather than every file for a source.
- Existing successful outputs are never overwritten, and the query command refuses mutation.
- SQL date bounds and the unconfirmed Counterparty extraction gate.

Python source syntax and the shell launcher's syntax were checked. SQLite integrity checks passed for the synthetic demonstration and the existing sample run. SQL templates use read-only SHOW/SELECT statements and reviewed Trino syntax; their source availability, partition requirements and execution still require your SQL environment.

The runtime files were also copied into an isolated folder with spaces in its path. The launcher completed the demonstration from a different working directory, with no dependency on the original project directory or additional Python packages.

## Synthetic example

`examples/demo-run/` contains only made-up data, a separate demonstration configuration, and a completed run:

| Output | Records |
| --- | ---: |
| Raw CLO associations / enriched CLO associations | 12 / 12 |
| CLO facility/date observations | 9 |
| Signal evidence records | 25 |
| Client/signal assessments | 48 |

The demo intentionally enables synthetic definitions to exercise candidate and non-trigger branches. Its configuration is not suitable for real bank exports.

## Existing project samples

The original sample files were read without alteration. Results were written to a temporary verification directory, not copied into this package.

| Source | Raw rows loaded | Consolidated observations |
| --- | ---: | ---: |
| CLO | 100 | 38 |
| Facilities Limits | 100 | 100 |
| KYC | 100 | 100 |
| Covenants | 100 | 100 |
| DRR Facility Limits | 100 | 100 |
| PVD OMNIA DRR | 100 | 100 |
| Counterparty Core | No input supplied | Supporting lookup unavailable |

All 100 raw CLO associations were retained in enrichment. The 38 candidate facility observations agree with the earlier sample review. Missing GID/drawn columns, null source scope, old source dates and absent Counterparty input were surfaced as qualifications. The six samples produced 538 consolidated observations, 673 latest signal evidence/context records and 2,682 client/signal assessments. With the real-data default configuration, **zero evidence rows had a non-NULL trigger decision**.

These are local transformation checks on small independent samples, not source-wide join, recovery or completeness measurements. They do not establish daily freshness, financial covenant coverage or confirmed ratings-advisory activity.

## File scope

All delivered files are under `local_signal_lab/`. Existing project documents, diagrams, SQL, raw CSVs, recorded analysis outputs and archives were checked by SHA-256 and remained unchanged. Production sample records are not included in the new folder.
