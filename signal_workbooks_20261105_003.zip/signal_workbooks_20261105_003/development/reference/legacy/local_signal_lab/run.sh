#!/usr/bin/env sh
set -eu
LAB_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "${PYTHON_BIN:-python3}" "$LAB_DIR/bond_radar.py" "$@"
