# Bond Radar local signal laboratory

Run the development process on your machine using SQL results exported as CSV. Everything in this folder is independent of the previous production handover. The existing project documents and SQL are not changed.

**Start with the synthetic demo**, then use your own exports. Python **3.10 or newer** is the only requirement; SQLite and CSV support are included with Python. No database server, Spark, Hadoop, network connection or pip installation is needed for local processing. The extraction SQL is for your existing **Starburst/Trino SQL access**; this package never connects to it or submits queries automatically.

## 1 Try the complete process

Open a terminal in this folder and run:

```sh
python3 --version
python3 bond_radar.py demo --out runs/demo-001
```

On Windows, use `py -3` instead of `python3` if that is your Python launcher. All paths can be absolute; quote paths containing spaces. Each command's output path must be new. For a second demo, use `runs/demo-002`.

Open:

- `runs/demo-001/results/REPORT.md` — results and quality checks.
- `runs/demo-001/results/exports/signal_evidence.csv` — all signal metrics/context.
- `runs/demo-001/results/exports/client_signal_summary.csv` — one row per observed client identity and signal.
- `runs/demo-001/results/exports/clo_enriched.csv` — original/final mastergroup IDs, both matching routes and dates.
- `runs/demo-001/results/bond_radar.sqlite` — all raw and derived tables in one local database.

The demo contains made-up records with duplicates, missing/zero limits, matching conflicts, multiple borrowers, old events and history. Its specially enabled definitions apply **only to synthetic data**. Use `config.json`, not the demo configuration, for real exports.

A completed synthetic example is included in `examples/demo-run/` for immediate inspection. The quick-start command above creates your own separate run.

## 2 Generate SQL for your extraction window

An initial SQL pack is already in `sql_templates/`, using **1–29 October 2026**. These are examples, not a claim that each source has data in that window. First inspect available dates using your source knowledge/partition metadata, then choose source-appropriate bounds.

To generate another pack:

```sh
python3 bond_radar.py sql --start 2026-10-01 --end 2026-10-29 --out generated_sql/october-001
```

For a small initial smoke test, add `--row-limit 100`. This creates an **arbitrary limited sample**, useful for header/type checks but insufficient for history, complete client coverage or join match rates. Later regenerate without the limit using a manageable date/country/client scope. Keep relevant product/status history; raw capture does not apply EUR 50 million, 70% or REV-only filters.

For each source:

1. Run the statements in `01_schema.sql` separately. Export the column list, then the DDL separately; use `SHOW CREATE VIEW` if the object is a view.
2. Review actual date types/formats, partition requirements and source location. The six sampled source date columns are VARCHAR in the supplied schemas. The generated predicates use their observed string formats and avoid casting partition columns.
3. Adjust source-specific windows and add verified client/country predicates where needed. Start narrow and expand after checking volumes. A date profile still scans its selected partitions.
4. Run `03_date_profile.sql` and `02_extract.sql`. Export all result rows with headers, UTF-8, comma delimiter, correctly quoted multiline fields and dot-decimal numbers. Check SQL-client export limits/truncation and successful completion.
5. Save CSVs under `inputs/` using the filenames below. Store schema/DDL and the exact submitted SQL under `inputs/schemas/` and `inputs/queries/`. Fill a metadata sidecar beside each CSV using the generated example. Record actual filters, timestamps, requested/observed dates and whether the export was complete, limited or empty.

The earlier DRR sample contained 2023 reporting dates and the PVD sample extended only to July 2025. An empty October 2026 result would need investigation, not automatic rejection of the source. Use source-specific available windows after checking metadata/source guidance; do not assume the same date bounds will yield comparable populations everywhere.

`SELECT t.*` deliberately captures the available candidate fields for development. If a connector cannot export complex columns, explicitly select verified needed columns after schema inspection. The local loader keeps every exported column as text; it interprets only the fields needed for the current tests. Large exports should be split into **non-overlapping** windows/chunks.

### Counterparty requires a location/schema check

`hive.prod_party_gda.counterparty_core` is still proposed. Its schema statement is clearly a candidate lookup; do not treat it as verified. The reviewed archive used a Delta filesystem path, whose equivalence to this catalog table has not been established.

Once you have confirmed the catalog object and its five required fields/date format, generate its extraction template explicitly:

```sh
python3 bond_radar.py sql --start 2026-10-01 --end 2026-10-29 --counterparty-confirmed --out generated_sql/confirmed-001
```

The Counterparty template includes **120 days before the CLO lower bound**, to support historical mapping. This is the previous lookback setting to validate; adjust the SQL if `counterparty.lookback_days` changes. Its proposed `run_date` VARCHAR YYYYMMDD format also needs live confirmation. If the verified table has another location/type, edit only the new generated SQL to match it. The pipeline can run other sources while this remains unresolved.

## 3 Save the CSV inputs

| Input filename | Source | Intended use |
| --- | --- | --- |
| `clo.csv` | `hive.clo_prod.clo_cda_contract_lvl` | SIG01; SIG06 utilisation |
| `counterparty.csv` | Proposed `hive.prod_party_gda.counterparty_core` | CLO mastergroup enrichment |
| `facilities.csv` | `delta.prod_credit_and_lending_gda.facilities_limits` | SIG02; SIG07 context |
| `kyc.csv` | `delta.prod_party_gda.kyc` | SIG04 |
| `covenants.csv` | `delta.prod_credit_and_lending_gda.covenants` | SIG06 financial covenant tests |
| `drr.csv` | `delta.prod_credit_and_lending_mda.drr_facility_limits` | Alternative SIG06 utilisation |
| `pvd.csv` | `hive.pvd_prod_wave.pvd_omnia_drr` | SIG06; SIG07 context |

Missing sources are allowed and reported. SIG03 has no identified feed and remains unavailable. SIG05 and PVD sector aggregate are excluded.

Chunk folders are also supported: `inputs/clo/part-001.csv`, `inputs/clo/part-002.csv`, etc. Use identical header order within a source. Do not keep both a flat input and a chunk folder for the same source. Files are appended into one raw table per run; exact duplicates are reported and preserved raw.

The original returned filenames such as `clo_sample.csv`, `facilities_limits_sample.csv`, `kyc_samples.csv`, `covenant_samples.csv`, `drr_facility_samples.csv` and `omina_drr_samples.csv` are recognised automatically. You can run against the existing project's `../sql/sql_samples` directory without moving or modifying it. Historical aggregate/profile/schema files in that directory are not ingested as source data.

## 4 Run your own data

```sh
python3 bond_radar.py run --input inputs --as-of 2026-10-29 --out runs/real-001
```

Or inspect the previously returned samples:

```sh
python3 bond_radar.py run --input ../sql/sql_samples --as-of 2026-10-29 --out runs/existing-samples-001
```

Choose the assessment date explicitly. Source observations and available processing dates after that date are excluded from derived evidence. Raw input values remain available. A successful run writes a new directory atomically; existing run directories are never overwritten. Each run includes the exact configuration, program/input hashes, input filenames, CSV row references and a log. Failed runs stay in a hidden `.run-name-*` directory with their traceback/log for diagnosis.

The `as-of` check uses dates exposed in the CSV, not historical database versions. It cannot reconstruct records that were corrected later without suitable source history/effective dates. PVD ETL dates are checked when present; an absent processing date remains a limitation.

## 5 Inspect the database

```sh
python3 bond_radar.py query --database runs/real-001/bond_radar.sqlite --sql "SELECT * FROM client_signal_summary LIMIT 30"
python3 bond_radar.py query --database runs/real-001/bond_radar.sqlite --sql "SELECT source, signal_id, component, assessment_status, COUNT(*) AS n FROM signal_evidence GROUP BY 1,2,3,4"
python3 bond_radar.py query --database runs/real-001/bond_radar.sqlite --sql "SELECT * FROM quality_issues WHERE severity='WARN'"
```

The query command opens SQLite read-only and prints CSV. See `inspection_queries.sql` for joins to source rows, history, mapping conflicts and client evidence. An SQLite desktop viewer can also open the database; no particular viewer is required.

## 6 Refine the configuration through testing

`config.json` defaults to **unverified definitions**. It computes suitable metrics where possible but leaves `triggered` empty until their definitions/settings are verified. Numeric metrics may be available even when a business trigger is not.

| Setting | Development behaviour / decision needed |
| --- | --- |
| `freshness_days = 30` | Test freshness threshold, not an agreed service level. Applied to observation dates; inspect event ages separately. |
| Counterparty lookback/lifecycle/sentinels | Previous settings only. Validate accepted statuses, blank status, invalid IDs and lookback; set `settings_verified` only after review. |
| `counterparty.as_of_policy` | `point_in_time` limits each mapping to its CLO observation date; `current_group` explicitly restates under the assessment-date mapping. Both retain route dates. |
| `identity.cin_namespace_verified` | False: shared CIN keys are provisional and labelled. Confirm identifier scope or use explicit links. Leading zeros are retained. |
| SIG01 fields/rule | Uses local-currency `facility_drawn_amount` by default, then latest versus immediately previous observation. Set an agreed minimum increase, its `threshold_currency` and maximum comparison gap. The rule is assessed only in that currency; no FX conversion is inferred. Comparison is not a fixed-period lookback. |
| EUR 50m baseline | **Not implemented as an eligibility rule.** Investment-grade scope, total-facility/HSBC share, participation and EUR conversion are unverified. Do not use the increase setting as a substitute. |
| SIG06 | Proposed threshold is strictly **greater than 70%**. Validate drawn/limit definitions, currency, approved-limit basis, participation and grain for each source before enabling its definition. |
| PVD currency/grain | No currency or explicit facility ID is established. Requires a verified currency and grain to assess a trigger; otherwise context is retained and the ratio may be unavailable. |
| SIG02 | Creation date is a candidate event. Qualifying product codes are deliberately empty until verified. A 90-day event window is a development setting to agree. |
| SIG04 | NTB/TRG are candidate review purposes. Request-created time is the initial event field; change only after agreeing its meaning. A 90-day event window is a development setting. |
| Covenants | Requires verified financial type, final-value/threshold units, compliance-operator meaning, event date and approved-result codes. Approved codes start empty. `reporting_dt` and a 90-day event window are development candidates to agree; missing/old tests remain unavailable for current breach assessment. Multiple-threshold rules are withheld for separate implementation. |
| SIG07 | Category/rating fields are retained as context. The package never infers an advisory engagement from them. |

Make a copy of the configuration for each experiment and pass `--config path/to/experiment.json`. Do not mark a definition verified merely to produce a positive result. All triggered rows remain **development candidates**.

### Add verified client links

Edit `inputs/identity_links.csv` only when a source-to-client mapping is known. Example **format using made-up identifiers**:

```csv
source,identifier_type,identifier_value,client_id,mastergroup_id,valid_from,valid_to
pvd,JOI_RELATIONSHIP_ID,DEMO_REL,DEMO_CLIENT,DEMO_GROUP,2026-01-01,
covenants,RELATIONSHIP_ID,DEMO_REL,DEMO_CLIENT,DEMO_GROUP,2026-01-01,
```

The source namespace and validity interval are part of the mapping. Exact/source-wildcard matching routes are combined; conflicting overlapping mappings remain ambiguous. A shared CIN key uses `CIN:<text>` unless an explicit link supplies another client ID. CLO Counterparty enrichment provides group IDs, not a universal facility bridge. Facility IDs from different sources are never automatically joined.

## 7 Read the outputs correctly

- `raw_<source>`: original CSV fields as text, plus input file, CSV record number, hash and internal row ID.
- `source_manifest`, `source_profile`, `column_profile`, `quality_issues`: input provenance, dates, freshness, missingness, duplicates, invalid numbers and interpretation gaps.
- `clo_enriched`: one row per accepted raw CLO association. Latest key state is selected **before** lifecycle filtering; both CIN/GID candidate sets are combined. Valid original IDs are preserved; disagreements are flagged. Names are copied only with an original valid CLO ID and are not newly verified by Counterparty.
- `observations`: candidate key/date records after consolidation. Conflicting fields withhold affected metrics. Null source-scope components remain explicit and require uniqueness review. Multiple borrower associations are retained in enrichment; an unallocated shared facility gets one source-scoped evidence identity, not duplicated full balances.
- `signal_evidence`: latest source-record assessments, with prior CLO observation references for SIG01. Different SIG06 sources/components remain separate. Context, unavailable metrics and unverified definitions are explicit.
- `signal_assessments` / `client_signal_summary`: all six signals for each observed identity. `unavailable`, `needs_validation`, `stale_evidence`, `partial_assessment`, `candidate_trigger` and `assessed_no_trigger_in_supplied_records` are distinct. No state establishes source-wide absence of activity.
- `group_signal_summary`: evidence counts grouped by mastergroup, component and mapping status. It does not sum overlapping exposure or calculate group-level utilisation. Review unresolved/provisional group mappings before presentation.

All source history stays in raw tables and observations, even though the signal table uses the latest state per candidate record. Re-running with the same inputs/as-of/config into a new run is reproducible; it rebuilds the local database rather than incrementally appending alerts.

## 8 Checks and troubleshooting

Run the regression tests:

```sh
python3 -m unittest discover -s tests -v
```

| Symptom | Action |
| --- | --- |
| Output directory already exists | Choose a new run name. Prior successful outputs are retained. |
| Required header missing | Check the full export, actual live schema and the source contract in `bond_radar.py`. Historical CLO samples legitimately lack GID/drawn fields and produce warnings/unavailable metrics. |
| Ragged rows / wrong column count | Check delimiter, quoting, multiline fields and SQL-client export truncation. Default delimiter is comma; configure another single character if needed. |
| Header-only CSV | Check the submitted query, bounds, partitions, execution status and exporter. Empty results do not prove no source history. |
| No SIG01 change | Supply repeated observations of fixed facility keys and the configured drawn measure. The old 19-column CLO sample has only one date and lacks `facility_drawn_amount`. Do not silently divide its USD measure by a local limit. |
| No joined client across sources | Review identifier meaning, country/source scope, observation dates and verified links. Independent limited samples cannot establish join coverage. |
| Stale records | Inspect per-source dates, then choose current/relevant extraction bounds. Do not relabel the processing date as the business-event date. |
| All triggers blank | Expected with the real-data defaults. Review computed metrics and resolve definition/units/mapping gaps before enabling test rules. |
| Large CSVs | Start with bounded slices, then non-overlapping chunks. Raw ingestion streams to disk and sorted observation groups are processed individually; one extremely large key/date group still needs memory. This is a development runner, not a distributed production engine. |

Exit code 0 means the diagnostic run completed, possibly with warnings/unavailable signals. Exit code 2 indicates invalid input/configuration or an operational error. Inspect `REPORT.md` and `validation.json`; completion is not publication approval.

## Scope and references

The design follows the project's planning decisions as of **29 October 2026**. Candidate tables and mappings remain subject to live verification. This folder contains no copied production client data and no network/authentication code. It can be copied by itself to another machine.

SQL syntax was checked against [Trino SELECT](https://trino.io/docs/current/sql/select.html) and [SHOW COLUMNS](https://trino.io/docs/current/sql/show-columns.html). Local tests cannot prove remote access, partition pruning, business semantics or the actual query results. See `VALIDATION.md` for the checks performed during development.
