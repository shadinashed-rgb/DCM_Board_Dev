-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "delta"."prod_credit_and_lending_gda"."covenants";

SHOW CREATE TABLE "delta"."prod_credit_and_lending_gda"."covenants";
