# Generated read-only extraction SQL

Run schema statements first, verify dates/partitions and source identity, then run bounded extracts. Save data as `<source>.csv` or `<source>/part-001.csv` in your input directory. Save schema and DDL outside the source data folders. Copy each metadata example beside the CSV as `<csv-stem>.metadata.json` and fill in the actual submitted query/parameters and extraction outcome.

Counterparty catalog location and date format require confirmation. The other queries follow supplied schema exports, not a live verification. Date profiles describe exported raw-row coverage, not unique facilities. No query is automatically submitted.

Syntax reference: https://trino.io/docs/current/sql/select.html and https://trino.io/docs/current/sql/show-columns.html.
