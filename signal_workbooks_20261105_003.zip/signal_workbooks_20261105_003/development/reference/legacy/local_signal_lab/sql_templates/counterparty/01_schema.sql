-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "hive"."prod_party_gda"."counterparty_core";

SHOW CREATE TABLE "hive"."prod_party_gda"."counterparty_core";
