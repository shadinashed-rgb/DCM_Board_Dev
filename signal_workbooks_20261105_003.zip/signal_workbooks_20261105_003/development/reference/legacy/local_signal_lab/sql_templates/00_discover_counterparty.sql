-- Read-only metadata discovery in the two known catalogs. Execute separately.
-- Visibility depends on access; no result does not prove the source is absent.
SELECT table_catalog, table_schema, table_name, table_type
FROM "hive"."information_schema"."tables"
WHERE lower(table_name) LIKE '%counterparty%core%'
ORDER BY table_schema, table_name;

SELECT table_catalog, table_schema, table_name, table_type
FROM "delta"."information_schema"."tables"
WHERE lower(table_name) LIKE '%counterparty%core%'
ORDER BY table_schema, table_name;
