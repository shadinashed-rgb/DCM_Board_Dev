-- READ ONLY. Execute statements separately. Save each result independently.
SELECT t."joi_date" AS source_date, COUNT(*) AS raw_rows
FROM "hive"."pvd_prod_wave"."pvd_omnia_drr" t
WHERE t."joi_date" >= '2026-10-01' AND t."joi_date" <= '2026-10-29'
GROUP BY t."joi_date"
ORDER BY t."joi_date";
