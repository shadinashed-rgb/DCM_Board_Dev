-- READ ONLY. Execute statements separately. Save each result independently.
-- Review live schema and partition properties first. Native date formats follow supplied schemas.
-- Capture all relevant fields and history within these bounds. No product/materiality/utilisation filters.
-- Add verified country/client/partition predicates to control volume; split into non-overlapping chunks.
-- SELECT t.* preserves candidate fields for development. Review complex types/export format in your SQL client.
SELECT t.*
FROM "hive"."pvd_prod_wave"."pvd_omnia_drr" t
WHERE t."joi_date" >= '2026-10-01' AND t."joi_date" <= '2026-10-29';
