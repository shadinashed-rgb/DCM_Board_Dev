-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "hive"."pvd_prod_wave"."pvd_omnia_drr";

SHOW CREATE TABLE "hive"."pvd_prod_wave"."pvd_omnia_drr";
