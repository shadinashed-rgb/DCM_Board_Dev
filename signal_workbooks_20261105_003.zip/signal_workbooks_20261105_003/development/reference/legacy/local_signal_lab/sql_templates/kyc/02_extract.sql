-- READ ONLY. Execute statements separately. Save each result independently.
-- Review live schema and partition properties first. Native date formats follow supplied schemas.
-- Capture all relevant fields and history within these bounds. No product/materiality/utilisation filters.
-- Add verified country/client/partition predicates to control volume; split into non-overlapping chunks.
-- SELECT t.* preserves candidate fields for development. Review complex types/export format in your SQL client.
SELECT t.*
FROM "delta"."prod_party_gda"."kyc" t
WHERE t."run_date" >= '20261001' AND t."run_date" <= '20261029';
