-- READ ONLY. Execute statements separately. Save each result independently.
SELECT t."run_date" AS source_date, COUNT(*) AS raw_rows
FROM "delta"."prod_party_gda"."kyc" t
WHERE t."run_date" >= '20261001' AND t."run_date" <= '20261029'
GROUP BY t."run_date"
ORDER BY t."run_date";
