-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "delta"."prod_party_gda"."kyc";

SHOW CREATE TABLE "delta"."prod_party_gda"."kyc";
