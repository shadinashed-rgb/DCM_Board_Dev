-- READ ONLY. Execute statements separately. Save each result independently.
SELECT t."reporting_date" AS source_date, COUNT(*) AS raw_rows
FROM "delta"."prod_credit_and_lending_mda"."drr_facility_limits" t
WHERE t."reporting_date" >= '20261001' AND t."reporting_date" <= '20261029'
GROUP BY t."reporting_date"
ORDER BY t."reporting_date";
