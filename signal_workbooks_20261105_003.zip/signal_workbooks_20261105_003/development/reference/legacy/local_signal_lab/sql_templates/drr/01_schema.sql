-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "delta"."prod_credit_and_lending_mda"."drr_facility_limits";

SHOW CREATE TABLE "delta"."prod_credit_and_lending_mda"."drr_facility_limits";
