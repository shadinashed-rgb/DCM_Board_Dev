-- READ ONLY. Execute statements separately. Save each result independently.
SHOW COLUMNS FROM "hive"."clo_prod"."clo_cda_contract_lvl";

SHOW CREATE TABLE "hive"."clo_prod"."clo_cda_contract_lvl";
