# Local database and signal contracts

All table/column names below are local design choices. They are not additional upstream columns or confirmed production contracts.

## Layers

```text
CSV exports ──> raw_<source> ──> observations ──> signal_evidence
                    │                │                 │
                    │          identity_links          ├──> client_signal_summary
                    │                │                 └──> group_signal_summary
                    └──> clo_enriched + Counterparty lookup/audit
```

`raw_*` tables preserve text so leading zeros and original values survive. `__id` is an internal row identifier for this run; `__file`, `__line` and `__hash` identify the input file, logical CSV record number and values. A multiline CSV record can span several physical text lines.

`source_manifest` records each file's SHA-256, schema headers, count and optional metadata. It is not proof of upstream completeness. `source_profile` uses the selected source date; `column_profile` reports blanks/null tokens. Numeric conversion uses finite Decimal values with a dot separator and optional exponent; it does not guess locale/thousands separators.

## Source record keys

| Source | Candidate observation key | Observation/date rule |
| --- | --- | --- |
| CLO | source system + mapping system + booking entity + prefixed fallback (`sub_lim_id`, then `rct_facility_ref`, then `facility_id`) | `run_date`, YYYYMMDD. Null scope components remain explicit, with warnings; a wholly missing facility identifier is excluded from derived records. |
| Facilities | source system + country + facility ID | `run_date`, YYYYMMDD. Record semantics and facility uniqueness need validation. |
| KYC | CIN + case ID | `run_date`, YYYYMMDD; case request/resolution dates remain separate. |
| Covenants | source system + country + facility ID + covenant ID + active testing ID | `run_date`, YYYYMMDD. Test-instance grain is retained. |
| DRR | source system + reporting country + facility ID | `reporting_date`, YYYYMMDD; future `run_date` also excludes the record. |
| PVD | relationship ID | `joi_date`, ISO. This is provisional: multiple rows with different values on the same relationship/date are conflicted and withheld pending a better source key. Future ETL month dates also exclude the record. |

The package requires its source contract's key/date headers. It warns for absent candidate fields. All supplied columns remain in raw tables even when no derived rule uses them. In particular, it never falls back automatically from `facility_drawn_amount` to the differently defined USD drawn amount in older CLO samples.

## Identity and group mapping

`identity_links` contains source, identifier type/value, canonical client ID, optional mastergroup ID and inclusive validity dates. Matching uses trimmed, whitespace-normalised uppercase text, with leading zeros intact. Conflicting applicable links produce an unresolved source-scoped identity. Shared CIN matching is explicitly provisional until its namespace is confirmed.

Sources without a verified/common client key retain a namespaced identity such as a PVD relationship or covenant record key. These are testing placeholders; do not display them as verified banker clients.

Counterparty is used only for CLO mastergroup enrichment. Its two lookup routes are:

- `obligor_cin` → `customer_relationship_cin_identifier`.
- `rct_gid` → `customer_relationship_gid_identifier`.

Within the configured bounded window, select the latest observed date per key, then apply lifecycle/mastergroup validity checks. Candidate sets from both routes are combined. Preserve a valid original CLO ID and flag disagreement. Fill a missing/invalid original only when the combined set has exactly one ID. Several candidates remain ambiguous; none remain unmatched. The prior lookback/status/sentinel configuration remains unverified by default.

The default as-of policy is per-CLO-observation mapping. Current-group restatement is an explicit alternative. Both retain route dates, candidates, rule and status. Counterparty dates are observed record dates, not proven relationship-effective periods.

The code never generates a group name from a recovered ID. `final_name_from_clo` is the original CLO name only when its original ID was retained; it is not independent name verification. Explicit source group conflicts and unverified settings remain in `mapping_status`.

## Consolidation and aggregation

Raw records remain untouched. At each candidate key/date:

- Repeated CLO financial values are used once. Non-null differences in relevant amount, currency or product fields withhold metrics. All borrower associations remain in `clo_enriched`.
- Several borrower clients on one facility produce one unallocated facility identity for evidence, with the borrower client list retained in the observation payload. A group is populated only if all borrower rows resolve to the same group. No facility allocation is invented.
- Other sources conservatively treat different non-null values on the same candidate key/date as conflicts. A more precise source key/version rule may be needed after testing. Conflicting source identity fields do not assign an arbitrary client.
- The latest raw observation is chosen before product qualification; a later ineligible state is not replaced by an older eligible state. Active/closed/maturity eligibility rules still need business agreement and are not implemented as production filters.

Signal calculations run separately by source. Facilities, cases and covenant tests are not joined into a wide table that could multiply balances. PVD/DRR/CLO exposures are not summed or coalesced. `group_signal_summary` contains evidence counts with mapping qualifications, not group monetary totals or a blended utilisation percentage.

## Signal evidence contract

One row per signal/component/source record from its latest observed state, under the selected assessment date and rule version. `evidence_id` hashes that identity and its event/observation date; it is stable for identical rule inputs but is not a substitute for a production alert lifecycle.

| Fields | Meaning |
| --- | --- |
| `signal_id`, `component`, `source`, `record_key` | Which assessment and source record produced the evidence. |
| `client_id`, `mastergroup_id`, `mapping_status` | Canonical/provisional/source-scoped identity and its qualifications. |
| `event_date`, `observation_date`, `assessment_date` | Business event where known, source observation and reproducible test date. |
| `value`, `previous_value`, `denominator`, `currency`, `metric_name` | Decimal text measures and units, where evaluable. For SIG01, value is the increase; for utilisation, the percentage; for covenant tests, the configured actual/final value. |
| `triggered` | NULL for unavailable/unverified rules, 0 for an assessed non-trigger, 1 for a development candidate. Never a confirmed issuance prediction. |
| `assessment_status`, `stale`, `reason` | Rule/data readiness, observation freshness and explicit missing/invalid/unverified reasons. |
| `source_rows`, `details_json`, `rule_version` | Raw row IDs, calculation/context details and configuration version. |

`evidence_lineage` connects current evidence directly to raw source IDs, files and CSV record numbers; join its `input_file` to `source_manifest.filename` for file hashes/metadata. SIG01 previous observations and their raw row IDs are retained in `details_json`. Counterparty matching evidence is retained in `clo_enriched`, `cp_lookup`, `raw_counterparty` and the run metadata.

All calculation input history remains in `observations` and raw tables. The current testing table emits latest assessments; it does not reconstruct every historical alert. Different reporting dates across sources are shown rather than force-aligned into a fabricated daily snapshot.

`signal_assessments` covers all six retained signals for every identity seen in the supplied observations. States distinguish no evidence, unverified evidence, stale evidence, partially evaluable inputs, candidates and assessed non-triggers in supplied records. No state asserts full upstream coverage. SIG03 has no records/feed; SIG07 remains context only.

## Reproducibility and limits

Every run gets a new database, exports, configuration snapshot, hashes, log and validation report. Raw CSVs are read-only inputs. This version rebuilds per run; incremental ingestion, cross-run event reconciliation, production entitlement controls, a verified facility crosswalk, FX/participation conversion and group allocation remain future work.

Python SQLite supports the disk-backed raw data and sorted work tables. Processing holds one key/date group in memory; one exceptionally large group can still be expensive. Start with manageable, bounded development extracts. Test results establish local transformation behaviour, not live source availability or banker relevance.
