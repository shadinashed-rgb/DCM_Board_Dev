---
name: hsbc-house-style
description: Apply the user-provided HSBC house style to HTML dashboards, interactive diagrams and internal web interfaces for HSBC stakeholders. Use for HSBC theming or restyling; do not apply to unrelated brands or change application behaviour unless requested.
---

# HSBC House Style

Apply the user's observed HSBC board style as a swappable theme. This skill supplies presentation conventions, not platform architecture, financial definitions or proof of compliance with an official brand standard.

## Style authority and reusable assets

Read [references/house-style.md](references/house-style.md) when applying the theme. It is a self-contained copy of the user's house-style reference. A newer reference supplied for the current task takes precedence.

Use [assets/hsbc-theme.css](assets/hsbc-theme.css) for the reusable tokens and optional prefixed component classes. Apply `data-hsbc-theme` to the document root or themed container. Map an existing interface's classes to these tokens rather than replacing its structure. For a standalone offline HTML deliverable, embed the CSS so the file does not depend on this skill's installation path.

## Essential conventions

- Use HSBC red `#db0011`, hover red `#b1000e`, black/charcoal text, slate secondary text, grey page background, white cards and soft grey supporting surfaces. Keep brand choices in the theme layer.
- Use `"Univers Next for HSBC", Arial, sans-serif`. Design for Arial when the brand font is unavailable. Titles, labels, buttons and headers use weight 700; body text uses 400, generally 13–14px with about 1.5 line spacing. Compact dashboard titles are around 18px.
- Use red uppercase kickers at 11–12px with `.08em` tracking, a centered page around 1300–1600px maximum width, 24px desktop padding and about 14px mobile padding.
- Use white bordered cards with 14–16px corners and the reference's subtle shadow. A topbar can carry a 6px red top border. Keep identity on the left and actions on the right when practical.
- Action buttons use pill shapes, bold uppercase 11px labels and `.08em` tracking. Primary actions are red with white text; secondary actions have white backgrounds and red text/borders. Keep diagram nodes readable as nodes rather than forcing every node into an action-pill shape.
- Tables use black headers, white uppercase bold header text, visible grey cell borders and soft-grey zebra rows. Preserve horizontal access to wide tables.
- The supplied reference defines a light theme. Use that palette consistently by default, including on a device using dark appearance. Add a dark variant only when requested or required by the target surface, with equivalent contrast.

## Colour meaning

Red is the brand colour. When a board explicitly encodes signal strength, the reference order is red → amber → green → grey/no data, using `r / a / g / n`; document the meaning on that board. Do not invent strength scores or assign that scale to unvalidated candidates.

In an interactive flowchart, red may instead identify the current selection and connected paths. State that it indicates selection, not severity, risk or signal strength. Use explicit wording for missing sources and genuine errors; colour alone must not carry their meaning.

## Logos and portability

Use an approved logo asset when supplied and embed it for offline delivery. The reference's Studio-host logo URLs are historical examples, not mandatory dependencies. Do not assume access to that host, fetch private assets without a task need, or invent an official logo. Text identity is sufficient when no logo asset is available.

Include `<meta name="theme-color" content="#db0011">` for a standalone HTML page. Avoid remote font, image or CSS dependencies when offline portability is part of the task.

## Applying and checking the theme

Preserve content, source mappings, data qualifications and existing interactions when restyling. Do not add status metrics, publication, hosting or unrelated application changes merely to apply the theme.

Inspect the result at desktop and mobile widths. Typical breakpoints are around 1200px for stacking columns and 720px for compact controls; adapt these to actual content. Keep labels, long identifiers and controls readable, keyboard focus visible, and reduced-motion preferences respected. Recheck the interactions affected by styling, including diagram selection, pan/zoom, detail panels and print views where they exist.
